# Worker Classification Intake — IRS control test + FLSA three-gate

> Run Part 1 for every worker before you write "contractor" or "employee." If the
> answer is W-2, run Part 2 to set exempt vs. non-exempt. Classification follows the
> **control facts, not the label on the contract.** Escalate borderline calls to
> employment counsel.

Worker / role: __________  Date: __________  Filled out by: __________

---

## Part 1 — IRS control test (contractor or employee?)

Answer each. Tally the leans at the bottom.

### Behavioral control — who controls *how* the work gets done?
- [ ] Company sets the worker's hours / schedule. (→ employee)
- [ ] Company provides training on methods. (→ employee)
- [ ] Company can assign additional or different tasks at will. (→ employee)
- [ ] Company directs the sequence and details of the work. (→ employee)
- [ ] Worker decides methods and hours independently. (→ contractor)

### Financial control — who bears cost and risk?
- [ ] Company provides the tools, equipment, and workspace. (→ employee)
- [ ] Worker is paid by the hour / salary, not by the project. (→ employee)
- [ ] Worker has no real opportunity for profit or loss. (→ employee)
- [ ] Worker has significant unreimbursed business expenses. (→ contractor)
- [ ] Worker markets the same services to other clients. (→ contractor)

### Relationship — how permanent and how core?
- [ ] Arrangement is ongoing / indefinite (not project-scoped). (→ employee)
- [ ] Company provides benefits (PTO, insurance, etc.). (→ employee)
- [ ] Worker works only for this company (exclusivity). (→ employee)
- [ ] The work is a core, ongoing part of the business. (→ employee)
- [ ] There is a genuine fixed-term project with a defined deliverable. (→ contractor)

**Tally:** leans-employee ____ / leans-contractor ____.
**Classification (Part 1): [ ] W-2 employee   [ ] 1099 contractor   [ ] Borderline → counsel**

> Punchline: substance over label. Someone who works 9-to-5 in your office, on your
> laptop, only for you, for 18 months, fails all three groups — the "contractor"
> label will not survive an audit.

---

## Part 2 — FLSA three-gate test (only for W-2 employees)

Non-exempt employees are owed **overtime (1.5×) and minimum wage**; exempt employees are
not. A worker must pass **ALL THREE gates** to be exempt.

### Gate 1 — Salary level
- [ ] Paid at least the federal floor. *(Roughly $684/week ≈ $35,568/year — **verify the current DOL threshold**, it is litigation-prone and several states set a higher floor.)*
- Fail → **non-exempt.**

### Gate 2 — Salary basis
- [ ] Paid a guaranteed minimum salary that is **not docked** for the quality or quantity of work.
- Fail → **non-exempt.**

### Gate 3 — Duties (pick the bucket the job actually fits)
- [ ] **Executive** — supervises 2+ employees, management is the primary duty, has hire/fire influence.
- [ ] **Administrative** — office work directly related to management/operations **and** independent judgment on significant matters. *(Clerical / register work is NOT "administrative.")*
- [ ] **Professional** — advanced-knowledge field: law, medicine, accounting, engineering, IT.
- [ ] None of these fit → **non-exempt.**

**The "everyone's a manager" trap:** title inflation ("Shift Manager," "Operations
Manager") without real exempt duties **fails the duties test.** A $40K "manager" who mostly
staffs the register is non-exempt regardless of title — and the company owes back overtime.

**Classification (Part 2): [ ] Exempt   [ ] Non-exempt (overtime owed)**

---

## Output

- **Final classification:** __________
- **One-line rationale:** __________
- [ ] Borderline on either part → **escalate to employment counsel before you paper this.**
- Keep this completed form on file — documenting classification **at hire** is also the
  Section 530 "consistent treatment" evidence trail.
