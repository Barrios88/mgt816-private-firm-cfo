# Certification Checklist — certify every number before you act on it

> The rule of this domain: **AI drafts; you certify.** Nothing in an output should reach
> a filing, a memo, an investor, or a hire until you have hand-checked it against a current
> authority and can reproduce every figure yourself. Run this checklist before you act.

Item / decision being certified: __________  Date: __________  Certified by: __________

---

## 1. Source every law parameter to a current authority

For each rate, cap, or threshold you relied on, write down where you confirmed it **today**:

| Parameter used | Value used | Source checked | Current? (Y/N) |
|---|---|---|---|
| Corporate rate `t_c` (fed + state) | ____ | ____ | ____ |
| LTCG / dividend rate + NIIT `t_s` | ____ | ____ | ____ |
| QBI eligibility & threshold | ____ | ____ | ____ |
| QSBS regime caps ($50M/$10M vs. $75M/$15M) & date split | ____ | IRS §1202 / OBBBA | ____ |
| SS wage base (~$184,500 for 2026) | ____ | **SSA.gov** | ____ |
| FUTA rate & state credit | ____ | **IRS Pub. 15** | ____ |
| DOL exempt-salary floor (~$684/wk) | ____ | **DOL** (litigation-prone) | ____ |
| State conformity (QSBS, SUI, exempt floor) | ____ | your state | ____ |

**Any parameter you could not confirm today → stamp it `VERIFY` and do not rely on it.**

---

## 2. Hand-recompute every dollar line

- [ ] Every worked figure is reproduced by hand from the formula and inputs — no black boxes.
- [ ] The entity comparison foots: `$100 × (1 − t_ord)` vs. `$100 × (1 − t_c)(1 − t_s)`, and `t_s* = 1 − (1 − t_ord)/(1 − t_c)`.
- [ ] The QSBS exclusion foots: exclusion% × min(gain, cap); taxable remainder at 28%.
- [ ] The misclassification stack foots: 7.65% + 1.53% + 1.5% of wages + FUTA per worker-year.
- [ ] **Every number in your memo exists in your model** — no figure appears in the write-up that you can't point to in the underlying calculation.

## 3. Confirm the state layer

- [ ] State corporate and personal rates used (not just federal).
- [ ] QSBS state conformity checked (several states, e.g. California, do not conform).
- [ ] State SUI, workers' comp, and exempt-salary floor accounted for where relevant.

## 4. State assumptions out loud

- [ ] Every assumed rate, date, and FMV is written down and labeled as an assumption.
- [ ] Time-varying numbers are flagged "verify current-year value," not stated as permanent.

## 5. Log what still needs a professional

| Open item | Who signs off (CPA / corp attorney / 409A firm / employment lawyer) | Asked yet? |
|---|---|---|
| ____ | ____ | ____ |
| ____ | ____ | ____ |

---

**Certification statement:** *I have reproduced every number above from its inputs,
sourced each law parameter to a current authority or stamped it VERIFY, and logged every
item that still needs a professional's sign-off.*  Signed: __________
