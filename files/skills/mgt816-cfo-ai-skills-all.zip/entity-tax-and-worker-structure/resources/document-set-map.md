# The Document Set Map — the company as a stack of paper

> A private company is a stack of legal documents. Know which ones exist and what each
> one governs before you form, hire, or open diligence. At formation you don't need the
> deep term-sheet economics — you need to know the documents exist and defer the economics
> to a financing-round advisor.

---

## The three stacks

| **Company docs** | **Shareholder / investor docs** | **Employee docs** |
|---|---|---|
| **Charter** (Certificate of Incorporation) — *public*, filed with the Secretary of State. Creates the company, authorizes shares, sets the rights and preferences (including liquidation preferences) of each class. | **Cap table + stock ledger** — the legal record of who owns the company (see callout). | **Offer letter** — most employees are **at-will** (no employment contract); senior team is sometimes contracted. |
| **Bylaws** (LLC: **Operating Agreement**) — *internal* operating manual: meetings, notice, quorum, voting, officers. The LLC operating agreement is contract-law-flexible and not public. | **Investor Rights Agreement (IRA)** — pro-rata rights, information/inspection rights, registration rights, board/observer seats, protective provisions (the investor-veto list). | **Confidentiality agreement** — information handling. |
| **Stock / option plan** — the equity incentive plan and its pool. | **Share Purchase Agreement (SPA)** — price and shares, reps & warranties, covenants, and the **disclosure schedule** (the "exceptions list"). False rep → indemnity or price adjustment. | **IP / invention assignment** — the company owns what the employee creates. **Gaps here are a diligence red flag.** |
| **Minutes** — C-corps must keep them; sloppy formalities → veil-piercing → personal liability. | | **Option agreement** with a vesting schedule (vesting matters among **founders**, too). **Non-compete** — fragile: the FTC's 2024 ban was set aside in court, so state law governs (void in CA, restricted in several states). |

---

## Callout — the cap table is a legal record, diligence exhibit #1

The cap table (with the stock ledger) is the **evidence of who owns the company**, and it
is the first thing an acquirer or new investor asks for in every financing and every exit.
Errors **compound**: lost certificates, unsigned 83(b) elections, phantom grants, a
two-year-old handshake promise of 1% to an early engineer that was never papered — all of
it surfaces at diligence, and the **founders/sellers pay** (via escrow, indemnity, or a
re-cut cap table). The legal record governs, not anyone's memory. This is why Carta exists.

---

## CFO practice notes

- Rely on **confidentiality + IP assignment** as the durable protections; treat
  **non-competes as fragile** and jurisdiction-dependent (void in CA; the FTC's 2024
  nationwide ban was set aside, so state law governs).
- Keep **minutes** and observe formalities even at five people — skipped formalities are
  how plaintiffs pierce the corporate veil and reach personal assets.
- Get **IP assignment** signed by **everyone** — founders and contractors included —
  **before** any diligence. Acquirers will re-paper gaps at your expense.
- Term-sheet **economics** (liquidation preferences, pro-rata, participation) are a
  fundraising-round topic. At formation, know the documents exist and what each governs;
  defer the deep economics to a financing-round advisor.
