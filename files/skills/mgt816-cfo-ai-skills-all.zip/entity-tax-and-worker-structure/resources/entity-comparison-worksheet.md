# Entity Comparison Worksheet — C-corp vs. LLC after-tax showdown

> First-pass tax math for the entity box. Fill in your own rates. Every dollar
> figure below the example line is a blank you compute — hand-check each line.
> Confirm state rates and QBI limits with a CPA before you file.

---

## Step 1 — Inputs

| Input | Symbol | Your value | Notes |
|---|---|---|---|
| Owner's marginal ordinary rate | `t_ord` | ____ % | fed + state personal, top marginal |
| Combined corporate rate | `t_c` | ____ % | federal 21% + your state's corporate rate |
| Shareholder rate on the second layer | `t_s` | ____ % | LTCG / qualified-dividend rate + 3.8% NIIT if it applies |
| State | — | ________ | swings both `t_c` and `t_s`; check conformity |
| QBI (§199A) eligible? | Y / N | ____ | if Y, is it an SSTB above the income threshold? (loses QBI) |

If QBI applies and is not phased out, replace `t_ord` in the pass-through column with
`t_ord × (1 − 0.20)`. Write your adjusted rate here: ____ %.

---

## Step 2 — Build both columns (per $100 of pre-tax profit)

| Line | LLC / pass-through | C-corp |
|---|---|---|
| Pre-tax profit | $100.00 | $100.00 |
| Entity-level tax | — (no entity tax) | `−$100 × t_c` = −$____ |
| After entity tax | $100.00 | $____ |
| Owner-level tax | `−$100 × t_ord` = −$____ | `−(after-corp) × t_s` = −$____ |
| **Owner keeps** | `$100 × (1 − t_ord)` = **$____** | `$100 × (1 − t_c)(1 − t_s)` = **$____** |

**Winner:** ________  **Margin per $100:** $____

---

## Step 3 — Rule box

> **Choose pass-through iff `(1 − t_ord) > (1 − t_c)(1 − t_s)`.**
>
> **Indifference shareholder rate:** `t_s* = 1 − (1 − t_ord) / (1 − t_c)`.
> - If actual `t_s` < `t_s*` → C-corp wins the static comparison.
> - If actual `t_s` > `t_s*` → LLC wins the static comparison.

Your `t_s*` = 1 − (1 − ____)/(1 − ____) = ____ %.
Actual `t_s` = ____ % → sits **____** (above / below) indifference → **____** wins the static case.

---

## Step 4 — Break the static frame: the three flip questions

The one-year table above assumes the shareholder layer is paid **this year**. It usually
isn't. Answer these before you decide:

| Flip question | If YES, which way it pushes |
|---|---|
| **Retain & reinvest** — will the company keep and reinvest profits (no dividends for years)? | The second layer is **deferred**; its present value shrinks with the horizon → pushes toward **C-corp**. |
| **QSBS eligible** — will the stock qualify for the §1202 exclusion at exit? | The shareholder layer on the qualified gain goes to **zero** → pushes hard toward **C-corp**. |
| **Early losses + other income** — will you lose money for years while the founder has other (e.g., W-2) income? | Pass-through **losses shelter that other income now**; C-corp losses are trapped as NOLs → pushes toward **LLC**. |

**The asymmetry to remember:** LLC→C-corp is cheap; C-corp→LLC is a **taxable liquidation**
(corporate tax on all appreciation). If no VC is imminent, starting as an LLC keeps the
option open. If VC money is weeks away, form the C-corp now and skip the conversion cost.

---

*This is a first-pass table. Confirm state rates and QBI limits with a CPA before you file.*
