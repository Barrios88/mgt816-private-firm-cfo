# Red Flags & Escalation — when to stop and call the professional

> This skill gets you to the right question and a defensible first-pass number. When the
> decision is real money or hard to reverse, name the professional and hand off. Below:
> the escalation map, and the red flags that should trigger it.

---

## Who to call, and for what

| Professional | Call them for |
|---|---|
| **Corporate attorney** | Filing the charter, drafting bylaws / operating agreement, papering the IRA / SPA, and any actual **entity conversion** (it's a taxable event — don't DIY it). |
| **CPA / tax advisor** | Confirming the QSBS **gross-asset test** and issuance/exercise dates, running the real multi-year after-tax model, **state conformity**, and anything that lands on a return. |
| **409A valuation firm** | Setting or refreshing common-stock FMV. (For the equity-comp mechanics around it — 83(b), ISO/NQSO, AMT — hand off to the equity-comp sibling skill.) |
| **Employment lawyer** | Any **borderline classification**, an existing 1099 population that looks like employees, and any **FLSA exposure** — before you self-report or settle. |
| **Banker / M&A advisor** | Deal-structure and asset **step-up** questions at an exit. (For depth, hand off to the exit-and-M&A sibling skill.) |

---

## Red flags that should trigger escalation

**Entity choice**
- "We'll just switch later." C-corp → LLC is a **taxable liquidation** (corporate tax on all appreciation). Confirm the conversion cost with a corporate attorney and CPA before you assume reversibility.
- Making a decade-long decision off a single-year table without stating the deferral and QSBS assumptions.
- Ignoring state conformity — several states don't follow the federal treatment.

**QSBS §1202**
- Citing the old "$10M / 5-year / $50M" rule for stock **issued after 7/4/25** — establish the issuance (or exercise) date first. Stale web explainers are the predicted #1 error.
- Assuming an **LLC interest or a secondary purchase** qualifies. They never do.
- Waiting to exercise options until **after** the company blows past the asset cap — you lose eligibility an earlier exercise would have captured.
- Treating "federal 100% excluded" as "no tax" without checking **state conformity**.

**Legal documents**
- **IP-assignment gaps** — anyone (founder or contractor) who built product without signing an assignment. Acquirers re-paper this at your expense.
- Relying on a **non-compete** as your main protection — fragile and jurisdiction-dependent (void in CA; the FTC's 2024 ban was set aside). Lean on confidentiality + IP assignment instead.
- Skipped **minutes / formalities** at a C-corp — the route to veil-piercing and personal liability.
- Cap-table drift: lost certificates, unsigned 83(b) elections, unpapered handshake grants.

**Worker classification**
- A "1099 contractor" who works set hours, on company equipment, only for you, on core work → **the label won't survive an audit.**
- Title-inflated "managers" doing non-exempt work → **back-overtime exposure.**
- An existing 1099 population your counsel is now questioning → price the exposure and route to an employment lawyer **before** any self-report.
- Treating **Section 530** or the **§3509** reduced rates as automatic shields — they are narrow and fact-specific; counsel will probe them.

---

## Time-varying numbers to re-verify (never state as permanent)

| Parameter | Source | Note |
|---|---|---|
| SS wage base (~$184,500 for 2026) | SSA.gov | moves annually |
| FUTA rate & state credit | IRS Pub. 15 | credit status varies by state/year |
| DOL exempt-salary floor (~$684/wk) | DOL | litigation-prone; states set higher floors |
| QSBS caps & indexing | IRS §1202 / OBBBA | $75M/$15M indexed for inflation |

Re-check these each January against the source before you rely on any output.
