# Misclassification Exposure Calculator — the federal floor and the multipliers

> If an audit or a lawsuit reclassifies 1099 contractors as W-2 employees, this is
> the federal back-tax **floor**. The real bill is higher — interest, penalties,
> state assessments, and possibly personal officer liability. Route to counsel
> before you self-report or settle.

---

## Inputs

| Input | Your value |
|---|---|
| Number of workers | ____ |
| Wage per worker per year | $______ |
| Number of years exposed | ____ |
| Were 1099s actually filed? | Y / N |
| Were the workers non-exempt (overtime-eligible)? | Y / N |

**Reclassified wages = # workers × wage each × # years = $__________.**
**Worker-years = # workers × # years = ____.**

---

## Federal stack (reduced §3509 rates — assumes 1099s WERE filed)

| Line | Rate / basis | Amount |
|---|---|---|
| Employer FICA | 7.65% of reclassified wages | $______ |
| Employee FICA share (should-have-withheld) | 1.53% of wages (20% × 7.65%) | $______ |
| Failure-to-withhold income tax | 1.5% of wages | $______ |
| FUTA | ~$420 × worker-years (6.0% × $7,000) | $______ |
| **Federal subtotal** | | **$______** |
| **As a % of wages** | subtotal ÷ reclassified wages | ____ % |

The federal floor lands around **~11% of every contractor dollar.**

---

## Multiplier flags (make the bill worse — report these as ranges, not points)

- [ ] **No 1099s filed** → lose §3509 relief → the rates roughly **double.**
- [ ] **Willful misclassification** → up to the full employee-tax liability + penalties + **personal officer exposure** (trust-fund recovery penalty — the CFO personally).
- [ ] **State stack** → state UI, workers' comp, and benefits claims on top of the federal bill.
- [ ] **Non-exempt workers** → FLSA adds **2–3 years of back overtime × double (liquidated) damages + attorney fees.**
- [ ] **Section 530 safe harbor** possible? Consistent 1099 filing + a reasonable basis + consistent treatment can shield the company. It is real but narrow — **counsel will probe this; don't assume it applies.**

---

### Worked example (numbers invented for illustration — not a course answer key)

A startup paid **8 "contractors" $90,000 each for 2 years**. An audit reclassifies them
all as W-2. 1099s *were* filed → reduced §3509 rates apply.
- Reclassified wages = 8 × $90,000 × 2 = **$1,440,000**. Worker-years = 16.
- Employer FICA (7.65%) = **$110,160**.
- Employee FICA share (1.53%) = **$22,032**.
- Income-tax withholding (1.5%) = **$21,600**.
- FUTA ($420 × 16) = **$6,720**.
- **Federal subtotal ≈ $160,512 ≈ 11.1% of wages** — before interest, penalties, state UI, and any FLSA overtime.
- No 1099s filed → roughly **double** it. Non-exempt + overtime → add 2–3 years of back overtime at 1.5× doubled.

**CFO control:** a **written classification policy + counsel review before headcount scales.**

---

*This is a federal-floor estimate. The real bill includes interest, state assessments,
and possibly personal officer liability. Route to counsel before you self-report or settle.*
