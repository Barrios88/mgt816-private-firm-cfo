# QSBS §1202 Eligibility Checklist — six gates → regime → exclusion

> Walk the gates in order. The issuance date picks the regime, and the regime sets
> the caps and holding-period rules. Stock issued via options uses the **exercise**
> date, not the grant date.

---

## Gate 1 — Issuance date → which regime?

| If the stock was issued... | Regime | Gross-asset cap | Dollar exclusion cap | Holding period |
|---|---|---|---|---|
| **on/before July 4, 2025** | Grandfathered | ≤ $50M | greater of $10M or 10× basis | **5-year cliff → 100%** (nothing before 5 yrs) |
| **after July 4, 2025** | OBBBA | ≤ $75M (indexed) | greater of $15M (indexed) or 10× basis | **tiered: ≥3 yrs → 50%, ≥4 yrs → 75%, ≥5 yrs → 100%** |

Issuance (or exercise) date: __________ → **Regime: ____________**

---

## Gate 2 — Is the issuer a domestic C-corp?

- [ ] Yes → continue.
- [ ] No (LLC interest / S-corp stock) → **DISQUALIFIED.** LLC and S-corp equity never qualify.
- Note: an **LLC that converts to a C-corp** can qualify, but the **clock starts at conversion** and the gross-asset test is measured at conversion.

## Gate 3 — Original issuance (not a secondary purchase)?

- [ ] Yes — acquired directly from the company for money, property, or services → continue.
- [ ] No — bought on the secondary market → **DISQUALIFIED.** Secondaries never qualify.

## Gate 4 — Active qualified business?

- [ ] Yes — ≥80% of assets used in a qualified active trade or business → continue.
- [ ] No — an **excluded field**: professional services (health, law, accounting, consulting, financial services, brokerage), banking/insurance/financing, farming, extraction, hospitality (hotels/restaurants) → **DISQUALIFIED.**

## Gate 5 — Gross assets at issuance ≤ the regime's cap?

- Aggregate gross assets **immediately after** the stock was issued: $______.
- Cap for your regime: $50M (grandfathered) / $75M (OBBBA).
- [ ] At or below cap → eligible. [ ] Over cap → this issuance **DISQUALIFIED** (earlier, under-cap issuances keep their status).

## Gate 6 — Holding period at the planned sale → exclusion %

- Holding period from issuance/exercise to sale: ____ years.
- **Grandfathered:** ≥5 yrs → 100%; anything less → **0%**.
- **OBBBA:** ≥3 yrs → 50%; ≥4 yrs → 75%; ≥5 yrs → 100%; under 3 yrs → **0%**.
- Your exclusion %: ____.

---

## Cap calculation

> **Per-issuer cap = greater of { dollar cap ($10M grandfathered / $15M OBBBA) , 10 × your basis }.**

- 10 × basis = 10 × $______ = $______.
- Dollar cap = $______.
- **Cap = $______.**

## Exclusion output

- Realized gain = $______.
- Excluded = exclusion% × min(realized gain, cap) = ____ × min($____, $____) = **$______**.
- **Taxable gain = realized gain − excluded = $______**, taxed at the **28% §1202 rate class** (not the 20% LTCG rate).
- **State layer flag:** does your state conform to §1202? Several (e.g., California) do **not**, so "federal $0" is not "total $0." State treatment: __________.

---

### Worked example (numbers invented for illustration — not a course answer key)

Founder buys original C-corp stock in **Aug 2026**, basis **$500**, gross assets **$3M** at
issuance → OBBBA regime, eligible. Sells **2032** (>5 yrs) for an **$18M** gain.
- Cap = greater of $15M or 10 × $500 = $5,000 → **$15M**.
- ≥5 yrs → 100% of the capped amount.
- **Excluded = $15M; taxable = $3M** at 28% (plus state).
- Sold at year 3 instead → only **50%** excluded under the tiers.

---

*QSBS is worth six or seven figures and is easy to blow. Have a CPA confirm the asset
test and issuance dates before you rely on this.*
