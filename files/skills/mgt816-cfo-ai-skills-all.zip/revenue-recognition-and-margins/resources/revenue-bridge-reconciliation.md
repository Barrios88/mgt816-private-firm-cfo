# Revenue Bridge Reconciliation (worksheet)

Use this when "sales says X, the model says Y, and the auditor says Z." Locate each
number on the spine before arguing about it — most disagreements are just two people
quoting different nodes.

    BOOKINGS  ──►  BILLINGS  ──►  GAAP REVENUE  ──►  DEFERRED REVENUE
    (signed        (invoiced      (delivered +          (cash in for work
     TCV)           this period)   collectible)          not yet performed)

    Period identity:  BILLINGS = REVENUE + Δ DEFERRED REVENUE

---

## Fill-in table

| Node | Definition | This period ($) | Source / who quotes it |
|---|---|---|---|
| Bookings (TCV) | Signed commitment, whole contract | ____________ | Sales / CRM |
| Billings | Invoiced this period | ____________ | Billing system |
| GAAP revenue | Delivered + collectible | ____________ | GL / audited |
| Δ Deferred revenue | End DR − Beg DR | ____________ | Roll-forward |
| Ending deferred revenue | Cash in, not yet earned | ____________ | Balance sheet |

**Tie test:** Billings − Revenue − Δ Deferred Revenue = **0** ? ☐ TRUE  ☐ FALSE

---

## Worked example (numbers invented for this skill, illustrative)

A customer signs a **$900,000 TCV** three-year deal. This year you **billed $300,000**,
**recognized $220,000** of GAAP revenue, and the rest sits in deferred revenue.

| Node | This period ($) |
|---|---|
| Bookings (TCV) | 900,000 |
| Billings | 300,000 |
| GAAP revenue | 220,000 |
| Ending deferred revenue (Δ from 0) | 80,000 |

**Tie test:** 300,000 − 220,000 − 80,000 = **0** → TRUE. The $600,000 gap between the
$900,000 headline "bookings" and the $300,000 billed is unbilled future-year TCV — real,
but not this year's revenue. The $80,000 gap between billed and recognized is prepaid
cash you still owe as service — a liability, not income.

---

## Diagnostic ratios (separate illustrative contract)

Take a three-year contract with **$280,000 ARR** (recurring) plus a **$60,000** one-time
onboarding fee in Year 1.
- ACV Year 1 = 280,000 + 60,000 = **$340,000**
- TCV = 280,000 × 3 + 60,000 = **$900,000**

| Ratio | Formula | Value | Read |
|---|---|---|---|
| ARR : ACV (Y1) | 280,000 ÷ 340,000 | **0.82** | Below 1 → one-time fees inflate Y1; recurring base is smaller than the headline |
| TCV : ARR | 900,000 ÷ 280,000 | **3.21** | > 1 → long contract (durability) OR one-time-heavy (quality question) — look to tell which |

**Red flag:** anyone annualizing the $60,000 one-time onboarding into ARR. ARR is $280,000,
not $340,000. Strip one-time fees before you quote a recurring-revenue growth number.

---

CERTIFICATION (human must confirm before this is final):
- [ ] Each figure placed on the correct node (bookings / billings / revenue / deferred)
- [ ] The period identity ties: Billings = Revenue + Δ Deferred Revenue
- [ ] Recognized revenue traces to contract terms and delivery evidence
- [ ] Any "ARR" quoted excludes one-time fees
