# Revenue Recognition Policy Memo (template)

The written policy an auditor and a diligence team both ask for first. Fill each section
for YOUR company. Keep it current as GAAP and the business evolve. Draft with AI if you
like — but every judgment and number here is human-certified.

**Company:** ________________________
**Prepared by:** ________________________   **Date:** ________________________
**Approved by (CFO / controller):** ________________________
**Reviewed with (CPA / auditor):** ________________________

---

## 1. Scope and contract types

Which revenue streams and contract types this policy covers (e.g., SaaS subscriptions,
usage-based, professional services, hardware, marketplace/platform fees).

> ________________________________________________________________

---

## 2. Five-step treatment, by contract type

Complete the ASC 606 five-step analysis for each material contract type. Attach a filled
`asc606-five-step-scorecard.md` per type.

| Contract type | Step 1: contract & collectability | Step 2: performance obligations (distinct?) | Step 3: transaction price (variable consideration?) | Step 4: SSP allocation basis | Step 5: timing (PIT / over time) |
|---|---|---|---|---|---|
|  |  |  |  |  |  |
|  |  |  |  |  |  |

---

## 3. Deferred-revenue policy

How prepaid/annual contracts are booked and released; roll-forward cadence; where the
balance sits (current vs. long-term). Reference `deferred-revenue-rollforward.csv`.

> ________________________________________________________________

The identity that must hold every period: `Billings = Revenue + Δ Deferred Revenue`.

---

## 4. Gross vs. net (principal vs. agent) position

State the position and the control rationale for any pass-through / marketplace / reseller
revenue. Reference `gross-vs-net-decisiontree.md`. If you report net, state how GMV (if
any) is disclosed separately as a KPI.

> ________________________________________________________________

---

## 5. Commission capitalization policy and amortization period

Whether incremental costs of obtaining a contract are capitalized, and the benefit period
used to amortize them (expected customer life / contract term). Reference
`margin-ladder-and-cost-perimeter.md`.

> ________________________________________________________________

---

## 6. Significant judgments and estimates

The places where this policy relies on estimation — variable-consideration constraint,
SSP estimates, whether promises are distinct on customized deals, collectability calls.
Name them so an auditor sees you saw them.

> ________________________________________________________________

---

## 7. Questions for our auditor / CPA

Open items to resolve with a professional before this policy is final. Escalate here:
material variable consideration, ambiguous "distinct" calls, principal-vs-agent where
control is genuinely unclear, and anything hitting audited financials or a data room.

- [ ] ________________________________________________________________
- [ ] ________________________________________________________________
- [ ] ________________________________________________________________

---

CERTIFICATION (human must confirm before this policy is adopted):
- [ ] Every contract type mapped through all five ASC 606 steps
- [ ] Deferred-revenue mechanic ties every period
- [ ] Gross/net position matches the control analysis, not desired optics
- [ ] Commission amortization period matches expected customer life
- [ ] Significant judgments disclosed; open items escalated to a CPA/auditor
