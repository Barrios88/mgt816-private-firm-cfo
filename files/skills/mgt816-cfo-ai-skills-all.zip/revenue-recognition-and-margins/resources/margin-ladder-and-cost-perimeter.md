# Margin Ladder & Cost-of-Revenue Perimeter (reference card)

The gross-margin formula is trivial. The whole fight is **what goes in Cost of Revenue.**

    GM% = (Revenue − Cost of Revenue) / Revenue

---

## Cost-of-revenue perimeter (IN vs. OUT)

| IN Cost of Revenue (above the line) | OUT — lives below the line |
|---|---|
| Materials / merchandise | S&M salaries, advertising |
| Production & service-delivery labor + overhead | R&D / engineering building the product |
| Hosting / data-center (SaaS) | G&A, corporate IT |
| Support personnel | Professional fees |
| Professional-services delivery staff | (These sit in operating expense) |
| Amortization of capitalized software | |

*Matching principle:* recognize a cost in the period of the revenue it helped earn.

**Benchmark (public history):** software runs ~**80%** gross margin — that is *why*
software multiples exist. Retail / CPG / services run far lower. Cite any benchmark with
a source or stamp it UNVERIFIED.

---

## Gross margin vs. contribution margin

| | Gross Margin (GM) | Contribution Margin (CM) |
|---|---|---|
| Formula | Revenue − Cost of Revenue | Revenue − ALL variable costs |
| Fixed costs | Can carry fixed production overhead | Strips **every** fixed cost |
| Variable costs below GP line (e.g. variable S&M, payment processing) | Excluded | **Included** |
| Lens | Reporting / GAAP | Per-unit economics |

**CM ≠ GM. Never quote one as the other.** CM feeds unit economics — CAC payback and LTV.

---

## The margin ladder

    Gross Margin  →  Operating Margin  →  Net Profit Margin
    (after COGS)     (after all opex)     (after everything: interest, tax)

Always know which rung a number is on before you compare it to anything.

---

## Commission capitalization (ASC 606 / Topic 606, periods after Dec 15, 2017)

Historically, sales commissions were expensed in the quarter of sale — terrible matching
on a multi-year contract. Now:

- An **incremental cost of obtaining a contract** (a commission you'd pay ONLY if the
  deal closed) is **capitalized as an asset**, then **amortized over the benefit period**
  (expected customer life / contract term).
- The balance sheet grows a **"deferred commissions" asset** that mirrors the
  deferred-revenue liability.

**Worked example (numbers invented for this skill, illustrative):** a **$72,000**
commission on a **3-year** contract.
- Capitalize $72,000 as a deferred-commission asset at close.
- Amortize $72,000 ÷ 3 = **$24,000/year**.
- **$24,000** hits this year's P&L (as amortization inside the S&M line), NOT $72,000.

| Year | Beginning asset | Amortization | Ending asset |
|---|---|---|---|
| 1 | 72,000 | 24,000 | 48,000 |
| 2 | 48,000 | 24,000 | 24,000 |
| 3 | 24,000 | 24,000 | 0 |

**Red flag:** a SaaS P&L expensing full commissions in the booking quarter — it
understates early-cohort profitability and misstates margins.

---

CERTIFICATION (human must confirm before this is final):
- [ ] Cost-of-revenue perimeter stated explicitly (what's IN vs. OUT)
- [ ] GM and CM labeled correctly — not quoted interchangeably
- [ ] Each margin identified by rung (GM / OM / NPM)
- [ ] Commission amortization period matches the expected customer life
- [ ] Any benchmark cited is sourced or stamped UNVERIFIED
