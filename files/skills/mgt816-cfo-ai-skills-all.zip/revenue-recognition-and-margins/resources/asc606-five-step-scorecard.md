# ASC 606 Five-Step Scorecard (fillable)

Run the five steps in order on ONE contract. Each step is a gate — if a step fails,
stop and resolve it before recognizing revenue.

**Contract name / ID:** ________________________
**Effective date:** ________________________
**Counterparty:** ________________________
**Prepared by:** ________________________   **Date prepared:** ________________________

---

## Step 1 — Is there a contract? (and will they pay?)

Check all five criteria. All must be YES to have a contract under ASC 606.

- [ ] Parties have approved the contract and are committed to perform
- [ ] Each party's rights to the goods/services are identifiable
- [ ] Payment terms are identifiable
- [ ] The contract has commercial substance
- [ ] **Collection is probable** (the collectability gate)

**Collectability evidence** — selling to a shaky counterparty (early-stage startup,
at-risk retailer)? What is your evidence collection is probable?
> ________________________________________________________________

*No written contract (startup reality):* recognize only when consideration is
**received AND nonrefundable AND** performance is **complete or terminated**.

**Step 1 verdict:** ☐ Pass  ☐ Fail — why: ______________________________

---

## Step 2 — Performance obligations (what am I obligated to deliver?)

A promise is a **distinct** obligation only if BOTH are true:
(a) the customer can benefit from it on its own (or with readily available resources), AND
(b) it is **separately identifiable** from the other promises.

*Not separately identifiable* if any of these flags fire:
- [ ] Significant integration of the items into a combined output
- [ ] Significant customization or modification of one item by another
- [ ] Items are highly interdependent / highly interrelated

If a promise is NOT distinct, combine it with others until the bundle is distinct;
recognize a non-distinct bundle only when ALL of it is delivered.

| # | Promised good / service | Can benefit on its own? (Y/N) | Separately identifiable? (Y/N) | **Distinct?** (Y/N) |
|---|---|---|---|---|
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |

---

## Step 3 — Transaction price (how much will I earn?)

Transaction price = expected consideration, **excluding amounts collected on behalf of
third parties** (sales tax, a merchant's cut).

- Gross consideration: $____________
- Less third-party amounts (sales tax, pass-through): $____________
- **Transaction price:** $____________

Adjust for the four modifiers:
- [ ] **Variable consideration** (rebates, refunds, concessions, volume discounts,
      performance bonuses, royalties, make-goods)
  - Estimation method: ☐ Expected value  ☐ Most likely amount
  - Constrained amount (include only to the extent a significant reversal is NOT probable): $______
- [ ] Significant financing component
- [ ] Noncash consideration
- [ ] Consideration payable back to the customer

---

## Step 4 — Allocate the price by relative standalone selling price (SSP)

Best evidence of SSP = the price when the item is sold separately; otherwise a
documented management estimate. "Free" elements still get an SSP — do NOT allocate $0.

| Obligation | SSP ($) | SSP % of total | Allocated transaction price ($) |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
| **Total** | **(sum SSP)** | **100%** | **(= transaction price)** |

*Allocated $ = Transaction price × (obligation SSP ÷ total SSP). Allocated column must
sum to the Step 3 transaction price.*

---

## Step 5 — Timing (point-in-time vs. over time)

Recognize **over time** if ANY one holds:
- [ ] Customer simultaneously receives and consumes the benefit (e.g., SaaS subscription)
- [ ] Customer controls the asset as it is created/enhanced
- [ ] Asset has no alternative use AND you have an enforceable right to payment for work to date

Otherwise **point in time** — at the moment control transfers.

| Obligation | PIT or Over-time | Recognition period / trigger |
|---|---|---|
|  |  |  |
|  |  |  |
|  |  |  |

---

## Recognition-schedule stub

| Period | Obligation | Revenue recognized | Cumulative | Deferred remaining |
|---|---|---|---|---|
|  |  |  |  |  |
|  |  |  |  |  |

---

CERTIFICATION (human must confirm before this is final):
- [ ] Every figure traces to a contract term or billing record
- [ ] Collectability judged probable (Step 1 gate)
- [ ] SSP allocation uses defensible standalone prices, not plugs
- [ ] Timing per obligation matches the control/consumption analysis
- [ ] Escalated to CPA/auditor if variable consideration is material or "distinct" is genuinely ambiguous
