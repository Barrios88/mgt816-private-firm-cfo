# Gross vs. Net (Principal vs. Agent) — One-Pager

The question: is the whole transaction value YOUR revenue, or just the fee you keep?
The answer turns on one word: **control**.

    Do you control the good/service BEFORE it transfers to the customer?
      │
      ├─ YES → PRINCIPAL → report GROSS (whole price is revenue)
      │
      └─ NO  → AGENT → report NET (only your fee / take rate is revenue)

---

## Control indicator scoresheet

Score each. More YES → principal (gross); more NO → agent (net). No single box is
decisive; weigh them together and document the call.

| Indicator | You? (Y/N) | Points toward |
|---|---|---|
| You hold inventory / bear inventory risk | ____ | Gross (principal) |
| You set the price to the customer | ____ | Gross (principal) |
| You are primarily responsible for fulfillment | ____ | Gross (principal) |
| You bear credit risk on the customer | ____ | Gross (principal) |
| You merely arrange for another party to provide it | ____ | Net (agent) |

**Verdict:** ☐ Principal → GROSS   ☐ Agent → NET

---

## Compute revenue BOTH ways (and note GP dollars don't move)

Presentation moves the revenue line and every margin **percentage** — it does NOT move
gross-profit **dollars**. Always show both so no one is fooled by the optic.

| | Gross view | Net view |
|---|---|---|
| Revenue | Whole transaction value | Your fee only (take rate × GMV) |
| Cost of revenue | Amount paid to the third party | ~0 (already netted) |
| **Gross profit ($)** | **Same** | **Same** |
| Gross margin (%) | Low | High |

---

## GMV and take rate

**GMV (Gross Merchandise Value)** = total value transacted through the platform. It is a
**growth KPI for a marketplace, NOT revenue.** An agent's revenue is `take rate × GMV`.

*Illustrative take rates (public history):* Amazon marketplace books ~8% of GMV as
service revenue; eBay ~3%. Amazon's own retail owns inventory → for that business GMV
IS revenue.

---

## Worked example (numbers invented for this skill, illustrative)

A marketplace facilitates a **$50,000 GMV** month and keeps a **6% take rate**. It holds
no inventory, does not set the seller's price, and is not the fulfillment obligor → **agent → net**.

| | Gross view (WRONG here) | Net view (correct) |
|---|---|---|
| Revenue | 50,000 | 6% × 50,000 = **3,000** |
| Cost of revenue | 47,000 (paid to sellers) | 0 |
| **Gross profit ($)** | **3,000** | **3,000** |
| Gross margin (%) | 6% | 100% |

Same $3,000 of gross profit either way. The gross view just inflates the top line 16.7×
and drops the margin — which is exactly why grossing up is tempting and why sophisticated
investors re-derive GMV and the take rate anyway.

**Cautionary history (public record):** the SEC made Groupon restate H1-2011 revenue
**$1.52B → $688M** for reporting gross when it was acting as an agent. The restatement
changed zero economics and cost a lot of credibility. Report net; disclose GMV separately
as a clearly labeled KPI.

---

## Red flags

- "Managed revenue," "gross billings," "transaction volume" placed where a reader hears
  "revenue." Label it, define it, reconcile it.
- "Revenue" growth that is really GMV growth at a **falling** take rate.
- Gross presentation showing an 80%+ "gross margin" on a business that clearly holds no
  inventory — a tell it should probably be net.

**Escalate to a CPA/auditor** when control is genuinely ambiguous (unusual fulfillment,
pricing, or credit-risk terms), before this hits audited financials or a data room.

---

CERTIFICATION (human must confirm before this is final):
- [ ] Gross/net matches the control analysis, not the desired optics
- [ ] Revenue shown BOTH ways; gross-profit dollars identical
- [ ] GMV disclosed separately and labeled as a KPI, not revenue
- [ ] Any cited take rate is sourced or stamped UNVERIFIED
