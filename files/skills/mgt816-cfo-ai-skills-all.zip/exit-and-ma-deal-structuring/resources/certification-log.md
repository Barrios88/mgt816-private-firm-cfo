# Certification Log

**AI drafts; you certify every number.** One row per load-bearing number in any
deal memo — the peg true-up, the step-up shield, the after-tax comparison, the
earn-out tiers, the IPO cost tally. A number without its arithmetic is worthless
in diligence; a number nobody recomputed by hand is a liability.

Copy this table into every deal memo. Do not present a computed figure as final
until its row is signed.

---

## How to use it

1. Enter every figure the memo relies on — one row each.
2. Write the **formula and the inputs**, not just the result.
3. **Recompute it by hand** (or in a fresh sheet) and record how.
4. A human names themselves in **Verified by** — that is the certification.
5. If a row is not yet independently recomputed, mark **UNVERIFIED? = YES** and do
   not rely on the number until it is cleared.

---

## The log

| # | Number produced | Formula / source | How I recomputed it | Verified by (human) | UNVERIFIED? |
|---|---|---|---|---|---|
| 1 | Adjusted closing NWC `[$__]` | `(CA − excess cash) − (CL − seller-repaid debt)` | Re-added each component from the closing balance sheet | `[name]` | YES / no |
| 2 | Price adjustment `[$__]` | `Adjusted NWC − Peg` | Checked sign: above peg → buyer pays more | `[name]` | YES / no |
| 3 | Step-up `[$__]` | `price allocated to assets − old net tax basis` | Confirmed step-up ≤ price | `[name]` | YES / no |
| 4 | Tax shield (undiscounted) `[$__]` | `step-up × blended rate` | Confirmed rate source; undiscounted ≠ PV | `[name]` | YES / no |
| 5 | After-tax proceeds (stock) `[$__]` | `price − (gain × cap-gains rate)` | Recomputed gain from stock basis | `[name]` | YES / no |
| 6 | After-tax proceeds (asset, C-corp) `[$__]` | two layers: corporate then shareholder | Recomputed both layers separately | `[name]` | YES / no |
| 7 | `[add rows as needed]` | | | | |

---

## Certification ethic (why this exists)

Every computed figure ships with its formula and inputs so it can be recomputed by
hand. The skill builds the **muscle** to recompute — it never replaces it. When in
doubt, the human who signs the deal owns the number, not the tool that drafted it.

**Escalate any UNVERIFIED row that is load-bearing** to the relevant human before
close: M&A counsel (SPA terms), CPA / tax attorney (tax figures), banker
(valuation), auditor (historical financials).
