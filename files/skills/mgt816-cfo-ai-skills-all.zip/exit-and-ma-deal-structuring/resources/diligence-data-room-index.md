# Diligence Data-Room Index

A starter folder tree for a sell-side diligence data room, organized by the six
standard scope areas. Populate it in a **restricted** room with a view audit
trail (who saw what, when). Stage sensitive folders so the crown jewels release
late and only under NDA — protect against tire-kickers.

A fundraising data room that was kept current matures naturally into an M&A data
room. The seller who kept it live sells faster and leaks less.

> **Certify before you use this.** Tailor the document list to your company and
> deal; confirm what must be redacted with counsel before release.

---

## 00 — Process & administration
- Master NDA and executed counterpart log
- Data-room index and access/permission matrix
- Diligence request tracker (open / answered / disputed)

## 01 — Organization & corporate
- Certificate of incorporation / formation, bylaws / operating agreement
- Cap table (fully diluted), option ledger, SAFE/convertible register
- Board and shareholder minutes and consents
- Subsidiary structure chart; foreign qualifications
- Equity plan documents and grant agreements

## 02 — Commercial
- Top-customer contracts and concentration schedule
- Pipeline / bookings and churn/retention data
- Pricing, discounting, and rebate policies
- Marketing materials and competitive positioning
- Supplier / vendor agreements and concentration

## 03 — Finance & accounting
- Audited / reviewed financial statements (all periods available)
- Monthly management accounts and board packages
- Trial balance, GL detail, chart of accounts
- **Working-capital history** (monthly NWC, by component — feeds the peg)
- AR aging, inventory detail (with sell-through), AP aging
- Debt schedule and payoff letters; cash and excess-cash analysis
- Budget / forecast and variance analysis
- Revenue-recognition policy memo; accounting-policy manual

## 04 — Legal, regulatory & HR
- Litigation and claims schedule; demand letters
- Material contracts with change-of-control / assignment clauses
- IP register: patents, trademarks, domains, key licenses
- Regulatory licenses, permits, and compliance history
- Employee census, comp bands, key-employee agreements
- Benefit plans; contractor classifications; open HR matters

## 05 — Operations
- Facilities, leases, and equipment schedule
- Production / delivery process documentation
- Quality metrics, warranty and returns history
- Business-continuity and insurance summary

## 06 — IT, data & environmental
- Systems architecture and key-application inventory
- Cybersecurity posture, incident history, data-privacy compliance
- Data-processing agreements and PII map
- Environmental permits, assessments, and any remediation history

---

## Staging guidance

| Stage | Release when | Contents |
|---|---|---|
| Tier 1 (early) | NDA signed | Summary financials, org overview, redacted contracts |
| Tier 2 (post-IOI) | Serious buyer, IOI in hand | Detailed financials, WC history, customer schedules (anonymized) |
| Tier 3 (post-LOI) | Exclusivity signed | Named customer contracts, IP detail, employee census, crown jewels |

**Escalate:** M&A counsel for redaction and clean-team protocols; auditor for the
financial statements buyers will scrutinize.
