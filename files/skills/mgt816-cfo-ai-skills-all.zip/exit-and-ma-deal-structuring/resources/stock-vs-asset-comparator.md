# Stock vs. Asset Sale Comparator

A side-by-side decision sheet for the tax structure that moves headline price by
millions. All rates and dollar figures below are `[INVENTED EXAMPLE]` — clearly
labeled illustrations, **not** benchmarks or real comps. Run your own basis and
rates with your CPA before deciding.

> **Certify before you use this.** The purchase-price allocation, the actual
> blended rate, and the entity-level tax treatment are CPA / tax-attorney terrain.
> Draft the business logic; do not file the election.

---

## The core contrast

| | **Stock sale** | **Asset sale (C-corp seller)** |
|---|---|---|
| Layers of tax to the seller | **One** (capital gains) | **Two** (corporate-level, then shareholder-level) |
| Buyer inherits basis? | Yes — inherits target's old basis (and liabilities) | No — buyer gets a **step-up** |
| Who tends to prefer it | Seller (esp. C-corp) | Buyer (gets the shield) |

Buyers often prefer assets because of the **step-up**; C-corp sellers resist
because of the **double tax**. The spread between the two headline prices is
negotiated, like everything else.

---

## Worked side-by-side (INVENTED EXAMPLE)

**Assumptions (invented, confirm your own):** shareholders' aggregate stock basis
$14M; target's net asset tax basis $18M; shareholder capital-gains rate 20%;
corporate rate 21%; buyer's blended rate 25%.

The buyer offers **$60M as a stock deal** *or* **$62M as an asset deal** (the
extra $2M is the buyer sharing part of its step-up value).

### Stock deal @ $60M (one layer)
```
Shareholder gain = $60M − $14M basis      = $46M
Capital-gains tax = $46M × 20%            = $9.2M
Net after-tax to sellers = $60M − $9.2M   = $50.8M
```

### Asset deal @ $62M (two layers, C-corp)
```
Layer 1 — corporate:
  Corporate gain = $62M − $18M asset basis = $44M
  Corporate tax  = $44M × 21%              = $9.24M
  Cash left in corp = $62M − $9.24M         = $52.76M

Layer 2 — shareholder (liquidating distribution):
  Shareholder gain = $52.76M − $14M basis  = $38.76M
  Capital-gains tax = $38.76M × 20%        = $7.752M
  Net after-tax to sellers = $52.76M − $7.752M = $45.008M ≈ $45.0M
```

**Result:** the stock deal nets the sellers **$50.8M** vs. **$45.0M** for the
asset deal — the **$2M headline premium does not cover the corporate-level layer**
for a C-corp. *(Illustrative only.)*

---

## Buyer's step-up shield (why the buyer can afford to bid more)

```
Step-up = purchase price allocated to assets − target's old net tax basis
Undiscounted future tax shield ≈ step-up × buyer's blended rate
   (goodwill / intangibles amortize over ~15 years for tax)
PV of the shield < undiscounted amount (discount the 15-year stream)
```

**On the $62M asset deal (INVENTED EXAMPLE):**
```
Step-up = $62M − $18M           = $44M of new amortizable basis
Undiscounted shield = $44M × 25% = $11.0M
PV over ~15 years                ≈ $6–7M
```
*(Illustrative only — the real number depends on the asset allocation and the
buyer's actual rate.)*

---

## Entity-type modifier

| Seller entity | Entity-level layer on an asset deal? | Consequence |
|---|---|---|
| **C-corp** | **Yes** — double tax | Seller resists asset deals; premium rarely covers the corporate layer |
| **S-corp / LLC** | **No (generally)** | Buyer can get a step-up **without** double tax — a win-win |

This is why PE prefers LLC / S-corp targets, and why entity choice at formation
has a decade-long tail.

---

## The "ask a tax attorney" flag

For certain **stock** deals, a **§338(h)(10)** or **§336(e)** election can make the
deal be **treated as an asset deal** for tax — delivering the buyer's step-up on a
stock-deal legal structure. **Name it, then route to a tax attorney to execute.**
Also flag any QSBS interaction.

**Escalate:** CPA / tax attorney (after-tax comparison, purchase-price allocation,
§338(h)(10)/§336(e), QSBS); M&A counsel (deal documents).
