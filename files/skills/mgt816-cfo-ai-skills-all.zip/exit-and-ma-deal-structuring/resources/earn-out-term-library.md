# Earn-Out, Seller-Note & Rollover Term Library

Building blocks for the three instruments that bridge a price gap. Match the
instrument to the **type of disagreement**: liquidity gap → seller note;
valuation gap on future performance → earn-out; alignment / sponsor confidence →
rollover. All figures marked `[INVENTED EXAMPLE]` are illustration only.

> **Certify before you use this.** These are business-logic skeletons, not legal
> instruments. The metric definition and the accounting-policy language are where
> earn-out disputes are won or lost — get M&A counsel to paper them.

---

## 1. Earn-out (contingent consideration on post-close performance)

Use when the seller thinks it's worth more and the buyer won't pay for unproven
upside. Sellers dislike it: **price at risk without control.** Disputes are the
norm — so define everything.

**The metric choice is everything.**

| Metric | Seller's exposure | When it favors the seller |
|---|---|---|
| **Revenue** | Lowest manipulation risk | Seller has lost control of costs post-close |
| **Gross profit** | Moderate | Cost of sales is stable and definable |
| **EBITDA** | **Highest** — buyer controls cost allocations, overhead pushdowns | Only with tight P&L-control and policy locks |

Post-close the buyer controls the P&L. Earn-out on **revenue** beats earn-out on
**EBITDA** for a seller who has lost cost control, because EBITDA can be gamed
through allocations.

**Threshold / tier skeleton (INVENTED EXAMPLE):**

| Tier | Trigger (measurement-period metric) | Payout |
|---|---|---|
| Floor | Below `[$22M revenue]` | $0 |
| Tier 1 | `[$22M–$26M]` | `[$2.1M]` |
| Tier 2 | Above `[$26M]` | `[$2.4M]` (max `[$4.5M]`) |

**Must-have definitions (checklist):**
- [ ] **The metric**, computed to the line — inclusions, exclusions, adjustments.
- [ ] **Measurement period(s)** — single vs. staged (e.g., two annual measures).
- [ ] **Who controls the P&L** post-close and what they may not reallocate.
- [ ] **Accounting policies** frozen to the closing-date basis (no policy drift).
- [ ] **Audit rights** for the seller over the earn-out computation.
- [ ] **Dispute resolution** — named neutral accountant, capped to the earn-out.
- [ ] **Acceleration / change-of-control** treatment if the buyer resells.

**Tax flag:** installment-sale-flavored, but messier with uncertain payoffs —
route to the CPA.

---

## 2. Seller note (buyer pays part of the price over time + interest)

Use when the buyer has a liquidity gap or the seller wants to signal confidence.

**Term skeleton (INVENTED EXAMPLE):**
- Principal: `[$3.0M]` of a `[$__M]` purchase price
- Interest rate: `[8%]` fixed
- Term / amortization: `[4 years]`, `[interest-only then balloon / straight-line]`
- Default provisions: `[cure period, acceleration, remedies]`
- **Subordination:** **junior to the buyer's senior bank debt.** If the buyer
  levered up to do the deal, this note is real credit risk. (Search-fund / ETA
  reality: many operators sign one — know exactly how junior you are.)
- Security / guarantees: `[personal guaranty? collateral? none?]`

---

## 3. Rollover equity (seller / management rolls a slice into NewCo)

The PE sponsor wants this: it aligns incentives, signals confidence, and reduces
the sponsor's cash out. Management gets a **"second bite of the apple"** at the
next liquidity event.

**Term skeleton (INVENTED EXAMPLE):**
- Rollover %: `[15%]` of proceeds rolled into NewCo equity
- Valuation basis: `[rolled at the same per-unit price as the sponsor]`
- Security class: `[common / preferred alongside sponsor]`
- **Tag-along / drag-along** rights: `[tag on secondary sales; subject to drag]`
- Board seat: `[1 seat / observer / none]`
- Second-bite mechanics: monetized only at the **next exit** — illiquid and junior

**Both truths at once:** rollover can be the best-returning position in the deal
**if the sponsor wins** — and it is **illiquid and junior**, monetized only at the
next exit. Rollover holders often keep board seats and interact with the
management incentive pool.

---

**Decision rule to state out loud:** *What kind of disagreement is this?*
Liquidity gap → seller note. Valuation gap on future performance → earn-out (on
the right metric). Alignment / sponsor confidence → rollover. Price gap the buyer
simply won't close → some blend, with escrow.

**Escalate:** M&A counsel (metric definitions, subordination, tag/drag, board
rights); CPA / tax attorney (installment-sale and rollover tax treatment).
