# Working-Capital Peg Workbook

A fill-in worksheet for computing and negotiating the working-capital (NWC) peg
and closing true-up. Every dollar figure below marked `[INVENTED EXAMPLE]` is a
placeholder for illustration only — it is **not** a benchmark, a comp, or a
course answer. Replace it with your own source figures and recompute by hand.

> **Certify before you use this.** Confirm the SPA's NWC definition, the peg
> basis, and every reserve policy against source documents. AI drafts; you
> certify every number.

---

## (a) NWC definition builder — which line items are IN or OUT

Price is set **cash-free / debt-free**. The seller keeps excess cash and repays
funded debt; the buyer prices the enterprise. Decide each line item explicitly —
the SPA's definitions section is where the CFO drafts with counsel.

| Line item | In NWC? | Notes / rule |
|---|---|---|
| Accounts receivable (net of reserve) | IN | Aging-based reserve; consistency rule applies |
| Inventory | IN | At lower of cost or NRV (LCNRV) |
| Prepaid expenses | IN (usually) | Only operating prepaids per SPA |
| Other operating current assets | IN (per SPA) | Define explicitly |
| **Excess / non-operating cash** | **OUT** | Seller keeps it — remove from asset side |
| Operating cash float (if any) | IN (if agreed) | Only the minimum the business needs |
| Accounts payable | IN | |
| Accrued liabilities | IN | Payroll, taxes, warranty, etc. |
| **Funded debt the seller repays at close** | **OUT** | Remove from **liability** side |
| Deferred revenue | Per SPA | Contentious — negotiate explicitly |
| Income taxes payable | Per SPA | Often carved out |

**Cash-free / debt-free toggle:** `[ ] cash-free/debt-free  [ ] cash-and-debt-included`
(This workbook assumes cash-free/debt-free — the market default.)

---

## (b) Trailing-average grid — how the peg NUMBER gets set

The peg is usually a trailing average or a projected close-level. It is
subjective, therefore contentious. Fill in each basis, then note where close
sits in the seasonal cycle.

| Basis | NWC level | Notes |
|---|---|---|
| Trailing 12 months (T12M) avg | `[INVENTED EXAMPLE: $2.18M]` | Full seasonal cycle |
| Trailing 6 months (T6M) avg | `[INVENTED EXAMPLE: $2.34M]` | |
| Trailing 3 months (T3M) avg | `[INVENTED EXAMPLE: $2.47M]` | |
| Projected NWC at close date | `[INVENTED EXAMPLE: $2.02M]` | The principled basis |
| **Proposed peg** | `[INVENTED EXAMPLE: $2.0M]` | |

**Seasonality note field:** _Where does the close date sit in the cycle?_
`[ ] seasonal trough   [ ] mid-cycle   [ ] seasonal peak`

- If close sits at a **trough** and the peg uses a full-cycle (T12M) average, the
  peg is **above** actual closing NWC → the true-up systematically transfers price
  to the **buyer**.
- If close sits at a **peak**, it reverses and favors the **seller**.
- **Principled peg ≈ expected NWC at the close date, on the agreed basis** — or
  add a collar (section d/e).

---

## (c) True-up computation block

```
Adjusted closing NWC = (Current assets − excess cash the seller keeps)
                     − (Current liabilities − seller-repaid funded debt)

Price adjustment = Adjusted closing NWC − Peg
   > 0  → closing NWC above the peg → buyer PAYS MORE
   < 0  → closing NWC below the peg → price comes DOWN
```

**Worked fill (INVENTED EXAMPLE — buyer "Northwind" / target "Palmetto"):**

| Input | Amount |
|---|---|
| Current assets (gross) | $9.5M |
| less: excess cash seller keeps | ($0.4M) |
| **Adjusted current assets** | **$9.1M** |
| Current liabilities (gross) | $6.5M |
| less: seller-repaid bank loan | ($0.7M) |
| **Adjusted current liabilities** | **$5.8M** |
| **Adjusted closing NWC** = $9.1M − $5.8M | **$3.3M** |
| less: Peg | ($2.0M) |
| **Price adjustment** | **+$1.3M (buyer pays more)** |

Two traps this avoids: (1) excess cash removed from the **asset** side; (2) the
seller-repaid loan removed from the **liability** side, not the asset side.
*(Illustrative only.)*

---

## (d) Disputed-items log

Resolve on evidence, not assertion. The consistency rule: any policy on the
closing statement must hit the peg basis **identically**.

| Item | Amount | Evidence | Proposed treatment | Same treatment on peg basis? (Y/N) |
|---|---|---|---|---|
| Aged AR > 90 days | `[$__]` | Aging schedule | Specific reserve 50–100% by age | Y / N |
| Disputed AR (customer claim) | `[$__]` | Correspondence file | Reserve to expected recovery | Y / N |
| Obsolete / slow-moving inventory | `[$__]` | Sell-through data | Write down to NRV (LCNRV) | Y / N |
| Unrecorded accrued liability | `[$__]` | Vendor invoices | Accrue in full | Y / N |
| Deferred revenue classification | `[$__]` | Contract terms | Per SPA definition | Y / N |

Any "N" in the last column is an asymmetry — surface it. Asymmetric treatment is
the oldest trick in the closing statement.

---

## (e) Process-levers checklist (settlement-zone toolkit)

Use when the gap won't close on a single number.

- [ ] **Collar / deadband:** no adjustment inside a band, e.g., `±[INVENTED: $150K]`.
- [ ] **WC true-up escrow:** `$[__]` — fast, formulaic, short clock.
- [ ] **Reps & warranties escrow:** `$[__]` — ~12 months, adversarial, separate
      clock. (Two escrows is standard; different risks, different clocks.)
- [ ] **Named dispute accountant** in the SPA — pre-agreed neutral firm, resolution
      capped to the disputed items.
- [ ] **Consistency-rule clause** drafted — peg basis and closing statement use
      identical accounts, reserves, and GAAP policies.

**Negotiation posture:** every $1 of peg is $1 of purchase price. Anchor on a
principled basis, concede on evidence, steer to a settlement zone. When you
disagree, disagree on policy, not on the number.

**Escalate to M&A counsel** for the NWC definition clause, the escrow agreements,
and the dispute-accountant provision. **Escalate to the auditor** for the
historical financials the buyer will diligence.
