# IPO Readiness Decision Sheet

A decision-framework tool for the "sell vs. go public" question. **Advise, not
execute** — this is enough to counsel a founder, not a substitute for
underwriters and securities counsel. All figures are illustrative ranges, not
guarantees.

> **Certify before you use this.** Costs, timelines, and eligibility are
> deal-specific. This is where you need underwriters and securities counsel before
> you commit to the IPO track.

---

## 1. The five-dimension framework — private sale vs. IPO

Score each dimension for your specific facts.

| Dimension | Private sale | IPO | Your read |
|---|---|---|---|
| **Control after** | Buyer-specific (often lost) | Dispersed public float | `[__]` |
| **Capital raised** | Buyer-limited | Potentially large | `[__]` |
| **Regulatory burden** | Low | High, ongoing | `[__]` |
| **Speed & certainty** | Fast, higher certainty | Long prep, market-dependent | `[__]` |
| **Valuation driver** | Synergies + negotiated multiples | Market sentiment + growth story | `[__]` |

The CFO balances the triad on every path: **control · capital · compliance.**

**The sharp question:** which reason to go public *evaporates* if private capital
is abundant? (Capital and liquidity — the private-markets story.) For most
private-company cohorts, the private sale is the modal and often superior path —
not a consolation prize.

---

## 2. IPO cost tally

| Cost | Illustrative range |
|---|---|
| Underwriting (gross spread) | **6–7% of proceeds** (mega-caps negotiate lower) |
| Legal + accounting | **~$2–3M** |
| SEC registration fee | Per fee schedule |
| Exchange listing | **~$125–250K initial + annual** |
| Blue-sky / miscellaneous | Varies |

**Accounting for IPO costs:** if the IPO is **probable**, defer incremental costs
against proceeds (reduce paid-in capital); if **aborted** (>90-day postponement),
**expense** them.

**EGC / JOBS Act relief:** emerging-growth companies get reduced disclosure and no
§404(b) auditor attestation for a period.

---

## 3. S-1 contents checklist — what the world will see

The S-1 is the **first time the world sees the financials** — a *liability
document with marketing inside.*

- [ ] Risk factors
- [ ] Industry / market data
- [ ] Use of proceeds
- [ ] Selected financials (GAAP + KPIs mixed in the summary)
- [ ] MD&A
- [ ] Business description
- [ ] Management & compensation
- [ ] Principal stockholders
- [ ] Accounting policies (exposed — forecasts optional and rare despite safe-harbor)

After the IPO: 10-K / 10-Q / 8-K / proxy cadence.

**Pre-IPO earnings-management caution:** the temptation is to price the offering
off inflated numbers. The checks: accrual scrutiny (do receivables and accruals
outrun revenue?) plus the monitoring stack — auditors, underwriters, analysts,
press, and post-IPO litigation/SEC exposure. Evidence direction: **Ball &
Shivakumar (2008)** find IPO firms report *more* conservatively than private peers
— the monitoring usually works. CFO line: *aggressive accruals before an IPO are a
loan from your future credibility, at loan-shark rates.*

---

## 4. Lock-ups & secondaries primer

- **Lock-ups:** underwriters impose **90–180-day** insider lock-ups. Mass insider
  selling at the open is a death signal.
- **Secondary offering** (post-lock-up): insiders sell; **non-dilutive**; proceeds
  go to the **selling shareholders**, not the company. This is when founders and
  early employees actually see cash.
- **Primary offering** (contrast): **dilutive**; proceeds raise money **for the
  company**.

---

**Output framing:** a go/no-go read on the five dimensions for the user's facts, a
cost tally, and a "what the S-1 will force you to disclose" list — framed as
advice.

**Escalate:** underwriters and securities counsel (S-1, SEC review, pricing,
lock-ups, secondary offerings); auditor (the financials the S-1 exposes).
