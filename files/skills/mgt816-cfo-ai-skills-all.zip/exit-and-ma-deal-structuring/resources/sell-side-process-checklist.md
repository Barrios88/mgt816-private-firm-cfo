# Sell-Side Process Checklist

The exit funnel as a gated checklist. Work top to bottom. At each gate, know what
the next gate demands and what destroys value if you skip it. "Ready to sell" is
not "someone is ready to buy."

> **Certify before you use this.** This is a process map, not legal advice.
> Engage M&A counsel and a banker before you open a process.

---

## The gated funnel

| # | Gate | What it demands | Value-destroying if skipped |
|---|---|---|---|
| 1 | **Readiness & advisors** | Clean cap table; audit history (exit lubricant); current data room; tax + M&A counsel engaged early | Opening a process unprepared invites re-trades and leaks; a stale data room stalls momentum |
| 2 | **Banker / teaser / NDA / CIM** | Sell-side banker screens buyers and solicits bids; anonymous **teaser** → **NDA** → **CIM** (the full book). Fees: retainer + ~1–10% of transaction value (smaller deals higher %) | Skipping the NDA/teaser stage exposes proprietary data to tire-kickers |
| 3 | **IOI (indication of interest)** | Valuation **range**, financing source, structure, timeline — non-binding | Accepting a headline number before structure is known: the price is not the price |
| 4 | **LOI (letter of intent)** | Final bid, structure, key terms. **Signing grants exclusivity + confidentiality** — seller stops shopping; leverage tilts to buyer; serious diligence begins | Signing without competitive tension locked in surrenders leverage for nothing |
| 5 | **Diligence / data room** | Six scope areas populated in a **restricted** room with a view audit trail (see diligence-data-room-index) | A disorganized room reads as hidden risk; slow responses read as a signal |
| 6 | **Sign → announce → close** | Announce-to-close gap covers regulatory + final diligence | Underestimating the regulatory clock blows the timeline |

---

## Approval & antitrust gates — check every time

- [ ] **Board** must formally approve.
- [ ] **Shareholders** vote — **possibly by class** (preferred protective
      provisions and class votes bite here).
- [ ] **FTC / DOJ (HSR)** review on larger deals — build the timeline around it.

---

## Red flags to raise unprompted

- [ ] **Tire-kickers / information tourists** — an inbound "buyer" who is really a
      competitor running cheap diligence. Guard proprietary data; **stage the data
      room** so the crown jewels release late and only under NDA.
- [ ] **A failed process destroys value** — leaks to competitors, management
      distraction that shows in the numbers, and a re-trade smell for the next
      buyer. Do not open a process you cannot close.
- [ ] **Consideration includes buyer stock?** Then the **seller must diligence the
      buyer** too.

---

## The "you are here" one-liner

At every check-in, state it as: **You are here → next gate → what it demands →
what kills value if skipped.** Responsiveness is itself a signal to the buyer;
move fast once the LOI is signed.

**Escalate:** banker (process + valuation range), M&A counsel (LOI, SPA, HSR),
auditor (historical financials), tax counsel (structure) — engage them at gate 1,
not gate 5.
