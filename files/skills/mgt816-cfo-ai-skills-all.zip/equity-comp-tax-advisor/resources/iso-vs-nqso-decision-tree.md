# ISO vs. NQSO — The Decision Tree (written out)

Walk any option grant through three gates: **GRANT → EXERCISE → SALE**. At each
gate, note the employee's tax AND the company's deduction. They move in
opposite directions — that is the two-chair crux.

> All figures illustrative (fictional **Kestrel Systems**). Substitute real facts.

---

## Gate 0 — Who are you? (this decides the instrument)

```
Are you a common-law EMPLOYEE of the granting company?
├── NO  (consultant, advisor, director, contractor)
│      → You can ONLY hold an NQSO. An "ISO" granted to you is an NQSO by law,
│        whatever the paperwork says. Someone should have caught it at grant.
└── YES
       → You CAN hold an ISO, IF the grant also meets every ISO requirement:
         • strike ≥ FMV at grant
         • exercisable within 10 years
         • ≤ $100,000 of grant-date value first exercisable per calendar year
           (the excess over $100k is an NQSO)
         Break any one → that piece is an NQSO.
```

---

## Gate 1 — GRANT

```
NQSO ─┐
ISO  ─┴──► No income to employee. No deduction to company. Nothing on the books
           for options (stock ledger only). Book records the option's grant-date
           fair value ratably over vesting (ASC 718) — same for ISO and NQSO.
           SAY IT: "at grant" — nothing happens at grant.
```

---

## Gate 2 — EXERCISE

```
                 ┌────────────────────────── NQSO ──────────────────────────┐
Exercise, spread = (FMV − strike):
  • Employee: spread is ORDINARY income, on the W-2, and IS WITHHELD.
  • Company:  DEDUCTS the same spread. Employer Medicare (1.45%) applies.
  • Cash needed: strike + withholding on the spread.
  • Clocks: LTCG clock and QSBS clock start NOW (at exercise).

                 ┌────────────────────────── ISO ───────────────────────────┐
Exercise:
  • Employee: NO regular tax. BUT the spread is an AMT ADD-BACK
              (run the 5-line worksheet). NOTHING is withheld.
  • Company:  NO deduction (yet).
  • Cash needed: strike + any AMT (which can be large with zero shares sold).
  • Clocks: LTCG clock and QSBS clock start NOW (at exercise).
  • Early-exercise + 83(b): exercise UNVESTED, file 83(b) within 30 days,
    start both clocks now while the spread is tiny → little/no AMT.
```

*Illustrative NQSO exercise (Kestrel):* 45,000 NQSOs, strike $1.00, FMV $6.60 at
exercise. Spread = ($6.60 − $1.00) × 45,000 = $5.60 × 45,000 = **$252,000**
ordinary income to the employee = **$252,000** deduction to the company.
Withholding (course-simplified) = 22% + 2.35% Medicare = 24.35% × $252,000 =
**$61,362** to remit next business day.

---

## Gate 3 — SALE (ISO path forks here on holding period)

```
NQSO sale:
  Post-exercise gain (sale price − FMV at exercise) = capital gain
  (LT if held > 1 yr from exercise, else ST). Company: no further deduction.

ISO sale — did you hold ≥ 2 years from GRANT and ≥ 1 year from EXERCISE?
├── YES → QUALIFYING disposition
│         • Employee: WHOLE gain (sale − strike) = LTCG. Best case.
│         • Company:  gets NOTHING. (Employee's best = company's worst.)
│         • The exercise-year AMT add-back may generate an AMT CREDIT.
└── NO  → DISQUALIFYING disposition (sold too soon, incl. a same-year sale)
          • Employee: spread at exercise → ORDINARY income (NOT withheld —
            you owe it yourself); further gain is capital.
          • Company:  DEDUCTS that ordinary spread.
          • Same-year sale ESCAPES AMT (no exercise-and-hold add-back).
```

---

## Who prefers which (the deductibility asymmetry)

| Party | Prefers | Because |
|---|---|---|
| Profitable / mature company | **NQSO** | the deduction is worth real cash at 21% now |
| Loss-making startup | **ISO** (fine to grant) | its deduction would just idle in NOLs anyway |
| Employee | **ISO** | *if* they can fund the exercise and survive AMT |

**A qualifying ISO disposition gives the company nothing.** The employee's best
tax outcome is the company's worst, and vice versa. Name that tension.

## The fine print that ruins people

- **90-day post-termination window** — leave, and most plans give ~90 days to
  exercise vested options or forfeit. Quitting starts a clock.
- **3-month ISO→NQSO statute** — exercise an ISO more than **3 months** after
  termination (even inside a board-extended window) and it is taxed as an NQSO.
  Extending the window trades tax character for time. **Someone pays.**
- **$100,000/yr ISO limit** — value first exercisable above $100k/yr is NQSO.

---

## Blank tree (fill in for your grant)

```
Gate 0  Employee? ____  →  Instrument: ISO / NQSO ____
Gate 1  GRANT:    income ____  deduction ____   (both should be "none")
Gate 2  EXERCISE: spread = (FMV ____ − strike ____) × shares ____ = $______
        NQSO → ordinary + withheld;  ISO → AMT add-back, nothing withheld
        Cash needed: strike $______ + withholding/AMT $______ = $______
        Clocks started (LTCG, QSBS): date ______
Gate 3  SALE:     held ≥2yr grant & ≥1yr exercise? ____
        Character: ordinary / LTCG / disqualifying ____
        Company deduction: $______ (zero on qualifying ISO)
```

**Certify:** confirm employee status, the $100k/yr split, the holding-period
dates, and whether the grant was validly an ISO — route the last one to a
securities lawyer.
