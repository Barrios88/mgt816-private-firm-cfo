# Runway Calculator — transparent 24-month cash model

A tiny, auditable model you can rebuild in any spreadsheet in five minutes. It
does one job: show the out-of-cash date and let you A/B two runway levers.

> **All numbers below are INVENTED and ILLUSTRATIVE.** Swap in your company's real
> cash balance and bank-feed exports. Nothing here is a company or course figure.

---

## Course spreadsheet conventions (bake these in)

- **Inputs are blue text on a light-yellow fill.** Formulas are black.
- **No hardcodes inside formulas** — every number a formula uses points to an
  input cell. If you type a constant into a formula, you have created an
  untraceable input.
- **One footing / error-check cell.** It must read `OK`. If it ever reads `ERR`,
  a row does not foot and the model is not trustworthy.
- Spreadsheet hygiene *is* control hygiene: the same discipline that keeps a GL
  honest keeps a model honest.

---

## Header block (inputs in [brackets] are the blue-on-yellow cells)

| Field | Value | Note |
|---|---|---|
| Current cash on hand | **[$1,050,000]** | input — today's bank balance |
| Monthly cash in (collected) | **[$60,000]** | input — collected, NOT booked/ARR |
| Monthly payroll out | **[$120,000]** | input |
| Monthly rent + infra out | **[$28,000]** | input |
| Monthly other out | **[$22,000]** | input |
| Gross burn = payroll + rent+infra + other | $170,000 | formula = 120,000 + 28,000 + 22,000 |
| Net burn = gross burn − cash in | $110,000 | formula = 170,000 − 60,000 |
| Runway = cash ÷ net burn | 9.5 months | formula = 1,050,000 ÷ 110,000 |
| Out-of-cash month | Month 10 | first month with **Ending cash < 0** |
| Footing check | **OK** | see check below |

**Footing check formula:** `Ending cash (Month 24)` must equal
`Current cash − 24 × Net burn` → 1,050,000 − 24 × 110,000 = 1,050,000 − 2,640,000
= **−1,590,000**. If the schedule's Month-24 ending cash ≠ −1,590,000 → `ERR`.

---

## The month-by-month schedule (illustrative)

Each row: Ending = Beginning + Cash in − Cash out. Cash in $60,000, cash out
$170,000, so every month steps down by the net burn of $110,000.

| Month | Beginning cash | Cash in | Cash out | Net burn | Ending cash |
|---|---|---|---|---|---|
| 1 | 1,050,000 | 60,000 | 170,000 | 110,000 | 940,000 |
| 2 | 940,000 | 60,000 | 170,000 | 110,000 | 830,000 |
| 3 | 830,000 | 60,000 | 170,000 | 110,000 | 720,000 |
| 4 | 720,000 | 60,000 | 170,000 | 110,000 | 610,000 |
| 5 | 610,000 | 60,000 | 170,000 | 110,000 | 500,000 |
| 6 | 500,000 | 60,000 | 170,000 | 110,000 | 390,000 |
| 7 | 390,000 | 60,000 | 170,000 | 110,000 | 280,000 |
| 8 | 280,000 | 60,000 | 170,000 | 110,000 | 170,000 |
| 9 | 170,000 | 60,000 | 170,000 | 110,000 | 60,000 |
| **10** | 60,000 | 60,000 | 170,000 | 110,000 | **−50,000** ← out of cash |
| 11 | −50,000 | 60,000 | 170,000 | 110,000 | −160,000 |
| 12 | −160,000 | 60,000 | 170,000 | 110,000 | −270,000 |
| 13 | −270,000 | 60,000 | 170,000 | 110,000 | −380,000 |
| 14 | −380,000 | 60,000 | 170,000 | 110,000 | −490,000 |
| 15 | −490,000 | 60,000 | 170,000 | 110,000 | −600,000 |
| 16 | −600,000 | 60,000 | 170,000 | 110,000 | −710,000 |
| 17 | −710,000 | 60,000 | 170,000 | 110,000 | −820,000 |
| 18 | −820,000 | 60,000 | 170,000 | 110,000 | −930,000 |
| 19 | −930,000 | 60,000 | 170,000 | 110,000 | −1,040,000 |
| 20 | −1,040,000 | 60,000 | 170,000 | 110,000 | −1,150,000 |
| 21 | −1,150,000 | 60,000 | 170,000 | 110,000 | −1,260,000 |
| 22 | −1,260,000 | 60,000 | 170,000 | 110,000 | −1,370,000 |
| 23 | −1,370,000 | 60,000 | 170,000 | 110,000 | −1,480,000 |
| 24 | −1,480,000 | 60,000 | 170,000 | 110,000 | **−1,590,000** |

Ending cash first goes negative in **Month 10** — consistent with a 9.5-month
runway (you cross zero partway through month 10). Month-24 ending cash =
−1,590,000 matches the footing check → **OK**.

The schedule beats the single ratio the moment burn or collections stop being
flat: add a hire in month 3, a renewal spike in month 6, and the ratio lies while
the schedule tells the truth.

---

## Lever comparison rows (the compounding-vs-one-time lesson, made visible)

Baseline: net burn $110,000, cash $1,050,000, runway **9.5 months**.

| Lever | Mechanism | New net burn | New cash | New runway | Δ vs. baseline |
|---|---|---|---|---|---|
| **One-time cash** of $110,000 | collect a stuck receivable | 110,000 | 1,160,000 | 1,160,000 ÷ 110,000 = **10.5 mo** | **+1.0 mo** |
| **Recurring cut** of $18,000/mo | drop a tool + one open req | 92,000 | 1,050,000 | 1,050,000 ÷ 92,000 = **11.4 mo** | **+1.9 mo** |

The one-time cash equal to one month of burn buys exactly **+1.0 month, once**.
The recurring cut lowers the denominator forever, so it buys more (**+1.9**) and
keeps compounding as long as the cut holds. Runway is *hyperbolic* in burn but
only *linear* in cash.

**Judgment note:** the spreadsheet ranks the recurring cut higher, but if that
$18,000 is the contractor finishing the integration a pilot customer is waiting
on, the cut can win the model and lose the company. Name the tradeoff next to the
number.

---

## Certification

Re-derive net burn, runway, and the out-of-cash month by hand before this goes to
a board — the model drafts it; you certify it. Log the re-derivation in
`certification-log.md`.
