# Certification Log

The discipline that turns AI use into a **deliverable** instead of a policing
problem. AI drafts the numbers; **you certify every one.** No burn, runway, or
out-of-cash figure is a board number until a human has re-derived it by hand and
logged that re-derivation here.

Keep this alongside any multi-number deliverable (a runway model, a close, a
financing entry). It is your auditable trail.

---

## How to use it

For each drafted number or claim: name the check you ran (from the list below),
record the result (**confirmed** / **corrected** / **rejected**), and note the
change you made. If a figure is corrected or rejected, the log shows exactly what
happened and why.

## The domain checks (reference these in the "Check performed" column)

1. **Cash-vs-accrual** — "cash in" is *collected* cash, not bookings/ARR.
2. **Gross vs. net** — runway computed off *net* burn; gross and net shown separately.
3. **One-time vs. recurring** — each lever re-divided explicitly; a one-time
   inflow equal to one month of burn yields exactly +1.0 month.
4. **A = L + SE tie-out** — every entry / mini-statement balances; accrual traps
   (collection, prepayment, unpaid wages) flagged.
5. **Valuation-never-booked** — no pre/post-money valuation on the balance sheet.
6. **Working-capital sign** — negative WC not read as distress for a
   collect-fast/pay-slow model.

---

## Log

| # | Prompt / step | AI claim or draft number | Check performed (1–6) | Result (confirmed / corrected / rejected) | Change made |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |

---

## Worked example row (invented, illustrative — delete before use)

| # | Prompt / step | AI claim or draft number | Check performed | Result | Change made |
|---|---|---|---|---|---|
| e.g. | "What's our runway?" | Net burn $110,000/mo; runway 9.5 mo | Checks 1 + 2: confirmed "cash in $60,000" is collected, not booked; re-derived gross $170,000 and net $110,000 by hand | confirmed | none — hand re-derivation matched |

---

## Sign-off

Numbers certified by: __________  ·  Date: __________

**Re-derive net burn, runway, and out-of-cash by hand before anything here goes to
a board — the AI drafted it; you certify it.** The course's closed-book material
tests this without AI, so the point is to build the judgment, not to lean on the
tool.
