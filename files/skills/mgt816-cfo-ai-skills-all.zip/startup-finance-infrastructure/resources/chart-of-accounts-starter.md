# Chart of Accounts — early-stage starter

**Book of record first; feed everything into it; keep it lean.** Pick the
accounting software (QuickBooks / Xero / FreshBooks) as your single source of
truth, then lay out the chart of accounts *before* the first transaction posts.

This is a generic template to swap for your company's real accounts — not a
filled company chart. Gaps are left between numbers (1010, 1020, …) so you can
insert accounts later without renumbering everything.

---

## 1000s — Assets (normal balance: Debit)

| # | Account | What posts here |
|---|---|---|
| 1000 | Cash — Operating | Primary checking; bank-feed connected |
| 1010 | Cash — Savings / Reserve | Money-market / reserve balances |
| 1100 | Accounts Receivable | Amounts billed to customers, not yet collected |
| 1200 | Prepaid Expenses | Rent, insurance, annual software paid in advance |
| 1300 | Equipment & Fixtures | Laptops, furniture (capitalized, then depreciated) |
| 1310 | Accumulated Depreciation | Contra-asset; running depreciation on the above |
| 1400 | Intangibles / Capitalized Software | Only if it meets the cap threshold |

## 2000s — Liabilities (normal balance: Credit)

| # | Account | What posts here |
|---|---|---|
| 2000 | Accounts Payable | Vendor bills received, not yet paid |
| 2100 | Accrued Expenses | Costs incurred but not yet billed to you |
| 2110 | Wages / Payroll Payable | Wages earned by staff, not yet paid |
| 2200 | Deferred Revenue | Cash collected before you deliver — a liability you owe |
| 2300 | Credit Card Payable | Company-card balances outstanding |
| 2400 | Notes Payable / Debt | Loans, venture debt, convertible notes (principal) |

## 3000s — Equity (normal balance: Credit)

| # | Account | What posts here |
|---|---|---|
| 3000 | Common Stock | Founder / common issuances, at amount invested |
| 3100 | Preferred Stock | Preferred rounds, at cash invested (valuations never post) |
| 3200 | Additional Paid-In Capital (APIC) | Amount above par, if you track par |
| 3900 | Retained Earnings / Accumulated Deficit | Cumulative net income (or loss) |

## 4000s — Revenue (normal balance: Credit)

| # | Account | What posts here |
|---|---|---|
| 4000 | Product / Subscription Revenue | Recognized when *earned*, not when collected |
| 4100 | Services / Implementation Revenue | Professional-services revenue |
| 4900 | Contra-revenue (discounts, refunds) | Reductions to gross revenue |

## 5000s — COGS / Cost of Revenue (normal balance: Debit)

| # | Account | What posts here |
|---|---|---|
| 5000 | Hosting / Infrastructure COGS | Cloud costs directly tied to delivering the product |
| 5100 | Payment-processing fees | Card / processor fees on revenue |
| 5200 | Support & Delivery Labor | Staff cost directly serving customers |

## 6000s — Operating Expenses (normal balance: Debit)

| # | Account | What posts here |
|---|---|---|
| 6000 | Sales & Marketing | Ads, events, S&M salaries |
| 6100 | Research & Development | Engineering / product salaries and tools |
| 6200 | General & Administrative | Rent, admin, legal, accounting, insurance |
| 6210 | Software & Subscriptions | Internal SaaS tools |
| 6300 | Depreciation & Amortization | Non-cash expense for the 1300/1400 assets |

---

## The four-layer software stack this chart plugs into

1. **Accounting software = book of record** (this chart lives here).
2. **AR & AP tools** — invoicing and bill-pay that feed the book of record.
3. **Document collection** — receipts, contracts, leases.
4. **Automated extraction** — bank/card feeds and OCR so entry is not retyped.

Operator tools (Ramp, Bill.com, Gusto) live in layers 2–4. They are **not** the
book of record — don't let a spend-management app quietly become your GL.

## Rules of thumb
- Map every recurring transaction type to exactly one account before go-live.
- A 12-person company does not need 300 accounts. Add an account only when a real
  transaction needs a home the chart doesn't already give it.
- Structure it first. A chart invented ad hoc as invoices arrive produces
  inconsistent coding and useless reports.
