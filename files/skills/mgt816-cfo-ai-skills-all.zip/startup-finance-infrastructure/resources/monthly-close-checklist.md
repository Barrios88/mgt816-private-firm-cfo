# Monthly Close Checklist

A one-page close calendar. Assign an owner to each step, set business-day (BD)
targets, and run the watch-list every month. Close **monthly, not annually** —
otherwise you run the company on 30-day-old numbers, errors compound, and the
year-end close becomes archaeology.

> BD+n = n business days after month-end close date. Targets below are a starting
> point; tighten them as the team matures.

---

## The six steps

### 1. Pre-close readiness — target BD+1  ·  Owner: __________
- [ ] Cutoff date set and communicated; no transactions in flight
- [ ] All bank / card feeds imported through month-end
- [ ] Expense reports and receipts submitted
- [ ] Payroll finalized for the period

### 2. Close the sub-ledgers — target BD+2  ·  Owner: __________
- [ ] AR sub-ledger closed (all invoices issued and posted)
- [ ] AP sub-ledger closed (all vendor bills entered)
- [ ] Payroll sub-ledger closed and tied to the payroll provider

### 3. GL accounting — target BD+3  ·  Owner: __________
- [ ] Recurring journal entries posted (depreciation, amortization)
- [ ] Accruals booked (wages payable, unbilled vendor costs)
- [ ] Prepaid amortization and deferred-revenue release posted
- [ ] Reclasses and corrections posted

### 4. Account reconciliations — target BD+4  ·  Owner: __________
- [ ] **Bank reconciliation first** — book cash ties to cleared bank balance
- [ ] AR aging reconciled to the GL control account
- [ ] AP reconciled to the GL control account
- [ ] Credit-card and loan balances reconciled

### 5. Prepare financial statements — target BD+5  ·  Owner: __________
- [ ] Balance sheet (A = L + SE ties out)
- [ ] Income statement
- [ ] Cash flow statement
- [ ] Draft burn / runway update off the closed cash number

### 6. Management review — target BD+6  ·  Owner: __________
- [ ] Founder / CEO walkthrough of the three statements
- [ ] Variance to prior month explained
- [ ] Burn, runway, and out-of-cash date reviewed and certified by hand
- [ ] Close signed off; period locked

---

## Monthly watch-list (check every close)

| Watch item | Why |
|---|---|
| **Bank reconciliation** | Catches missing, duplicate, or fraudulent transactions |
| **AR aging** | Old receivables signal collection or credit problems |
| **Unbilled / deferred revenue** | Revenue recognized too early or too late distorts everything |
| **Unrecorded expenses** | Missing accruals overstate profit and understate burn |
| **Overdue AP** | Slipping payables can mean a cash squeeze building |

---

## Footer
Close **monthly, not annually.** At some scale, **hire someone to own this** — a
founder doing the close off the side of the desk is a control weakness, not a
cost saving. Log the burn/runway certification in `certification-log.md`.
