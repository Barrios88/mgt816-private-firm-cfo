# Journal-Entry Cheat Card

Everything balances, after every transaction:

```
Assets = Liabilities + Shareholders' Equity
```

SE = contributed capital (Common + Preferred + APIC) + Retained Earnings.
Retained Earnings grows by Net Income (Revenues − Expenses) and shrinks with
losses and dividends. Double-entry just means every event touches ≥2 accounts and
leaves the equation balanced.

---

## Debits & credits

| Account type | Increases with | Decreases with | Normal balance |
|---|---|---|---|
| Assets | Debit | Credit | Debit |
| Liabilities | Credit | Debit | Credit |
| Equity | Credit | Debit | Credit |
| Revenues | Credit | Debit | Credit |
| Expenses | Debit | Credit | Debit |

Debit = left, credit = right. Nothing more moral than that.

**DEALER mnemonic:** **D**ividends, **E**xpenses, **A**ssets increase on the
**debit** side; **L**iabilities, **E**quity, **R**evenue increase on the
**credit** side.

---

## The financing rule (this returns on the final)

> **Equity financings are booked at the amount INVESTED.**
> Dr Cash / Cr Common (or Preferred) Stock.
> **Pre-money and post-money valuations are negotiated market values — they NEVER
> appear on the balance sheet.**

**Worked example (invented, illustrative):** angels invest $750,000 for seed
preferred.

```
Dr  Cash                       750,000
    Cr  Preferred Stock–Seed           750,000
```

The negotiation implied an $8M valuation. Where does the $8M post? **Nowhere.**
Only the $750,000 of cash invested is recorded. (Share count and price-per-share
live in the `cap-table-and-financing-rounds` skill, not on the books.)

---

## Three accrual traps (the ones that bite)

1. **Collection ≠ revenue.** Collecting on a prior invoice moves an asset; it is
   not a second sale.
   ```
   Dr  Cash            X
       Cr  Accounts Receivable   X
   ```
   Revenue was already recognized when *earned*.

2. **Prepayment = liability.** Cash received before you deliver is **Deferred
   Revenue** — you owe the work.
   ```
   Dr  Cash                 X
       Cr  Deferred Revenue      X   (a liability, not revenue)
   ```
   Recognize revenue later, as you deliver:
   ```
   Dr  Deferred Revenue     X
       Cr  Revenue               X
   ```

3. **Expense follows the work, not the check.** Wages earned but unpaid at
   month-end are accrued.
   ```
   Dr  Wages Expense        X
       Cr  Wages Payable         X
   ```

---

## Why this matters for burn

Net income and operating cash can move in **opposite directions** in the same
month. A customer prepayment can push operating cash positive while the P&L still
shows a loss. That is exactly why burn is measured in **cash**, not accrual
profit — and why the cash flow statement exists. When you certify a runway, you
are certifying a cash number.

## The four statements articulate
- Net income → Retained Earnings (equity).
- Net change in cash → balance-sheet cash.
- Financing events → cash from financing (CFF) + equity/debt.
- Indirect method: start at NI, add back non-cash (D&A, stock comp), adjust ΔWC —
  **Δcurrent assets up → subtract; Δcurrent liabilities up → add.**

**Prove it every time:** after any entry, re-check A = L + SE. If it doesn't
balance, the entry is wrong.
