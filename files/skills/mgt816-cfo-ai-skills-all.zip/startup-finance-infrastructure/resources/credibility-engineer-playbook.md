# Credibility Engineer Playbook

**The situation.** A big counterparty — a strategic acquirer, an enterprise
customer's procurement team, a lender — demands financials the company cannot
produce: say, three years of audited statements from a two-year-old startup with
ugly numbers. You cannot conjure an audit overnight. So the CFO's real product
here is **trust**, manufactured from substitutes.

**The reframe that changes the conversation.** Roughly 60% of large private firms
have **no** audited GAAP statements (Lisowsky & Minnis 2018). "We don't have an
audit" is the *default* for private companies, not a confession. Your job is to
substitute other credibility, not to apologize.

---

## The menu — generate at least four moves across three families

### Buy trust
| Move | What it is | Cost / speed |
|---|---|---|
| **CPA-*reviewed* statements** | A review (limited assurance), not a full audit | Fast, cheap, often enough for a customer |
| **Customer references** | Named, reachable customers vouch for delivery | Very fast, free |
| **Disclosed investor commitments** | Show who backed you and how much | Fast, free |
| **Reframe the numbers** | Losses = deliberate platform / R&D investment; lead with traction + runway, not the net-loss line | Free; presentation only |

### De-risk the deal
| Move | What it is | Cost / speed |
|---|---|---|
| **Source-code / product escrow** | Buyer gets the code if the startup dies | Moderate; needs a lawyer |
| **Shorter initial term / pilot** | Limit the counterparty's exposure up front | Fast; deal-structure |
| **Prepayment / milestone billing** | Tie payment to delivered milestones | Fast; also helps working capital |
| **Hard SLAs** | Contractual service guarantees with teeth | Moderate; needs a lawyer |
| **Arm your internal champion** | Give the sponsor who wants your product the ammo to sell procurement internally | Free |

### Fix the root cause
| Move | What it is | Cost / speed |
|---|---|---|
| **Commission a review / audit now** | If counterparties like this *are* the pipeline, start it | Slow, expensive |
| **Raise now** | If the deal hinges on balance-sheet strength | Slow |

---

## Ranking rubric

Score each move on two axes: **(a) how much trust it buys** vs. **(b) cost and
speed.**

- A **CPA review** buys real, third-party assurance cheaply — usually the best
  first move for a customer.
- **Escrow** de-risks the deal without any financials at all — powerful when the
  counterparty's real fear is "what if you disappear."
- **Stalling** ("we'll have them next quarter") is the weak option students
  reach for first — acknowledge it, then push past it; it buys no trust.
- A **full audit** is the heavyweight answer: recommend it only when the pipeline
  of audit-demanding counterparties justifies the cost and time.

---

## Audit vs. CPA review — know the difference

| | **Audit** | **Review** |
|---|---|---|
| Assurance level | Reasonable (highest short of nothing) | Limited |
| Procedures | Testing, confirmations, controls work | Inquiry + analytical procedures |
| Cost / time | High / months | Lower / weeks |
| When | Pipeline demands it; a raise or sale requires it | A customer or smaller lender needs comfort |

---

## The honest-numbers principle

Show the real, ugly numbers wrapped in narrative, metrics, and references.
**Hiding them destroys the trust you are trying to build the moment diligence
finds them.** Credibility for an unaudited company comes from three signals:

1. **Reviews / audits** — third-party assurance, even limited.
2. **Analyst-style scrutiny** — do the numbers match the business? Can you defend
   every driver?
3. **Reputation** — management hits what it forecasts, quarter after quarter.

---

## Your situation (fill in)

- Counterparty and what they are: __________
- Exactly what they asked for: __________
- What we can actually produce today: __________
- Their real underlying fear: __________
- Ranked moves we will offer (top 3): 1) ______ 2) ______ 3) ______
- Where we escalate (CPA for a review/audit; lawyer for escrow/SLA terms): ______

Deal-structure mechanics (earn-outs, purchase price) hand off to
`exit-and-ma-deal-structuring`.
