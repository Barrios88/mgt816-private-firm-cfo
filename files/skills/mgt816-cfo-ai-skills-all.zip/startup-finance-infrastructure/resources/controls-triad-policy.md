# Controls Triad Policy — drop-in one-pager (sub-10-person firm)

A fill-in internal-controls policy sized for a company under ten people. The
*smaller* the firm, the *fewer* hands, the *easier* the fraud — controls are not
a big-company luxury.

**Why this matters (two real, public failures):**
- **Skully** — founders accused of spending company cash on Dodge Vipers and a
  rented Lamborghini. Missing control: **expense documentation**.
- **WrkRiot** — CEO accused of faking wire-transfer documents to keep unpaid
  staff working. Missing control: **a separate person releasing payments**.

Both were preventable with the three controls below.

---

## Control 1 — Segregation of duties

No one person holds all three of: **authorization**, **custody**, and
**record-keeping**. Split at least authorization from custody.

Fill in your matrix (name a *different* person per column wherever headcount
allows):

| Function | Who |
|---|---|
| Approves a payment / PO | __________ |
| Releases the payment (clicks send / signs) | __________ |
| Records the transaction in the books | __________ |
| Reviews the bank reconciliation (did **not** prepare it) | __________ |

Rule: the person who **approves** a payment is **not** the person who **releases**
it. The founder reviews a bank rec they did not prepare.

## Control 2 — Authorization thresholds

Transactions above a limit need a second approver.

- Any single transaction above **$__________** requires a second approver.
  *(A common starting point for an early-stage firm is $1,000.)*
- **Every wire transfer requires two people**, regardless of amount — one to
  initiate, one to release.
- New vendors must be verified (bank details confirmed out-of-band) before first
  payment.

## Control 3 — Retention of records

Keep the paper, and keep it findable.

- [ ] Vendor invoices and receipts
- [ ] Signed contracts and order forms
- [ ] Leases
- [ ] Check register / payment log
- [ ] Bank and credit-card statements
- [ ] Payroll records
- Retention period: **__________ years** (set with counsel / your CPA).
- Storage location: __________ (a single, access-controlled document system).

---

## Sign-off
Adopted by: __________  ·  Date: __________  ·  Review annually or at every raise.

**Note:** contract terms, worker classification, and legal-liability questions go
to a lawyer; audit or review commissioning goes to a CPA. This policy is the
operator's baseline, not a legal opinion.
