# Formulas — Quick Reference

One page, every formula in the skill. Notation: `I` investment, `Pre` stated
pre-money, `Post` post-money, `x` new-investor %, `p` option-pool % of post FD,
`S₀`/`S₁` existing fully-diluted shares, `Z` post-round FD total, `Y` new
investor shares, `W` pool shares, `α` preference multiple, `E` exit value.

## Round math

| Quantity | Formula |
|---|---|
| Post-money | `Post = Pre + I` |
| New-investor ownership | `x = I ÷ Post`  *(÷ post, never ÷ pre)* |
| FD total, no pool | `Z = S₀ ÷ (1 − x)` |
| FD total, with pool shuffle | `Z = S₁ ÷ (1 − x − p)` |
| New investor shares | `Y = x · Z` |
| Pool shares | `W = p · Z` |
| Price per share | `PPS = I ÷ Y = effective pre ÷ S₁` |
| Effective (true) pre-money | `effective pre = Pre − p · Post` |

## Warrant-coverage dilution (venture debt)

| Quantity | Formula |
|---|---|
| Warrant dollars | `coverage% × loan` |
| Warrant shares | `warrant dollars ÷ strike` |
| Dilution % | `warrant shares ÷ (existing FD + warrant shares)` |

## Convertible note / SAFE conversion

| Quantity | Formula |
|---|---|
| Note conversion amount | `principal + accrued interest` |
| Conversion price | `min( round PPS × (1 − discount), cap ÷ applicable cap-count )` |
| Converted shares | `conversion amount ÷ conversion price` |
| Post-money SAFE ownership | `investment ÷ post-money cap` |

## Liquidation waterfall

| Quantity | Formula |
|---|---|
| Preference floor | `α × investment` |
| 1×/n× non-participating payoff | `max(preference, ownership% × E)` |
| Participating (1×) payoff | `preference + ownership% × (E − preference)` |
| Conversion crossover | `E* = preference ÷ ownership%`  *(above E*, convert)* |
| Common | `E − (all preferred payoffs)`  *(can be $0 at low exits)* |

## The certification checks (run every time)

1. **Foot check** — % column sums to **100.0%**; shares sum to `Z`.
2. **Price reconciliation** — `I ÷ Y` = `effective pre ÷ S₁`.
3. **Waterfall only** — payoffs sum to `E` at every exit modeled.

## The one-liner to never omit

**Who bears participation? Common — usually the employees.** And common priced at
the preferred PPS is an *upper bound*: 409A discounts and liquidation preferences
make it worth less.
