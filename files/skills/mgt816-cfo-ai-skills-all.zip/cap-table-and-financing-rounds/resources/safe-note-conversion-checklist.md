# SAFE / Note Conversion Checklist

SAFEs and notes are money in the door *before* a price exists. They are NOT on
the cap table yet — but they dilute exactly like equity when they convert, and
the surprise always lands on the founders. Convert them FIRST, fold the shares
into `S₁`, THEN run the priced-round math (`round-modeler-worksheet.md`).

---

## Step 1 — Which instrument is it?

```
Does it accrue interest and have a maturity date?
├── YES → CONVERTIBLE NOTE. It is DEBT until it converts.
│        Balance sheet: Dr Cash / Cr Note Payable at issuance; accrue interest.
│        On conversion it moves out of liabilities into equity.
└── NO  → SAFE. Not debt, not yet equity — an agreement to issue future equity.
         No maturity, no interest.
         Balance sheet: EQUITY section. Dr Cash / Cr Paid-in-Capital — SAFEs.
```

If an investor asks "how much debt do you have?", **SAFEs are zero** — but the
dilution overhang is real. Both statements are true; say both.

## Step 2 — What are the conversion terms? (read them off the doc, never invent)

- [ ] **Valuation cap?** — a ceiling on the price the money converts at.
- [ ] **Discount?** — e.g., 20% off the round price.
- [ ] **Both cap and discount?** → the investor takes the **investor-better
      (lower)** resulting price. Not both applied together — the better one.
- [ ] **Uncapped / MFN?** — Most Favored Nation: the SAFE later adopts the best
      terms granted to any subsequent SAFE. Flag it; you may not know the final
      terms yet → OPEN QUESTION.

## Step 3 — Which capitalization does ownership measure against?

- [ ] **Post-money SAFE (YC 2018+ default):** ownership is fixed at
      `investment ÷ post-money cap`, measured *after* all SAFEs but *before* the
      new priced-round money and its pool. Cleaner, but dilutes founders more.
- [ ] **Pre-money SAFE (older):** measured against the pre-money capitalization;
      the founder-vs-investor split of the pool and later money differs.
- [ ] If the doc doesn't say which → **OPEN QUESTION**, do not assume.

## Step 4 — Compute the conversion

- **Note conversion amount** = principal + accrued interest.
- **Conversion price** = the **lower** (investor-better) of:
  - (a) round PPS × (1 − discount), or
  - (b) cap ÷ the applicable capitalization count.
- **Shares** = conversion amount ÷ conversion price.
- **Post-money SAFE shortcut:** shares such that the holder lands at
  `investment ÷ post-money cap` of the post-SAFE capitalization.

## Step 5 — Fold in and re-run

- [ ] Add every converted SAFE/note share into `S₁`.
- [ ] Run the priced round on the enlarged `S₁` (`round-modeler-worksheet.md`).
- [ ] Produce the **pro-forma** table with everything converted **before** anyone
      signs. Contrast founder % *with* vs. *without* conversion so the overhang
      is visible.

## Step 6 — Book the conversion

- **SAFE:** Dr PIC — SAFEs / Cr Preferred Stock + APIC.
- **Note:** clear Note Payable + accrued interest / Cr Preferred Stock + APIC.

---

## Red flag — stacked instruments

Stacked SAFEs at rising caps ($4M → $6M → $8M) look harmless because none are on
the cap table, but at conversion they compound. Always model the full stack.

## Worked check (invented — "Cobalt Instruments")

A **$500,000 post-money SAFE** with an **$8,000,000 post-money cap** converts at
the Series A. Ownership = `$500,000 ÷ $8,000,000` = **6.25%** of the post-SAFE
capitalization. Convert to shares against that capitalization, add them to `S₁`,
then run the Series A pool-shuffle math. The founders' post-A % lands **lower**
than a table that "forgot" the SAFE — which is exactly the overhang the pro-forma
is built to expose.

## Escalate

Securities-law questions on note/SAFE cleanup, and the **definitive GAAP
classification/disclosure** of a SAFE, note, or warrant on audited financials,
are **lawyer** and **CPA** calls respectively. The math is yours; the sign-off
is theirs.
