# Term-Sheet Triage Card

Sort every line of the term sheet into two columns. **Economics decide who gets
paid; control decides who decides.** Read both columns before you sign — a
cheap-looking control term can be the most expensive line in the document years
later. The redlining itself is a **lawyer** call; this card is the triage that
tells you where to spend your negotiating capital.

---

## ECONOMIC — sets who gets paid / the price

| Term | One-line consequence |
|---|---|
| Pre-money valuation | Sets the price per share and everyone's starting %. |
| Option-pool size & timing | A pool *in the pre-money* is a hidden price cut — it lowers the effective pre and the existing holders pay 100% of it. |
| Liquidation preference (multiple) | A 1.5× on a $10M check is a $15M floor before common sees a dollar. |
| Seniority vs. pari-passu | Senior preferences are paid first; pari-passu shares the top layer pro-rata (more founder-friendly). |
| Participation | The "double dip" — investor takes its preference AND shares the residual as common; the cost lands on common (usually employees). |
| Anti-dilution formula | Weighted-average nudges the conversion price in a down round; full-ratchet resets it all the way and can crush common. |

## CONTROL — sets who decides

| Term | One-line consequence |
|---|---|
| Board composition | Board math decides who controls hiring/firing the CEO and approving the next deal. |
| Protective provisions | Class-vote veto over a sale, new senior stock, the budget, or new debt — a minority holder can block a majority decision. |
| Information rights | Obligates the company to deliver financials/reports on a schedule. |
| Pro-rata / pre-emptive rights | Lets the investor keep its % by buying into future rounds. |
| Drag-along | Forces a sale decision — minority holders must go along if the threshold approves. |

---

## The five that deserve your negotiating capital

> 1. **Valuation net of the pool shuffle** — the *effective* pre, not the headline.
> 2. **Preference seniority + participation** — the stack that decides who gets
>    paid first and whether the investor double-dips.
> 3. **The anti-dilution formula** — weighted-average vs. full-ratchet.
> 4. **The protective-provision list** — exactly what needs a class vote.
> 5. **Board math** — who controls the seats.

Everything else is real, but these five move the most money and the most control.
Escalate the actual drafting/redlining and any enforceability question to counsel.
