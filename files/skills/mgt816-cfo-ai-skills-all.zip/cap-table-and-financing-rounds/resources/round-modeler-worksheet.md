# Round Modeler Worksheet — priced round with (or without) an option-pool shuffle

Mirrors Workflows 1–2. Fill in the **Inputs**, then work down the **Compute**
column. The formula is printed next to every blank so you can re-derive by hand —
because the point is to understand the algebra, not to run a black box, and the
final exam is closed-book. Never invent a term the term sheet did not give you;
put anything missing under OPEN QUESTIONS.

---

## 1. Inputs (from the term sheet / SAFE / note — never invented)

| Symbol | Meaning | Your value |
|---|---|---|
| `I` | New investment | __________ |
| `Pre` | Stated pre-money valuation | __________ |
| `S₁` | Existing fully-diluted shares (incl. any converted SAFEs/notes) | __________ |
| `p` | Target option pool, as % of post-round FD (0 if none) | __________ |

> If SAFEs or notes are outstanding, convert them FIRST
> (`safe-note-conversion-checklist.md`) and fold their shares into `S₁` before
> you start here. A SAFE left out of `S₁` understates dilution.

## 2. Compute (formula, then plug in)

| Step | Formula | Result |
|---|---|---|
| Post-money | `Post = Pre + I` | __________ |
| New-investor % | `x = I ÷ Post`  *(÷ post, never ÷ pre)* | __________ |
| Fully-diluted total | `Z = S₁ ÷ (1 − x − p)`  *(drop `p` if no pool)* | __________ |
| New investor shares | `Y = x · Z` | __________ |
| Pool shares | `W = p · Z` | __________ |
| Price per share | `PPS = I ÷ Y` | __________ |
| Effective (true) pre-money | `effective pre = Pre − p · Post` | __________ |

## 3. Journal entries

- New money in: **Dr Cash / Cr Preferred Stock — [Series]** at `I`.
- Pool creation: **NO entry.** A reserved pool is a memo fact; options hit the
  P&L later, as granted and earned (Dr Comp Expense / Cr APIC).
- Pre/post-money and effective pre-money **never post** — they are market
  values, not transactions.

## 4. Certify before you ship (do both, state that you did)

1. **Foot check** — every holder's % sums to **100.0%**; every holder's shares
   sum to `Z`. If not, a line is missing or a % is hardcoded.
2. **Price reconciliation** — `I ÷ Y` must equal `effective pre ÷ S₁`. If they
   disagree, the pool or the share count is wrong.

---

## Worked example (invented — "Cobalt Instruments" Series A, pool shuffle)

**Inputs:** `I` = $10,000,000; `Pre` = $30,000,000; `S₁` = 10,000,000 (8,000,000
founders + 2,000,000 seed preferred); `p` = 12.5% of post FD.

**Compute:**

| Step | Plugged in | Result |
|---|---|---|
| `Post = Pre + I` | $30,000,000 + $10,000,000 | **$40,000,000** |
| `x = I ÷ Post` | $10,000,000 ÷ $40,000,000 | **25.0%** |
| `Z = S₁ ÷ (1 − x − p)` | 10,000,000 ÷ (1 − 0.25 − 0.125) = 10,000,000 ÷ 0.625 | **16,000,000** |
| `Y = x · Z` | 0.25 × 16,000,000 | **4,000,000** |
| `W = p · Z` | 0.125 × 16,000,000 | **2,000,000** |
| `PPS = I ÷ Y` | $10,000,000 ÷ 4,000,000 | **$2.50** |
| `effective pre = Pre − p · Post` | $30,000,000 − 0.125 × $40,000,000 = $30,000,000 − $5,000,000 | **$25,000,000** |

**Resulting cap table (fully diluted):**

| Holder | Security | Shares | % FD |
|---|---|---|---|
| Founders | Common | 8,000,000 | 50.0% |
| Seed | Preferred — Seed | 2,000,000 | 12.5% |
| Series A VC | Preferred — Series A | 4,000,000 | 25.0% |
| Option pool | Options (reserved) | 2,000,000 | 12.5% |
| **Total** | | **16,000,000** | **100.0%** |

**Journal entry:** Dr Cash $10,000,000 / Cr Preferred Stock — Series A
$10,000,000. Pool creation: no entry.

**Certification:**
- Foot check: 50.0% + 12.5% + 25.0% + 12.5% = **100.0%** ✓; shares 8,000,000 +
  2,000,000 + 4,000,000 + 2,000,000 = **16,000,000** = Z ✓.
- Price reconciliation: `I ÷ Y` = $10,000,000 ÷ 4,000,000 = $2.50;
  `effective pre ÷ S₁` = $25,000,000 ÷ 10,000,000 = $2.50 ✓.

**The unprompted line to add:** the pool shuffle cost the existing holders
$5,000,000 of effective pre-money (headline $30,000,000 → true $25,000,000).
Push back three ways: size the pool bottoms-up from an 18–24-month hiring plan,
move pool creation to post-money, or raise the stated pre to offset the shuffle.
