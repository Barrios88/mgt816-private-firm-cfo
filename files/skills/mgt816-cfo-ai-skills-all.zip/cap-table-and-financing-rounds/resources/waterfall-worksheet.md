# Liquidation Waterfall Worksheet — who nets what at exit

Mirrors Workflow 6. Given an exit value `E`, walk the proceeds through the
preference stack, holder by holder, seniority first. The bottom rule is
absolute: **payoffs must sum to the exit value.** Every dollar of the sale is
paid to someone.

---

## 1. Inputs (one row per preferred series — never invented)

| Series | Investment | Ownership % (FD) | Preference multiple (α) | Participating? (Y/N) | Seniority rank (1 = senior) |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |

Common holds the residual — no preference, paid last.

## 2. Formulas (hold these exactly)

- **Preference floor** = `α × investment`.
- **1× (or n×) non-participating** payoff = `max(preference, ownership% × E)`.
  A floor plus an option: take the money back, OR convert to common if that is
  worth more. You take the **greater** — never both.
- **Participating (1×)** payoff = `preference + ownership% × (E − preference)`.
  The "double dip." No conversion choice; it always participates.
- **Conversion crossover** (non-participating only): `E* = preference ÷ ownership%`.
  Above `E*` the investor converts; below it, takes the preference.
- **Common** = `E − (everything paid to preferred)`. At low exits this can be
  **$0** — the preference *is* the exit.

## 3. Procedure

1. Pay preferences by seniority. Senior ranks first; **pari-passu** ranks share
   the top layer pro-rata if proceeds fall short.
2. For each non-participating holder, check convert-vs-preference via `E*`.
3. Distribute the residual to common (and participating preferred) pro-rata.
4. **Confirm the payoffs sum to E.** If they don't, a line is missing.

---

## Worked example (invented — "Cobalt Instruments")

Series A investor: **$10,000,000 in, 25.0% FD, 1× preference.** Crossover
`E* = $10,000,000 ÷ 0.25 = $40,000,000` — above $40M it converts, below it takes
the $10M preference.

### Exit A: E = $50,000,000

| Structure | Investor payoff | Common payoff | Sum |
|---|---|---|---|
| Non-participating | `max($10,000,000, 0.25 × $50,000,000 = $12,500,000)` = **$12,500,000** (converts, since $50M > E* $40M) | **$37,500,000** | $50,000,000 ✓ |
| Participating | `$10,000,000 + 0.25 × ($50,000,000 − $10,000,000)` = $10,000,000 + $10,000,000 = **$20,000,000** | **$30,000,000** | $50,000,000 ✓ |

Participation moved **$7,500,000** from common to the investor at this exit
(common $37,500,000 → $30,000,000). Common is usually the employees — so
participation is a transfer out of the option-holders' pockets. Say it.

### Exit B: E = $10,000,000 (with a 1.5× preference = $15,000,000 floor)

The preference floor ($15,000,000) exceeds the entire exit ($10,000,000), so the
investor sweeps all $10,000,000 and **common gets $0** — under either structure.
This is why a "$10M sale" headline can be worthless to option-holders, and why
the 409A / common-preferred gap exists.

**Certification (sum-to-exit):** Exit A both structures sum to $50,000,000 ✓;
Exit B sums to $10,000,000 ✓.

---

## Anti-dilution (flag, don't compute unless asked)

- **Weighted-average** (civilized default): nudges the preferred's conversion
  price partway toward a down-round price, weighted by how much cheap new stock
  was issued.
- **Full-ratchet** (harsh): resets conversion price all the way to the
  down-round price; can crush common.

Anti-dilution protects the **investor** in a down round, never the founder.
Enforceability of the clause is a **lawyer** question — escalate it.
