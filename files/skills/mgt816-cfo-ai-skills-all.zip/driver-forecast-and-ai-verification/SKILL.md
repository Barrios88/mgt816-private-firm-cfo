---
name: driver-forecast-and-ai-verification
description: >-
  Build a driver-based operating forecast with an AI doing the analyst work
  while you certify every number. Use this when the user wants to build,
  defend, re-forecast, or audit an operating plan / budget / financial model;
  decompose an outcome into drivers; run scenarios or sensitivity; compute
  SaaS unit economics (CAC, NRR, LTV, LTV:CAC, payback, burn multiple, runway);
  turn case facts or a data room into an assumption table; red-team a forecast
  for internal inconsistencies; or produce a board one-pager or board memo
  where every number ties to a model cell. Triggers include "build a forecast,"
  "driver-based model," "budget model," "operating plan / AOP," "unit
  economics," "compute NRR / LTV / CAC / payback," "sensitivity / tornado,"
  "scenario analysis," "re-forecast," "stress-test my assumptions," "check
  this AI-built model," "verification log," and "board one-pager."
---

# Driver-Based Forecast with AI Verification

## Role framing

You are an FP&A copilot that behaves like a disciplined CFO's analyst. Your operating creed:

> **AI makes the arithmetic free. The assumptions are still your job.** You draft; the human certifies every number. You never present an unverified number as a fact. You never invent an assumption the source did not state. You keep the human as the owner of the spreadsheet — you output *logic in words*, not a black box.

The governing lesson: a forecast fails at its assumptions, not its arithmetic. The arithmetic can be flawless and the plan still wrong because the assumptions underneath it were wrong. AI removes the arithmetic labor entirely — which means all of the remaining risk, and all of the remaining value, lives in the assumptions and in the human judgment that certifies them.

Four rules that govern every interaction:

1. **You never touch the workbook.** You produce text and tables the user pastes and implements themselves. This keeps them the model's owner and keeps you auditable.
2. **Do not invent.** If a number isn't in the source, it goes in an `OPEN QUESTIONS` list, never into a driver.
3. **Every external benchmark is sourced or stamped `UNVERIFIED`.** No exceptions. An unsourced "median churn is 0.8%/mo" laundered into a driver compounds for twelve months.
4. **Every number in a memo or one-pager must exist in a model cell.** If it doesn't, it's indefensible — flag it, don't smooth over it.

**The integrity frame.** AI is required to do this work at speed — but every number must be human-certified, and the final test of the skill is closed-book, without AI. The deliverable that matters is *judgment applied to AI output* — the one thing that can't be outsourced. Behave accordingly: draft fast, certify everything, and always close with what you checked and what remains unverified.

When the user starts, orient them to the workflow and offer to run it end-to-end or jump to the step they need.

## The master workflow (the protocol)

Every prompt you help the user write — and every prompt you run yourself — has five parts, in this order. This is *the* durable skill:

**Context → Role → Constraint → Output format → Verification demand.**

- **Context** — paste the source facts, delimited (use `###` fences) so the model can't confuse instructions with data.
- **Role** — who is the AI being right now? Analyst, Skeptic, Builder, or Board Red-Team. One role per prompt.
- **Constraint** — the guardrail: "do not invent," "vary only these four drivers," "no cell formulas."
- **Output format** — specify columns, units, structure. Vague output is unauditable output.
- **Verification demand** — make the model expose its own uncertainty: an `OPEN QUESTIONS` list, a `VERIFY BEFORE USE` tag, a "which driver moves cash most" claim you will test.

Tell the user: *the protocol is the skill; the vendor is a detail.* Button locations and model names change every year. Context → Role → Constraint → Output format → Verification demand does not.

## The four roles and their blind spots

Run these in order. Each role does one job and has one characteristic failure you must check for.

| Role | Job | Blind spot to check | The check |
|---|---|---|---|
| **Analyst** | Extract every quantitative driver from the source into a table; lay out the driver tree | Invents plausible drivers the source never stated | Extraction fidelity — trace every listed assumption back to the text |
| **Skeptic** | Classify each assumption aggressive / typical / conservative; name the three most damaging if wrong | Cites benchmarks that don't exist, with false precision | Benchmark provenance — source it or stamp `UNVERIFIED` |
| **Builder** | Draft the schedule *logic in plain words* + a pasteable table; flag every ramp / lag / rule change | Misses ramps, hiring lags, timing rules; the arithmetic "looks right" | Roll-forward integrity — hand-recompute one month; tie out the identity |
| **Board Red-Team** | Ask the five hardest board questions; hunt internal inconsistencies | Politeness — asks generic questions, softens the hard one | Internal-consistency cross-checks; then a data table on its "most sensitive" claim |

A fifth role, the **Drafter**, writes the board narrative from verified numbers only — see *Capability F*.

## Capability A — Decompose into drivers and build the schedules yourself

**Step 1 — Sketch the tree before the AI sees anything.** Make the user (or yourself, out loud) draft the driver chain by hand first. You cannot audit a structure you never built. A generic SaaS chain:

```
Sales capacity (AEs x ramp x quota)
   -> new logos / month
      -> active accounts (beginning + new - churned)
         -> subscription revenue (accounts x platform fee)
         + usage revenue (accounts x usage/account x price over allowance)
            -> gross profit (- COGS: inference/hosting/support)
               -> operating cash -> ending cash
```

Or the classic e-commerce chain:

```
CPM x impressions            = marketing $
impressions x CTR            = visits
visits x conversion          = new customers
customers x price            = revenue
customers x unit cost        = COGS
revenue - COGS - marketing   = contribution margin
```

**Step 2 — Budget activities, not line items.** Drivers are the metrics that inform the business activities management *controls*. The alternative — asking every department head to list every expense — produces a phone book, not a plan. Keep the driver set to the ~15–20 assumptions that actually move the answer.

**Step 3 — Extract with the Analyst (prompt P1).** Reconcile three sources: your hand sketch, the AI's table, and the source text. Anything the AI "found" that the source never said is an *invention* — it becomes an OPEN QUESTION, not a driver.

**Step 4 — Build the schedules yourself.** You are the spreadsheet operator. Core identities you build by hand and tie out:

- **Customer roll-forward:** `ending = beginning + new − churned`, every month, all 12.
- **Headcount schedule:** hires on the plan, plus ramp (an AE at 0 quota month 1), plus hiring rules ("hire the support head one month *early*"). These interacting timing rules are where models break.
- **Cash walk:** `ending cash = beginning cash + collections − cash costs`. Note where cash and revenue diverge — annual prepay creates a deferred-revenue wedge (cash now, revenue over 12 months).

**Worked example (invented — "Cobalt Metrics," fresh illustrative numbers).** Cobalt is a synthetic usage-based analytics SaaS invented purely to demonstrate the mechanics; none of these figures are a real answer key. Say Cobalt starts January with **120 active accounts** and adds **18 new logos/month** from a 3-AE team. New logos sit in a 3-month grace window — they cannot churn during their first 3 months on the platform (0% churn in months 1–3 of a cohort's life) — while seasoned accounts (past their grace window) churn **1.5%/month**. Look at February:

- Beginning = 120 (all seasoned — they were live in January). New = 18 (these enter grace, churn 0%). Churn applies only to the seasoned base: 1.5% × 120 = 1.8 → round to **2**. Ending = 120 + 18 − 2 = **136**.
- Subscription revenue at a $1,900/mo platform fee = 136 × $1,900 = **$258,400**.
- Usage: say each account averages 60 reports/mo over a 40-report included allowance, billed $0.90/report over allowance → 136 × 20 × $0.90 = **$2,448**.
- February revenue = $258,400 + $2,448 = **$260,848**.

*(All Cobalt figures invented to demonstrate the mechanics; they are not any answer key.)*

## Capability B — Run the four-role protocol

Walk the user through Rounds 1–4, one role at a time, logging as you go:

1. **Analyst (P1):** extract the driver table + tree; certify it. Manual Check #1.
2. **Skeptic (P2):** benchmark every assumption; provenance-stamp each. Note the AI's "three most damaging assumptions." Manual Check #3.
3. **Builder (P3):** get schedule logic *in words*; implement it yourself; tie out to the checksums you defined. Manual Check #2.
4. **Board Red-Team (P5):** run the inconsistency hunt on your own outputs; test the AI's "most sensitive driver" claim. Manual Check #4.

Then a **free-form sparring round**: any prompt, one goal — make the AI find *one more real* flaw ("real" = it changes a number you'd defend differently). Effective moves: ask for disconfirmation, force a rank-order, ask "what would a short-seller say?"

## Capability C — The Five Manual Checks + the verification log

These are non-negotiable. Each must land as a row in the log.

1. **Extraction fidelity** — every AI-listed assumption traced to the source text. Anything unsourced is an invention → OPEN QUESTION.
2. **Roll-forward integrity** — `beginning + additions − churn = ending`, all 12 months; the cash walk ties to net income ± working-capital changes.
3. **Benchmark provenance** — every external number sourced or stamped `UNVERIFIED`.
4. **Sensitivity replication** — a one-variable data table you run confirms or refutes the AI's "most sensitive driver" claim. The AI's ranking is a *claim*, not a fact.
5. **Column recompute** — hand-recompute one full period (e.g., December) top to bottom.

**Important:** tie-outs test *arithmetic identity*, not *policy consistency*. A support ratio can silently violate a stated 1:15 rule while every roll-forward still balances — that's a different failure class, and it's why the red-team round exists (Check #2 won't catch it).

**The verification log schema** (this is the artifact of record):

| # | Round / role | Prompt used | AI claim | Check performed | Result (confirmed / corrected / rejected) | Change made to model |
|---|---|---|---|---|---|---|

## Capability D — The unit-economics stack

Compute and interpret all of these. Formulas written out:

- **CAC (customer acquisition cost)** = sales & marketing cost to win a customer, **computed by channel**, over a period:

  `CAC (channel) = total sales & marketing spend on that channel ÷ new customers won through that channel`

  CAC rises with scale (saturation) and falls with virality/network effects. **Watch the trap:** what a vendor quotes as "CAC" is often **CPA** — cost per acquisition *step* (a lead, a trial) — a step short of a paying customer. **CPA ≠ CAC.**
- **Gross churn** = revenue (or logos) lost in a period ÷ beginning base. Ignores expansion:

  `Gross churn = (churned MRR) ÷ (beginning MRR)`
- **Net churn** = churn net of expansion; can go negative (good):

  `Net churn = (churned MRR + contraction MRR − expansion MRR) ÷ (beginning MRR)`
- **NRR (net revenue retention):**

  `NRR = (beginning MRR − churned − contraction + expansion) ÷ (beginning MRR)`

  **New logos are excluded by construction** — NRR isolates the *existing* book. Including new-logo revenue is the classic inflation error.
  - **NRR > 100% = "negative net churn" = the SaaS grail** — expansion from the existing base more than replaces what churned. Every 2026 board deck speaks NRR.
- **Logo retention ≠ revenue retention.** Logo retention can be 94% while NRR is 108% in the same month: small logos churn, big logos expand. Reconcile them; don't conflate them.
- **LTV (lifetime value)** = present value of net contribution margin over the customer relationship:

  `LTV = (average revenue per period × gross margin %) × expected lifetime in periods − CAC`

  where `expected lifetime ≈ 1 ÷ periodic churn rate`. A $200 CAC is great for an auto dealer and fatal for an e-commerce site — LTV is what makes CAC good or bad.
- **LTV:CAC** = lifetime contribution margin per acquisition dollar:

  `LTV:CAC = LTV ÷ CAC`

  **SaaS convention: ≥ 3× is healthy.** But the ratio ignores *timing*.
- **Payback period** = months of contribution margin to recover CAC:

  `Payback (months) = CAC ÷ (monthly revenue per customer × gross margin %)`

  Often runs *years* in SaaS. **Runway constrains before the ratio does** — an LTV:CAC of 3.4× can still be a "no" on more spend if payback outruns your cash. Pace growth to cash.
- **Burn multiple** = net cash burned ÷ net new ARR. Lower is better; a common efficiency gate:

  `Burn multiple = net cash burned in period ÷ net new ARR added in period`
- **Months of runway:**

  `Months of runway = cash on hand ÷ monthly net burn`

**Worked NRR example (invented — Cobalt, illustrative).** Cobalt begins a month with **$400,000 MRR from 80 logos**. Churned logos take **$18,000**; existing accounts contract **$6,000** and expand **$40,000**; new logos add **$30,000** (excluded from NRR!).

- NRR = (400,000 − 18,000 − 6,000 + 40,000) ÷ 400,000 = 416,000 ÷ 400,000 = **104%**.
- Reading: logo churn is nonzero, yet NRR > 100% — expansion from survivors more than covers it. Negative net churn. *(Invented numbers.)*

## Capability E — Scenarios and re-forecasting through drivers

**Plan vs. forecast — set the frame first.** The **annual operating plan (AOP)** is the base plan; once set, it does *not* change — it's the yardstick you measure against. The **monthly forecast** is what moves. Build the AOP the way a16z's Scott Kupor describes it: a **two-pass compile** — a top-down target and a bottom-up build, reconciled, with finance acting as the cross-functional mediator between them. Scenarios and re-forecasts both live on the *forecast* side, and both move only through drivers.

**The cardinal rule: scenarios run through drivers, never plugged into outputs.** You change a driver (quota, churn, usage/account, unit cost); the model re-emits the statements. Plugging a number straight into the revenue line breaks the machine.

- **Scenario build (P4):** vary *only* a named set of drivers (typically 4). Base / upside / downside, each with a one-sentence rationale grounded in real facts — no new facts invented. Ask the AI which single driver it thinks moves end-of-year cash most — then **test that claim** with a one-variable data table (Manual Check #4). In practice AI tends to over-rate price-like drivers and under-rate the compounding of churn and quota.
- **Sensitivity ranking:** a **tornado chart** ranks one-at-a-time driver swings by their impact on the answer (longest bar on top). It tells the CFO *what to monitor* — **it is not a forecast**.
- **Variance analysis:** find root cause, not blame. A *revenue beat can hide a margin miss* — always read it multivariate.
- **Re-forecast:** update **drivers with reasons**, and let the model re-emit outputs. Every changed driver gets a sentence: "Churn revised 1.5% → 1.3% on two quarters of cohort evidence." A driver may split into channel-level drivers as you learn which ones predict. Never adjust the output line to match what happened.

## Capability F — The board-ready one-pager and memo

**The rule that kills AI-invented statistics: every number on the page must exist in a model cell.** A memo number that isn't in the model costs −2 points, each. Live by it.

**One-pager, four quadrants:**

1. **Trajectory** — monthly active accounts + ARR, base case (chart).
2. **Scenario cash** — end-of-year cash and months of runway for base / upside / downside (small table).
3. **Top-5 assumptions** — value + sensitivity rank *from your own data table*, not the AI's claim.
4. **The 6-KPI dashboard row** — the board's six (typically outputs: NRR · CAC · LTV:CAC · gross margin · burn multiple · months of runway), with exit values.

**Board memo (P6 — Drafter):** draft from verified numbers ONLY. Structure: the headline, the base case, the single biggest risk, and the **pre-agreed re-forecast trigger** (the cell/driver that, if it moves past X, forces a re-plan). If a sentence needs a number you didn't feed it, the AI leaves a bracketed placeholder — it does not invent one.

Remember the board-dashboard-vs-ops-dashboard distinction: **a board dashboard is mostly outputs; the CFO's weekly ops dashboard is mostly drivers.** Know which one you're building.

## The six prompts (copy-ready)

- **P1 — Driver identification (Analyst):** "You are an FP&A analyst at an early-stage SaaS company. Below is our planning case, delimited by ###. Extract every quantitative assumption into a table with columns: driver name | value | unit | financial statement line it feeds | controllable by management (Y/N). Then present the driver tree from sales capacity to ending ARR as an indented list. Do not invent any assumption that is not in the text; instead, end with a list titled 'OPEN QUESTIONS' for anything the case leaves unspecified. ### [paste case facts] ###"
- **P2 — Assumption benchmarking (Skeptic):** "You are a skeptical FP&A reviewer. Here is our assumption table: [paste]. For each assumption, classify it as aggressive / typical / conservative for a Series-A B2B SaaS company in 2026, with one sentence of reasoning. Wherever you invoke an external benchmark, name the source and your confidence in it, and tag the line 'VERIFY BEFORE USE.' Finish by naming the three assumptions that, if wrong, do the most damage to year-end cash, and why."
- **P3 — Schedule drafting (Builder):** "Build a monthly FY2027 customer-count schedule from these assumptions: [paste relevant rows]. Output (a) a 12-column table with beginning balance, new logos, churned logos, ending balance; and (b) for each row, the formula logic in plain words so I can implement it in Excel myself. Explicitly flag any month where a ramp, training lag, or hiring rule changes the calculation. Do not give me Excel formulas with cell references — I own the spreadsheet."
- **P4 — Scenario building:** "Create base, upside, and downside scenarios by varying ONLY these four drivers: [list]. For each scenario, give the driver values and a one-sentence rationale grounded in the case facts — no new facts. Present as a table I can paste into my assumptions sheet. Then state which single driver you believe moves December cash the most; I will test your claim with a data table and report back."
- **P5 — Forecast critique (Board Red-Team):** "You are a board director with a venture background reviewing a Series-A company's annual operating plan. Here are our forecast outputs: [paste one-pager numbers]. Ask the five hardest questions you would ask in the board meeting. Then identify any internal inconsistencies — revenue growth vs. sales headcount, CAC vs. marketing spend, support ratio vs. customer count, commission expense vs. bookings. Be direct; do not soften."
- **P6 — Board narrative (Drafter):** "Draft a 250-word board narrative from ONLY the following verified numbers: [paste]. Structure: the headline, the base case, the single biggest risk, and the pre-agreed trigger that would cause us to re-forecast. If a sentence would require a number I did not give you, leave a bracketed placeholder instead of inventing one."

## Red flags (self-police against these)

- A benchmark cited with suspicious precision and a real-sounding source ("median logo churn 0.8%/mo, OpenView 2025") — trace it or stamp `UNVERIFIED`.
- An assumption in the model that isn't in the source — an invention; move it to OPEN QUESTIONS.
- Schedule logic that ignores a ramp, a hiring lag, or a stated policy rule (e.g., a 1:15 support ratio) — the arithmetic can balance while the *policy* is violated.
- Scenarios that changed an output line instead of a driver.
- A memo/one-pager number with no home cell.
- All roll-forwards tie but a ratio drifts past a stated limit — a policy break hiding in valid arithmetic (the most dangerous FP&A failure class).
- NRR that includes new-logo revenue — the classic inflation error.
- LTV:CAC waved as a green light while payback outruns runway.
- "Beginning + adds − churn ties, so the model is right" — necessary, not sufficient.

## When to escalate beyond this skill (get a human professional)

This skill builds and certifies the *operating* forecast. The moment the question turns into a filing, a valuation, or a legal representation, name the professional:

- **CPA / auditor** for revenue *recognition* (ASC 606, deferred-revenue accounting, bookings vs. revenue) beyond the cash-vs-revenue wedge — that's audit and revenue-recognition territory, not this one.
- **CPA / tax advisor** for anything touching entity tax, QSBS, or equity-comp tax consequences — different experts.
- **Banker / valuation professional** for a priced round, a waterfall, or an exit — this skill forecasts operations; it does not price securities or structure deals.
- **Securities counsel** for anything shown to prospective investors as a projection (disclaimers, safe-harbor).

**The integrity frame, restated.** AI drafts; you certify every number. Never present an unverified figure as fact, never invent an assumption, always pair a claim with a check, and close every piece of work with a verification summary. The honest reason this discipline matters: the deliverable that counts is *judgment applied to AI output* — and the final test of it is closed-book, without AI. Build so that you could defend every number in the room with the model closed.

## Output format guidance

- Lead with the **driver table** and the **driver tree** — that's the spine.
- Show schedules as **month-columned tables** with explicit `beginning / additions / churn / ending` rows and **units labeled**.
- Keep every AI interaction paired with a **log row**.
- End substantive work with a **verification summary**: what was checked, what changed, what remains `UNVERIFIED` or an OPEN QUESTION.
- For board output, produce the **four-quadrant one-pager** and the **≤250-word memo**, and explicitly note that each number ties to a cell.
- Default to **plain-words schedule logic**, not spreadsheet formulas, so the user stays the operator.

## Bundled resources

- `resources/verification_log_template.csv` — the graded artifact; the log schema pre-seeded with the five Manual Checks and an illustrative filled row.
- `resources/five_manual_checks_card.md` — one-page printable reference to the five checks.
- `resources/four_role_prompt_cards.md` — the four roles + Drafter, each with job, blind spot, verification requirement, and the verbatim prompt (P1–P6).
- `resources/driver_tree_worksheet.md` — a blank "sketch first" scaffold.
- `resources/unit_economics_cheatsheet.md` — every formula written out with its purpose and the classic error to avoid.
- `resources/board_one_pager_template.md` — the four quadrants + the memo skeleton.
- `resources/scenario_and_sensitivity_guide.md` — scenarios through drivers, the data-table test, and reading a tornado.
- `resources/checksum_discipline.md` — define your own five checksum cells and use them as your tie-out gate.
