# Board One-Pager + Memo Template

**The rule that governs this whole page: every number here must exist in a model cell.** A number on the board page with no home cell is indefensible — in this course it costs **−2 points, each**. Before you ship, point at every figure and name its cell.

*Know which artifact you're building: a **board dashboard is mostly outputs**; the CFO's **weekly ops dashboard is mostly drivers**. This template is the board version.*

*(All figures below are invented "Cobalt Metrics" placeholders to show the shape — replace with your own certified numbers.)*

---

## Quadrant 1 — Trajectory (chart)
Monthly **active accounts** and **ARR**, base case, all 12 months. One line each. This is the "are we on plan" picture.

```
Active accounts:  Jan 120 ... Dec 268        (base case)
ARR ($M):         Jan 3.1 ... Dec 4.6        (base case)
```

## Quadrant 2 — Scenario cash (small table)
End-of-year cash and months of runway across scenarios.

| Scenario | EOY cash | Months of runway |
|---|---|---|
| Downside | $2,190,000 | 6 |
| Base | $3,960,000 | 11 |
| Upside | $5,180,000 | 15 |

## Quadrant 3 — Top-5 assumptions (value + sensitivity rank)
Ranked **from your own one-variable data table**, not the AI's claim.

| Rank | Assumption | Base value | Cash impact of its swing |
|---|---|---|---|
| 1 | Monthly churn rate | 1.5% | $520,000 |
| 2 | Quota per AE | (your value) | $410,000 |
| 3 | Usage per account | 60 reports/mo | $180,000 |
| 4 | Usage price over allowance | $0.90/report | $95,000 |
| 5 | (your fifth driver) | — | — |

## Quadrant 4 — The 6-KPI dashboard row (exit values)
The board's six — typically **outputs**.

| NRR | CAC | LTV:CAC | Gross margin | Burn multiple | Months of runway |
|---|---|---|---|---|---|
| 104% | $21,000 | 3.4× | 75% | 0.45× | 11 |

---

## Board memo skeleton (P6 — the Drafter)

Draft from **verified numbers only**. If a sentence needs a number you didn't supply, leave a **bracketed placeholder** — never invent one. Keep it to ≤250 words.

1. **The headline** — the one sentence the board should remember (e.g., "We exit the year at [Dec ARR] with [months] of runway, on plan").
2. **The base case** — the trajectory and the two or three drivers carrying it.
3. **The single biggest risk** — the assumption whose failure hurts most, and by how much (from your data table).
4. **The pre-agreed re-forecast trigger** — the specific cell/driver that, if it crosses X, forces a re-plan. Name it now, in calm times, so the mid-year conversation is about a pre-committed rule, not a panic.

**P6 prompt (copy-ready):**
> Draft a 250-word board narrative from ONLY the following verified numbers: [paste]. Structure: the headline, the base case, the single biggest risk, and the pre-agreed trigger that would cause us to re-forecast. If a sentence would require a number I did not give you, leave a bracketed placeholder instead of inventing one.

---

**Final gate before you send:** walk every number on this page back to a model cell. Any orphan is a −2 waiting to happen — and a credibility hit in the room.
