# The Five Manual Checks — one-page reference

*Print this. Run it on any model — one an AI built, one a colleague handed you, one you built yourself. Each check must land as a row in your verification log.*

The governing idea: **AI makes the arithmetic free. The assumptions are still your job.** The AI can produce a model that ties out perfectly and is still wrong. These five checks are the minimum you owe every number before you certify it.

---

## Check #1 — Extraction fidelity
**Identity/action:** Trace every assumption the AI listed back to a specific sentence in the source. Anything you cannot find in the source is an *invention*.
**If it fails:** Move the invented item to an `OPEN QUESTIONS` list. It never enters the model as a driver.

## Check #2 — Roll-forward integrity
**Identity/action:** For every balance that rolls, confirm `ending = beginning + additions − churn` for all 12 months. Confirm the cash walk ties to net income ± working-capital changes.
**If it fails:** Find the month where the identity breaks; that's your timing bug (usually a ramp, a lag, or an off-by-one).

## Check #3 — Benchmark provenance
**Identity/action:** Every external number is sourced or stamped `UNVERIFIED`. Name the source and your confidence. A precise-looking benchmark with a real-sounding citation ("median churn 0.8%/mo, OpenView 2025") gets traced or stamped — never trusted on sight.
**If it fails:** Stamp the line `UNVERIFIED` and hold the driver at a defensible value until you can source it. An unsourced benchmark laundered into a driver compounds for twelve months.

## Check #4 — Sensitivity replication
**Identity/action:** The AI's "most sensitive driver" is a *claim*, not a fact. Run your own one-variable data table across the candidate drivers and rank them yourself.
**If it fails:** Re-rank from your own table. (AI tends to over-rate price-like drivers and under-rate the compounding of churn and quota.)

## Check #5 — Column recompute
**Identity/action:** Pick one full period (e.g., December) and hand-recompute it top to bottom — drivers → schedules → statements — independent of the model's own formulas.
**If it fails:** You've found a formula error the roll-forward didn't surface.

---

## The warning that makes this list matter

**Tie-outs test *arithmetic identity*, not *policy consistency*.** A support ratio can silently violate a stated 1:15 rule while every roll-forward still balances. A commission expense can drift out of line with bookings while the cash walk ties perfectly. These are a different failure class — the most dangerous one in FP&A, because the arithmetic gives you false comfort. Checks #2 and #5 will *not* catch them. That is precisely why the Board Red-Team round exists: to hunt the policy break hiding inside valid arithmetic.
