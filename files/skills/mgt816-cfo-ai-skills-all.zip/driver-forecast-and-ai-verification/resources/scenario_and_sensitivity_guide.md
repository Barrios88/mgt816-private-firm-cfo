# Scenarios & Sensitivity — the driver discipline

**The cardinal rule: scenarios run *through drivers*, never plugged into outputs.** You change a driver — quota, churn, usage per account, unit cost — and let the model re-emit the statements. The moment you type a number straight into the revenue line, you've broken the machine: the outputs no longer descend from assumptions you can defend.

---

## 1. Building scenarios (P4)

Vary **only a named set of drivers** — typically four. Build base / upside / downside, each with a **one-sentence rationale grounded in the case facts**. No new facts invented for a scenario; if you're tempted to invent one, it's an OPEN QUESTION instead.

**P4 prompt (copy-ready):**
> Create base, upside, and downside scenarios by varying ONLY these four drivers: [list]. For each scenario, give the driver values and a one-sentence rationale grounded in the case facts — no new facts. Present as a table I can paste into my assumptions sheet. Then state which single driver you believe moves December cash the most; I will test your claim with a data table and report back.

The AI's "most sensitive driver" answer is a **claim, not a fact.** Write it down — you're about to test it.

---

## 2. Testing the claim — the one-variable data table (Manual Check #4)

You do not take the AI's word for which driver matters most. You measure it.

1. Pick your output of record (e.g., **December ending cash**).
2. For each candidate driver, hold everything else at base and sweep the driver across a plausible low→high range.
3. Record the output at each point. The **swing** (high output − low output) is that driver's sensitivity.
4. Rank drivers by swing. **Longest swing = most sensitive.**

In practice, AI tends to **over-rate price-like drivers** and **under-rate the compounding of churn and quota** — churn especially, because its effect compounds month over month while a price change is roughly linear. Your data table catches this; the AI's intuition doesn't.

---

## 3. Reading a tornado chart

A **tornado chart** stacks each driver's one-at-a-time swing as a horizontal bar, **longest bar on top**. It answers one question: *what should the CFO watch?*

**It is not a forecast.** It is a ranking of where the answer is most fragile — a monitoring tool, not a prediction.

**Illustrative tornado (invented Cobalt drivers, ranked by impact on December cash):**

```
Monthly churn      1.2% – 1.8%          | ####################  $520,000
Quota per AE       (low – high)         | ###############       $410,000
Usage per account  52 – 68 reports      | #######               $180,000
Usage price        $0.80 – $1.00        | ####                  $95,000
```

Note the shape: churn on top, price on the bottom — exactly the pattern a naive AI ranking tends to get backwards. *(All swings invented for illustration.)*

---

## 4. Variance analysis — root cause, not blame

When actuals diverge from plan, decompose the miss to its driver. Read it **multivariate**: a **revenue beat can hide a margin miss** (you grew by discounting). Never stop at the top line.

---

## 5. Re-forecasting — "update drivers with reasons"

A re-forecast is **not** overwriting the output line to match what happened. It is:

- Update the **drivers**, each with a one-sentence reason: *"Churn revised 1.5% → 1.3% on two quarters of cohort evidence."*
- Let the model **re-emit** the outputs from the revised drivers.
- Split a driver into channel- or cohort-level drivers as you learn which ones actually predict.

**Never** adjust an output to match actuals. That destroys the one thing the model is for: the traceable line from assumption to result.

---

*The base plan (AOP) is fixed once set; the monthly forecast is what moves. Scenarios and re-forecasts both live on the forecast side — and both move only through drivers.*
