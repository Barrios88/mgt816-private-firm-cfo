# Checksum Discipline — your personal tie-out gate

Before you trust *any* model — one an AI built, one a colleague handed you, one you built at 2 a.m. — define a handful of **checksum cells** and reconcile to them by hand. A checksum is a single number you can recompute independently; if the model's cell and your hand figure disagree, something upstream is wrong. Checksums are how you catch a break you'd otherwise present to the board.

**Define five. Recompute each by hand. Only then do you trust the model.**

---

## The five checksum cells (a good default set)

| # | Checksum cell | Why it's a good gate | How you recompute it by hand |
|---|---|---|---|
| 1 | **December ending accounts** | Catches any roll-forward break across all 12 months | Chain `ending = beginning + new − churned` from January; the December ending must match |
| 2 | **FY total revenue** | Catches a summation, a units, or a mid-year rule-change error | Sum the 12 monthly revenue figures independently of the model's own SUM |
| 3 | **December total headcount** | Catches a hiring-lag or ramp timing bug | Add up the hiring plan month by month, honoring every "hire one month early" rule |
| 4 | **December deferred-revenue balance** | Catches the cash-vs-revenue wedge (annual prepay) | Roll deferred revenue forward: `+ cash collected on annual plans − revenue recognized` each month |
| 5 | **December ending cash** | The number the board actually cares about; catches the cash walk | `beginning cash + collections − cash costs`, chained across all 12 months |

---

## How to use them

1. **Before you trust the model**, compute all five by hand (or in a separate scratch tab) — *independently* of the model's own formulas.
2. If a checksum ties, that leg of the model earns provisional trust.
3. If a checksum **breaks**, walk backward month by month to the first month it diverges. That month holds the bug — usually a ramp, a lag, an off-by-one, or a units mismatch.
4. Log the result. A checksum reconciliation is a **roll-forward integrity** row (Manual Check #2) in your verification log.

---

## The warning that keeps you honest

**A checksum that ties proves the *arithmetic*, not the *policy*.** All five can tie while a support ratio quietly violates a stated 1:15 rule, or a commission line drifts out of step with bookings. Those are policy breaks hiding inside valid arithmetic — the most dangerous FP&A failure class, and the reason the Board Red-Team round exists. Checksums are necessary. They are not sufficient.

---

## Illustrative checksum set (invented "Cobalt Metrics")

*Numbers invented purely to show the shape — yours will differ.*

| Checksum | Value |
|---|---|
| December ending accounts | 268 |
| FY total revenue | $3,180,000 |
| December total headcount | 22 |
| December deferred-revenue balance | $640,000 |
| December ending cash | $3,960,000 |

*(These are illustrative placeholders, not an answer key. Derive your own from your own model and reconcile to them before you certify a single output.)*
