# Unit Economics Cheatsheet

*Every formula written out, each with what it's for and the classic error to avoid. All numbers below are invented ("Cobalt Metrics," a synthetic SaaS) purely to show the mechanics — none is an answer key.*

---

## CAC — Customer Acquisition Cost
**Formula:** `CAC (channel) = sales & marketing spend on that channel ÷ new paying customers won through that channel`
**What it's for:** the true, all-in cost to win one paying customer — computed *by channel*, because blended CAC hides the channel that's actually underwater.
**Behavior:** rises with scale (you saturate the cheap audience first), falls with virality / network effects.
**Illustrative:** paid-search spend of $189,000 in the quarter won 9 new paying customers → CAC = $189,000 ÷ 9 = **$21,000**.
**Classic error — CPA ≠ CAC.** What a vendor calls "CAC" is often **CPA**: cost per acquisition *step* (a lead, a trial, a demo), a step short of a paying customer. Example: a vendor quotes "$1,500 CAC," but that's really cost per demo booked; if it takes ~14 demos to land one paying logo, true CAC ≈ $1,500 × 14 = **$21,000**. Always ask: *cost per what?*

---

## Gross churn
**Formula:** `Gross churn = churned MRR ÷ beginning MRR`
**What it's for:** the raw bleed from the existing book, ignoring any expansion.
**Illustrative:** $18,000 churned ÷ $400,000 beginning MRR = **4.5%**.
**Classic error:** reporting gross churn as if it were the whole retention story — it hides expansion entirely.

---

## Net churn
**Formula:** `Net churn = (churned MRR + contraction MRR − expansion MRR) ÷ beginning MRR`
**What it's for:** churn *after* the existing base's expansion is netted in. Can go negative — which is good.
**Illustrative:** ($18,000 churned + $6,000 contraction − $40,000 expansion) ÷ $400,000 = −$16,000 ÷ $400,000 = **−4.0%** (negative net churn).

---

## NRR — Net Revenue Retention
**Formula:** `NRR = (beginning MRR − churned − contraction + expansion) ÷ beginning MRR`
**What it's for:** how the *existing* book alone is doing. **New logos are excluded by construction.**
**Illustrative:** ($400,000 − $18,000 − $6,000 + $40,000) ÷ $400,000 = $416,000 ÷ $400,000 = **104%**.
**Reading:** NRR > 100% = **"negative net churn" = the SaaS grail** — expansion from survivors more than replaces what churned. Every 2026 board deck speaks NRR.
**Classic error — the inflation trap:** folding new-logo revenue into NRR. If you had added $30,000 of new-logo MRR and counted it, you'd report a flattering fake. New logos are *not* retention.

---

## Logo retention ≠ revenue retention
**What it's for:** two different questions — *how many customers stayed* vs. *how many dollars stayed*.
**Illustrative:** logo retention can be **94%** in the same month NRR is **104%**: small logos churn while big logos expand.
**Classic error:** conflating them. Reconcile the two; a healthy NRR can sit on top of ugly logo churn (concentration risk).

---

## LTV — Lifetime Value
**Formula:** `LTV = (revenue per period × gross margin %) × expected lifetime in periods − CAC`, where `expected lifetime ≈ 1 ÷ periodic churn rate`
**What it's for:** the present value of net contribution margin a customer throws off over the relationship.
**Illustrative:** $1,900/mo revenue × 75% gross margin = $1,425/mo contribution; average retained lifetime ≈ 50 months → gross LTV = $1,425 × 50 = **$71,250**.
**Classic error:** judging CAC in a vacuum. A $200 CAC is great for an auto dealer and fatal for an e-commerce site — **LTV is what makes CAC good or bad.**

---

## LTV:CAC
**Formula:** `LTV:CAC = LTV ÷ CAC`
**What it's for:** lifetime contribution margin per acquisition dollar.
**Illustrative:** $71,250 ÷ $21,000 = **3.4×**.
**Convention:** **≥ 3× is healthy** for SaaS.
**Classic error:** treating the ratio as sufficient. **It ignores timing** — see payback.

---

## Payback period
**Formula:** `Payback (months) = CAC ÷ (monthly revenue per customer × gross margin %)`
**What it's for:** how many months of contribution margin it takes to earn CAC back. Often runs *years* in SaaS.
**Illustrative:** $21,000 ÷ $1,425 = **14.7 months**.
**Classic error — runway constrains before the ratio does.** An LTV:CAC of 3.4× still looks great, but if payback is 14.7 months and you hold only **11 months of runway** ($3,960,000 cash ÷ $360,000 monthly net burn), you can't afford to keep spending at that pace. Pace growth to cash.

---

## Burn multiple
**Formula:** `Burn multiple = net cash burned in period ÷ net new ARR added in period`
**What it's for:** capital efficiency — dollars burned to buy a dollar of new recurring revenue. **Lower is better.**
**Illustrative:** $600,000 burned ÷ $1,320,000 net new ARR = **0.45×**.
**Classic error:** celebrating ARR growth without asking what it cost to buy.

---

## Months of runway
**Formula:** `Months of runway = cash on hand ÷ monthly net burn`
**What it's for:** the clock. Every spend decision is really a decision against this number.
**Illustrative:** $3,960,000 ÷ $360,000 = **11 months**.
**Classic error:** planning growth as if the clock weren't running. The runway is the binding constraint most plans pretend away.

---

*(Every figure here is invented for illustration. Compute your own from your own model — and every number you present must live in a model cell.)*
