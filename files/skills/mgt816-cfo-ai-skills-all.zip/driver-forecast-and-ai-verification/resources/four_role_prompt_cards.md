# The Four Roles (+ Drafter) — prompt cards

*The durable take-home. Run the roles in order, one role per prompt. Every prompt follows the master protocol:*

**Context → Role → Constraint → Output format → Verification demand.**

*The protocol is the skill; the vendor is a detail. Model names and button locations change every year — this sequence does not.*

---

## Round 1 — ANALYST
**Job:** Extract every quantitative driver from the source into a table; lay out the driver tree.
**Blind spot to check:** Invents plausible drivers the source never stated.
**Verification requirement:** *Extraction fidelity* — trace every listed assumption back to the source text; anything unsourced becomes an OPEN QUESTION, not a driver. (Manual Check #1.)

**P1 — Driver identification:**
> You are an FP&A analyst at an early-stage SaaS company. Below is our planning case, delimited by ###. Extract every quantitative assumption into a table with columns: driver name | value | unit | financial statement line it feeds | controllable by management (Y/N). Then present the driver tree from sales capacity to ending ARR as an indented list. Do not invent any assumption that is not in the text; instead, end with a list titled 'OPEN QUESTIONS' for anything the case leaves unspecified. ### [paste case facts] ###

---

## Round 2 — SKEPTIC
**Job:** Classify each assumption aggressive / typical / conservative; name the three most damaging if wrong.
**Blind spot to check:** Cites benchmarks that don't exist, with false precision.
**Verification requirement:** *Benchmark provenance* — source every external number or stamp it `UNVERIFIED`. (Manual Check #3.)

**P2 — Assumption benchmarking:**
> You are a skeptical FP&A reviewer. Here is our assumption table: [paste]. For each assumption, classify it as aggressive / typical / conservative for a Series-A B2B SaaS company in 2026, with one sentence of reasoning. Wherever you invoke an external benchmark, name the source and your confidence in it, and tag the line 'VERIFY BEFORE USE.' Finish by naming the three assumptions that, if wrong, do the most damage to year-end cash, and why.

---

## Round 3 — BUILDER
**Job:** Draft the schedule *logic in plain words* + a pasteable table; flag every ramp, lag, and rule change.
**Blind spot to check:** Misses ramps, hiring lags, timing rules; the arithmetic "looks right."
**Verification requirement:** *Roll-forward integrity* — hand-recompute one month; tie out `beginning + additions − churn = ending`. (Manual Check #2.) You own the spreadsheet — the AI gives you logic in words, never cell formulas.

**P3 — Schedule drafting:**
> Build a monthly FY2027 customer-count schedule from these assumptions: [paste relevant rows]. Output (a) a 12-column table with beginning balance, new logos, churned logos, ending balance; and (b) for each row, the formula logic in plain words so I can implement it in Excel myself. Explicitly flag any month where a ramp, training lag, or hiring rule changes the calculation. Do not give me Excel formulas with cell references — I own the spreadsheet.

---

## Round 4 — BOARD RED-TEAM
**Job:** Ask the five hardest board questions; hunt internal inconsistencies.
**Blind spot to check:** Politeness — asks generic questions, softens the hard one.
**Verification requirement:** Internal-consistency cross-checks (revenue vs. headcount, CAC vs. spend, support ratio vs. customers, commissions vs. bookings); then run a data table on its "most sensitive" claim. (Manual Check #4.)

**P5 — Forecast critique:**
> You are a board director with a venture background reviewing a Series-A company's annual operating plan. Here are our forecast outputs: [paste one-pager numbers]. Ask the five hardest questions you would ask in the board meeting. Then identify any internal inconsistencies — revenue growth vs. sales headcount, CAC vs. marketing spend, support ratio vs. customer count, commission expense vs. bookings. Be direct; do not soften.

**Also useful for scenarios (P4 — Scenario building):**
> Create base, upside, and downside scenarios by varying ONLY these four drivers: [list]. For each scenario, give the driver values and a one-sentence rationale grounded in the case facts — no new facts. Present as a table I can paste into my assumptions sheet. Then state which single driver you believe moves December cash the most; I will test your claim with a data table and report back.

---

## Fifth role — DRAFTER
**Job:** Write the board narrative from verified numbers ONLY.
**Verification requirement:** Every number on the page ties to a model cell. A memo number that isn't in the model is indefensible (−2 points, each). If a sentence needs a number you didn't feed it, the AI leaves a bracketed placeholder — it does not invent one.

**P6 — Board narrative:**
> Draft a 250-word board narrative from ONLY the following verified numbers: [paste]. Structure: the headline, the base case, the single biggest risk, and the pre-agreed trigger that would cause us to re-forecast. If a sentence would require a number I did not give you, leave a bracketed placeholder instead of inventing one.

---

## After the four rounds — free-form sparring
One prompt, one goal: make the AI find *one more real* flaw — "real" means it changes a number you would then defend differently. Effective moves: ask for disconfirmation, force a rank-order, ask "what would a short-seller say?"
