# Driver Tree Worksheet — sketch first, before the AI sees anything

**Rule:** Fill this in *by hand* before you paste a single case fact into an AI. You cannot audit a structure you never built. The AI's job is to extract and pressure-test *your* tree — not to hand you one you never reasoned through.

For every node, name three things: its **source** (what sentence in the case gives it, or write `OPEN QUESTION`), its **unit**, and whether it is **controllable by management (Y/N)**. A driver you cannot source is not a driver yet.

---

## The chain (fill each blank)

```
Sales capacity  =  AEs (____) x ramp (____) x quota (____)
   |   source: __________   unit: __________   controllable: Y / N
   v
New logos / month  =  ____
   |   source: __________   unit: logos/mo    controllable: Y / N
   v
Active accounts  =  beginning (____) + new (____) - churned (____)
   |   source: __________   unit: accounts    controllable: Y / N
   |   churn rate: ____   grace window: ____
   v
Subscription revenue  =  active accounts x platform fee (____)
   |   source: __________   unit: $/mo        controllable: Y / N
   +
Usage revenue  =  accounts x usage/account (____) over allowance (____) x price (____)
   |   source: __________   unit: $/mo        controllable: Y / N
   v
Gross profit  =  revenue - COGS (____: inference / hosting / support)
   |   source: __________   unit: $/mo        controllable: Y / N
   v
Operating cash  ->  Ending cash  =  beginning cash + collections - cash costs
       source: __________   unit: $           controllable: Y / N
```

---

## Classify every metric before you build

For each metric, decide which bucket it lives in. This is the hinge of the whole model.

| Metric | Driver of the model | Output of the model | Outside the model |
|---|---|---|---|
| (example: quota per AE) | X | | |
| (example: ending ARR) | | X | |
| (example: a macro interest rate you can't move) | | | X |
| | | | |
| | | | |
| | | | |

- **Driver** = an input management controls that feeds the machine. Vary these in scenarios.
- **Output** = a result the machine produces. Never plug a scenario value straight into an output.
- **Outside** = real, but not something this model controls or should pretend to forecast.

---

## Discipline notes

- Keep the driver set to the **~15–20 assumptions that actually move the answer.** Budget *activities, not line items* — a full expense-by-department list produces a phone book, not a plan.
- Anything you wrote `OPEN QUESTION` next to goes to the Analyst round's OPEN QUESTIONS list — it does **not** get a made-up value.
- When you later run the Analyst prompt (P1), reconcile **three** things: this hand sketch, the AI's extracted table, and the source text. Anything the AI "found" that the source never stated is an invention.
