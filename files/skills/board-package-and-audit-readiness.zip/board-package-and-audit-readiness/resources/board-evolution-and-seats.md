# Board Evolution & Seats — composition quick-reference

**Core idea:** governance intensity rises with the gap between **ownership** and
**control.** Read every seat question through that lens.

```
Public co (thousands of holders)  → most governance
Angel/VC-backed (dozens)
VC-backed (a few firms)
PE <100% (sponsor majority + minority/rollover holders)
PE 100% (one owner)               → least *formal* governance
```

At PE-100%, ownership ≈ control: the board is informal but absolute — decisions
happen on the weekly sponsor–CEO call and get papered later. At a VC-backed
company, dozens of holders and a minority-owning founder create the gap the
board polices.

---

## The board grows up (evolution timeline)

| Stage | Board size | Composition |
|---|---|---|
| No institutional $ | 0–2 | Co-founders; often no formal board |
| Seed | 3 | 2 founders + 1 investor |
| Series A | 3–5 (best 3) | CEO seat + common seat + investor seat; observers appear; possible board re-set |
| Series B | 4–7 | CEO, common, 2 investors, 1 independent; 1–2 observers |
| Series C/D+ | 5–7 | earlier VCs cycle off; try to cap at 7 |
| Pre-IPO | 5–7 | add public-company / IPO experience; late VCs often stay 12+ months past IPO |

---

## Structure by capital source

| Capital source | Typical structure |
|---|---|
| Bootstrapped | Founders' carte blanche; 3 seats max; often founder-controlled, no formal board |
| VC-backed, growth | CEO seat + 1–2 common + 1–2 independent + 2–3 investor seats |
| PE-backed 100% | CEO seat + 2–4 sponsor seats; sometimes 1–3 outside directors (not necessarily independent) |
| PE >50% but <100% | Sponsor majority (3 of 5, 4 of 7); minority/rolled-over holders keep seats; independents bridge misaligned incentives |

---

## Two rules to know cold
- **The CEO seat belongs to the office, not the person.** Lose the CEO job, lose
  the seat — this is how a board fires a founder-CEO. Consider an employment
  contract **before** you raise.
- **Limit observer seats.** Confidentiality, leak risk, meeting efficiency, and
  creeping influence without fiduciary accountability all argue for keeping them
  few.

## VC & PE dynamics
- The round's **lead partner** usually takes the seat. By Series C+ a board can
  carry 3–4 VCs out of 5–7 — not all with relevant experience.
- The scarce, valuable seats are **qualified independents.** Cultivate them early
  (advisory board first: similar expertise, less equity, no liability).
- You often can't choose your VC; the highest bidder isn't always the best board
  member.

## Committees (arrive with scale)
- **Audit** — oversees finance/CFO, the annual audit & taxes; forms as you get
  closer to audited.
- **Compensation** — C-level comp, option grants, benchmarking; often first,
  often contentious.
- **Governance** — director recruiting/exits, meeting schedule; later stage.

## Director comp
- Founders / CEO: nothing extra.
- VCs: nothing (they are fund fiduciaries).
- Independents: NQSOs ≈ **0.50–1.0%** by stage, typically **2-year vesting with
  forward-vest on sale** — so a sale doesn't destroy their incentive to support
  it.

> **Escalation:** seat allocation, board consents, and founder employment terms
> are legal instruments — have counsel paper them before you sign. A seat is not
> a proxy vote: an investor's designee still owes loyalty to **all** shareholders
> (see `fiduciary-duties-reference.md`).
