# Board Package Critique — the six-flaw red-team card

Read any package the way an investor-director does: they stop trusting **every**
number the moment they catch the first sleight of hand. Scan in severity order —
a board's job is **survival first, integrity second, accountability third.**

Usual verdict ordering: **F1 > F2 > F4.**

---

## F1 — Missing cash / burn / runway  (MOST SEVERE)
- **Look for:** no cash balance, no net burn, no months of runway — for a company
  that is burning.
- **Why it misleads:** the board cannot govern what it cannot see; runway is the
  one number a board must have.
- **Fix:** cash, net burn, runway months, **each vs. plan**, top-left, first
  block, every package.

## F2 — Bookings–revenue conflation
- **Look for:** "Revenue up X%, $Y.YM this quarter" where the figure is TCV /
  bookings signed, not GAAP revenue recognized; a fine-print "total contract
  value" footnote; "ARR = quarter bookings × 4"; a revenue bar that jumps when
  the metric silently switched.
- **Why it misleads:** overstates the recognized top line and hides collection /
  delivery risk.
- **Fix:** four separately labeled lines — **bookings, billings, GAAP revenue,
  deferred revenue** — never one presented as another. GMV is a KPI, not revenue.

## F3 — Vanity / cumulative metrics
- **Look for:** cumulative registered users (monotonic by construction), total-
  ever downloads, raw unweighted pipeline with no stage definition.
- **Why it misleads:** can only go up; carries no information about the current
  quarter.
- **Fix:** 30-day actives, NRR, stage-weighted pipeline with historical
  conversion rates.

## F4 — No variance to plan
- **Look for:** "best quarter ever" with no budget column; RYG all green with no
  stated criteria.
- **Why it misleads:** the board approved an AOP; without actual-vs-plan the
  package is unverifiable self-congratulation.
- **Fix:** actual | plan | prior columns + variance commentary; RYG tied to
  **pre-agreed** thresholds.

## F5 — Undefined or shifting KPI definitions
- **Look for:** "active = login in trailing 12 months" (was 90-day last quarter →
  trend broken); "ARR = bookings × 4"; "churn 2%" with no period, no gross/net,
  no logo/dollar denominator.
- **Why it misleads:** silent definition drift breaks every trend line.
- **Fix:** a definitions page; freeze definitions; restate history when one
  changes.

## F6 — Chart crimes
- **Look for:** truncated y-axis (starts near the data, not at zero) so a few
  points of sequential growth read as a towering hockey stick; two different
  metrics plotted as one series; missing axis units.
- **Why it misleads:** the geometry lies even when the numbers are right.
- **Fix:** zero-based axis, one metric per series, labeled units.

---

## Bonus catches to always name
- Non-GAAP gross margin with **no reconciliation** (quietly excludes
  hardware / install / inference costs).
- No deferred revenue shown despite prepaid / TCV deals.
- No asks / needs section (a wasted board).
- No prior-period comparatives.
- A 🚀 "best quarter ever" tone masking the misses.

---

## The revenue-definitions strip (keep these four straight)
- **Bookings** — signed customer commitment (contract value). *Not* revenue.
- **Billings** — what you invoiced this period.
- **GAAP revenue** — booking **+** delivery **+** probable collection, recognized
  under ASC 606.
- **Deferred revenue** — cash billed/collected but **not yet earned** (a
  liability).

Identity to memorize:

> **Billings = Revenue + Δ Deferred Revenue**

*Illustrative check (invented figures, [ILLUSTRATIVE]):* if GAAP revenue is
**$6.4M** and deferred revenue rose by **$2.3M** in the period, then
billings = $6.4M + $2.3M = **$8.7M**. Rising deferred revenue means you billed
ahead of what you earned — good for cash, but do not report the $8.7M as
"revenue."

---

### Deliverable shape
Return: **Flaw | Where it is | Why it misleads | The fix**, ranked
most-dangerous-first; a one-line severity verdict (usually F1 > F2 > F4); and a
corrected rewrite of the single worst block, with any figures you supply marked
`[ILLUSTRATIVE]`.
