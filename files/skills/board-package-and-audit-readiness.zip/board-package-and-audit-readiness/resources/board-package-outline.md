# Board Package — Section-by-Section Outline

Drop this into your slide master or doc template. It is ordered the way a board
reads it. **Every quantitative cell is pre-marked `[CERTIFY]`** — you (the model
owner, the name on the package) tie out each number before it circulates. If you
paste an AI-generated placeholder, mark it `[ILLUSTRATIVE — replace]`, never
`[CERTIFY]`.

> Creed: **AI drafts, the human certifies every number.** Nothing here ships as
> "final" until a human has re-derived it from source.

---

## 1. CEO Update (owned by the CEO; CFO does the work behind it)
- Accomplishments since last meeting (3–5 bullets, high-level).
- Challenges / risks (name them; the worst-case belongs here, not buried).
- Needs / asks preview.
- One-line preview of this meeting's **deep-dive** topic.

*Keep it narrative, not granular. Detail lives in the CFO section and appendix.*

## 2. Cash, Burn, Runway  — FIRST BLOCK, TOP-LEFT, EVERY MEETING WHILE BURNING
The single most severe omission there is. A burning company whose board can't
find runway on page one is ungovernable.

| Line | Actual | Plan | vs. Plan | Comment |
|---|---|---|---|---|
| Cash balance (end of period) | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | |
| Net monthly burn | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | |
| **Months of runway** | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | runway = cash ÷ net monthly burn |
| Next-raise timing / gate | `[CERTIFY]` | `[CERTIFY]` | | |

## 3. KPI Dashboard vs. Plan  (the ~6 board KPIs — see six-kpi-selector.md)
RYG must be tied to **pre-agreed thresholds**, not self-graded.

| Metric | Driver/Output | Actual | Plan | Prior | Variance | RYG |
|---|---|---|---|---|---|---|
| KPI 1 | | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | |
| KPI 2 | | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | |
| KPI 3 | | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | |
| KPI 4 | | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | |
| KPI 5 | | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | |
| KPI 6 | | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` | |

## 4. Financials + Variance, with Base / Best / Worst
Monthly financials + variance commentary (actual vs. plan). Keep **bookings,
billings, GAAP revenue, and deferred revenue as four separate lines** — never
present one as another.

**Re-forecast — end-of-period cash summary**

| Scenario | Key driver assumptions | End-of-period cash | Runway (mo) |
|---|---|---|---|
| Base | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` |
| Best | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` |
| **Worst** | `[CERTIFY]` | `[CERTIFY]` | `[CERTIFY]` |

*Never drop the worst case because it's "depressing." It is the board's
early-warning system; hiding it breaches the duty of candor.*

## 5. Org Chart — Current + Planned Hires
- Current org (one page).
- Planned hires next 1–2 quarters, with the roles the board can help fill.

## 6. Asks / Needs
A board is a resource; a package with no asks wastes it.
- Intros (customers, partners, capital).
- Key exec hires the board can source.
- Specific decisions you need from the board.

## 7. Admin
- Option grants for approval `[CERTIFY]`.
- Current 409A (date + value) `[CERTIFY]`.
- Cap table (current) `[CERTIFY]`.
- Prior minutes for approval.
- Legal / consent items.

---

### Before this circulates — checklist
- [ ] Runway tied out from cash balance ÷ net monthly burn.
- [ ] KPI definitions frozen and identical to last quarter (or restated if changed).
- [ ] Bookings / billings / GAAP revenue / deferred revenue shown as separate lines.
- [ ] Worst case present.
- [ ] 409A date confirmed for any option-grant vote (CPA if in doubt).
- [ ] Every `[CERTIFY]` cell re-derived from source; every `[ILLUSTRATIVE]` removed.

> **If building this package takes two weeks of special production, fix your
> monthly close first.** A good board package is a show-and-tell of what the
> company already runs internally.
