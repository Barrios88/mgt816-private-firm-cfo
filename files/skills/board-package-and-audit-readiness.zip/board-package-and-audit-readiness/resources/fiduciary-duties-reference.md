# Fiduciary Duties Reference — care, candor, loyalty (owed to ALL shareholders)

Every director owes three duties **to all shareholders** — even a director
appointed by one class. A VC's designee still owes loyalty to the common holders;
a sponsor's designee still owes it to the minority. **A board seat is not a proxy
vote.**

---

## The three duties

### Duty of care
Make **informed, deliberate** decisions — do the homework, ask the questions,
document the deliberation.
- *Cautionary illustration — Theranos:* care failed. A board of celebrity
  signalers with no finance / audit / medical-devices expertise could not oversee
  what it did not understand.

### Duty of candor
Inform shareholders of **material information** — the bad news too.
- A CFO who hides the **worst-case scenario** or a **miss-vs-plan** is helping the
  board breach this duty. Put the worst case in the package; it is the board's
  early-warning system.

### Duty of loyalty
Act in the **corporation's / all shareholders'** interest, not the appointing
class's.
- VC and PE directors struggle with this most. It strains **hardest at conflicted
  financing rounds**, where new money wants dollars in and early money fears
  dilution. Naming the conflict is not the violation — *acting on* it can be.

---

## The consequence to internalize: the board can fire the founder
- **Cisco** — the board pushed out co-founder Sandy Lerner.
- **Digg** — the board blocked a sale the founder wanted; Digg later sold for a
  fraction of that, in pieces.
- Boards can be wrong in **both** directions — the power is the point.
- **Consider an employment contract before you raise**, and remember the CEO seat
  belongs to the office, not the person.

> Treat these as **course-level illustrations, not legal precedent.** Do not
> attach invented citations, dates, or dollar figures to them.

---

> **Escalation — this is where you call the lawyer.** Fiduciary-liability
> exposure, director removal / replacement mechanics, indemnification, board
> consents, founder employment agreements, and anything about *acting on* a
> duty-of-loyalty conflict are **legal matters.** Draft the business analysis,
> then say so explicitly.
