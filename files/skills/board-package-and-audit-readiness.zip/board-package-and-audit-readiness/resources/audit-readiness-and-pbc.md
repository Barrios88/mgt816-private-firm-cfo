# Audit Readiness & the PBC List — the first-audit one-pager

Audit readiness is a **year-round posture, not an event.** Build the artifacts
monthly from day one and the first audit is a hand-off, not a fire drill.

---

## Why a private company chooses to be audited (even voluntarily)
- **Signaling** — credibility to investors and acquirers.
- **Agency** — reassures majority vs. minority owners, and owners vs. creditors.
- **Cheaper credit** — audited firms borrow at lower rates even when riskier.
- **Contract terms** — lender and VC covenants require it.

## When the first audit comes (the triggers)
- **Self-funded** → often **never** (banks frequently lend to private firms
  without one).
- **VC-backed** → usually **not yet** audited at Series A/B.
- **≈$10M revenue** — the customary tipping point.
- **VC term-sheet covenant** — often requires audited financials **within 1–2
  years**; you'll see it as a covenant when you raise.
- **Exit prep** — acquirers take comfort from an audit history; an IPO requires
  audited years.
- **Cost anchor:** a first audit runs **≈$25–50K**, but the real cost is internal
  prep time.

## How to prepare for audit #1
- **Keep every scrap of paper** — even trivial documents evidence legitimate
  transactions.
- **Hire a firm that knows your industry** — risk-assessment quality varies; the
  right auditor becomes year-round technical-accounting counsel (ASC 606 judgment
  calls).
- **Reconcile and self-review before fieldwork.** Errors the auditors find
  trigger extra testing and higher fees. *If the numbers don't make sense to you,
  they won't make sense to the auditors.*

---

## The PBC (Prepared-by-Client) list — your standing auditability checklist
Build these **monthly**. The final column is blank so you can paste your own
auditor's actual PBC list and track it.

| PBC item | What the auditor is testing | Your auditor's exact request (paste here) |
|---|---|---|
| Trial balance | Do debits equal credits? | |
| General ledger & subledgers | Do they tie to the TB? | |
| Bank statements & reconciliations | Does cash corroborate the books? | |
| AR / AP aging | Collection & payment discipline; revenue quality (ties to ASC 606 collectability) | |
| PP&E / depreciation schedule | Existence & useful lives | |
| Accounting-policy & controls documentation | Consistent, GAAP-aligned | |

Plus: auditors **confirm externally** with your customers, vendors, and bank —
so keep those contacts and balances clean.

---

> **Escalation:** choosing and engaging an audit firm, reading an audit covenant,
> and any figure that will land in audited financials or an ASC 606 judgment call
> → **loop in a CPA / your auditor early.** This one-pager is business prep, not
> an audit opinion.
