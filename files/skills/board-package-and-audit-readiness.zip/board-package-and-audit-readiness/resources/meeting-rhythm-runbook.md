# Meeting Rhythm Runbook — cadence, five blocks, executive session

The board meeting is not sprung on people; it is **pre-wired.** A well-run board
meeting has no surprises and no live vote-counting.

---

## Cadence & attendees
- **Frequency:** monthly to quarterly; most common **every other month**,
  drifting quarterly once VCs (who sit on many boards) join. Special-purpose
  calls for fundraising and budget approval.
- **Length:** 3–4 hours.
- **Minimum attendees:** **CEO + CFO.** Each C-suite lead presents their area and
  is evaluated by the board in passing; execs don't stay for everything.

---

## The no-surprises rule — the T-minus timeline

| When | Action |
|---|---|
| T–14 to T–10 days | Circulate a **mock agenda**; ask directors for input |
| T–10 to T–3 days | **Pre-calls** with each director on the big topics |
| Before the meeting | **Pre-wire the votes** — count them; board votes are almost always unanimous |
| T–3 to T–2 days | Circulate the **pre-read** (package + deep-dive materials) |
| Meeting day | Run the five blocks (below) |
| T+2 to T+5 days | Draft and circulate **minutes**; log asks / action items |

- Optional standing check-ins with lead investors (≈2×/month, 30 min).
- **If you don't know the vote count before the meeting, you're not ready.** The
  CEO's job is to count votes before the room.
- If assembling the package takes two weeks of special production, the internal
  reporting is broken — fix the monthly close.

---

## The five-block meeting anatomy

| # | Block | Time | What happens |
|---|---|---|---|
| 1 | **CEO update** | ~15 min | Accomplishments / challenges / needs; preview the deep dive |
| 2 | **Functional updates** | ~1 hr | One-page KPI dashboard per area, with goals and performance-vs-plan |
| 3 | **Special topics** | 15–30 min | Forward org chart, planned hires, roadmap |
| 4 | **Deep dive** | ~1 hr | **The best hour of the quarter** — see below |
| 5 | **Executive session** | 30–60 min | Three stages — see below |

### Block 4 — the deep dive (the best hour of the quarter)
Management and board jointly work **ONE** strategic problem; this is where the
next 3–6 months' goals get set. Pick **1–2 topics max**, circulated in the
pre-read. Topic menu:
- Pricing power after winning bake-offs.
- A competitor got acquired — now what.
- A sales-productivity diagnosis.
- Rising data / inference costs.
- Partnership priorities.

### Block 5 — the three-stage executive session
1. **Formalities & votes** — option grants, 409A approval, prior minutes. CEO ±
   CFO present.
2. **CFO leaves the room** — the CEO reviews management-team performance (the CFO
   is on that team, so the CFO steps out).
3. **CEO leaves** — the board (lead director running it) evaluates the CEO and
   cycles feedback back.

---

## Board politics (name it; don't pretend it's absent)
Outside-the-room lobbying is normal. Investor-directors' financial interests can
diverge from other shareholders — the sharpest misalignment is at a **funding
round** (new money wants dollars in; early money fears dilution). That is the
duty-of-loyalty strain in action. **Count votes early**, and route any move to
*act on* a conflict to counsel (see `fiduciary-duties-reference.md`).
