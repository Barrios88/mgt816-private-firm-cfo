# Six-KPI Selector — the board-dashboard pruning worksheet

The board dashboard is **~6 metrics, no more.** The board manages cash and
strategy; it is not admiring your product. Use this worksheet to prune a long
candidate list down to a defensible six.

> Every candidate must survive **three kill tests** and be tagged **driver** or
> **output.** A good six mixes a few controllable drivers (the levers) with the
> key outputs (the score).

---

## Part 1 — Candidate grid (fill one row per proposed metric)

| Candidate metric | Driver / Output | Vanity or cumulative? | Definition stable & writable as a formula? | Destructive incentive if optimized? | Keep / Cut |
|---|---|---|---|---|---|
| (example) Net new ARR | Output | No | Yes | Discounting risk — pair w/ margin | Keep |
| (example) Cumulative registered users | Output | **Yes — monotonic** | Yes | Signup farming | **Cut** |
| (example) Quota attainment | Driver | No | Yes | Sandbagging quotas | Keep |
| | | | | | |
| | | | | | |
| | | | | | |

**The three kill tests (cut on any failure):**
1. **Vanity / cumulative.** Monotonic by construction (cumulative users, total
   downloads, total-ever pipeline) → carries no information. Replace with a
   *flow* or *retention* metric: 30-day actives, net-dollar retention (NRR),
   stage-weighted pipeline with historical conversion.
2. **Definition stability.** Can you write the exact formula, and has it held
   constant? An "active user" that silently shifts 90-day → 12-month breaks every
   trend. Freeze definitions; restate history when one changes.
3. **Destructive incentive.** Would optimizing it hurt the company? Raw "new
   logos" with no quality gate → churn-prone signings; pure "gross bookings" →
   discounting and over-long contracts. Name the perverse behavior; cut it or
   pair it with a guardrail metric.

---

## Part 2 — The final six (exact formulas + what each is shown against)

| # | Metric | Driver/Output | Exact formula / definition | Why it is *key* | Shown against |
|---|---|---|---|---|---|
| 1 | | | | | plan + prior |
| 2 | | | | | plan + prior |
| 3 | | | | | plan + prior |
| 4 | | | | | plan + prior |
| 5 | | | | | plan + prior |
| 6 | | | | | plan + prior |

---

## Starting points (adapt — not gospel)

**Default B2B SaaS six (burning):**
1. **Net new ARR** (output) — label it ARR, not bookings.
2. **Net-dollar retention / NRR** (output) — >100% means the base grows without
   new logos.
3. **CAC payback (months)** or **LTV:CAC** (output; heuristic LTV:CAC ≥ 3x) — is
   growth economic?
4. **Gross margin** (output) — especially with usage/inference costs in COGS.
5. **Net burn & months of runway** (output) — the survival metric.
6. **One controllable driver** — quota attainment, or SQL pipeline coverage vs.
   plan.

**Marketplace variant:** GMV growth (a KPI, **never** revenue), take rate, net
revenue, contribution margin per order, active buyers/sellers (flow, not
cumulative), runway.

**Usage-priced / AI variant:** net new ARR, NRR (usage expansion pushes it
>100%), inference cost per unit / gross margin, burn multiple, months of runway,
one controllable driver (AE quota attainment or units processed per active
account).

---

## Hall of shame — metrics that fail as board KPIs
- **Cumulative registered users / total-ever downloads** — monotonic; no signal.
- **Total pipeline, unweighted** — no stage definition, no conversion history.
- **Raw NPS as a board KPI** — a product/CX metric, not a board survival metric.
- **Gross bookings with no quality gate** — rewards discounting and long tails.
- **"All green" self-graded RYG** — no pre-agreed threshold = self-congratulation.

*All KPIs are metrics; not all metrics are key.* If a metric can't survive the
three tests and can't be tied to plan, it doesn't belong on the board dashboard.
