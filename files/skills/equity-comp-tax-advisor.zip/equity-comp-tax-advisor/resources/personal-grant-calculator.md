# Personal Grant Calculator — Intake + Formula Set

Paste the intake block below into the skill, fill what you know, and let it run
the ordered formulas. Anything you leave blank becomes a **stated assumption** in
the answer — never a silent one.

> All example figures are illustrative (fictional **Kestrel Systems**).

---

## 1. Intake form (fill in; label assumptions)

```
INSTRUMENT ............ restricted stock / RSU / ISO / NQSO / SAR-phantom: ______
SHARES ................ ______
STRIKE (per share) .... $______            (options only)
GRANT-DATE FMV ........ $______            (restricted stock / 83(b) base)
CURRENT 409A / FMV .... $______
TRANSACTION PRICE ..... $______            (tender / secondary / preferred, if any)
--- DATES ---
GRANT DATE ............ ____/____/____
VEST SCHEDULE ......... ______ (e.g., 4-yr, 1-yr cliff, monthly after)
EXERCISE DATE ......... ____/____/____      (if already/planning exercised)
TODAY ................. ____/____/____
--- TAX BASELINE ---
FILING STATUS ......... single / MFJ / other: ______
YTD ORDINARY INCOME ... $______
REGULAR FEDERAL TAX ... $______            (needed for AMT line 5)
MARGINAL ORDINARY RATE. ____%              (or use amt-parameters.md default)
LTCG RATE ............. ____%              (0/15/20 + 3.8% NIIT if applicable)
STATE ................. ______             (for state conformity flags)
--- SIDE ---
WHICH CHAIR? .......... employee / CFO / both
```

## 2. Ordered formula set

Run in this order; show every line; carry the character label on each dollar.

**A. ASC 718 book expense (CFO side, if applicable)**
- Restricted stock: period expense = (grant-date FMV × shares) ÷ vesting periods.
- Options: period expense = (grant-date **option** FV × shares) ÷ vesting periods.
- DTA each period = corporate rate × period expense.
- Never remeasured for later price moves.

**B. Exercise cost (options)**
- Strike cost = strike × shares exercised.

**C. Ordinary income at the taxable event**
- NQSO exercise: spread = (FMV at exercise − strike) × shares → ordinary, withheld.
- ISO disqualifying disposition: spread at exercise → ordinary, NOT withheld.
- Restricted stock, no 83(b): vest-date FMV × shares vesting → ordinary.
- Restricted stock, 83(b): grant-date FMV × all shares → ordinary now.

**D. AMT (ISO exercise-and-hold only — run the 5-line worksheet)**
- L1 bargain = (FMV − strike) × shares
- L2 AMTI = regular taxable income + L1
- L3 exemption = max(0, $90,000 − 0.5 × max(0, AMTI − $500,000)); base = AMTI − exemption
- L4 tentative = 26% × min(base, $240,000) + 28% × max(0, base − $240,000)
- L5 AMT = max(0, L4 − regular tax)

**E. Capital gain on sale**
- NQSO/qualifying paths: (sale price − basis) × shares; basis = FMV at exercise
  (NQSO) or strike (ISO qualifying); LT if held > 1 yr from exercise.
- Apply QSBS exclusion if the checklist clears (see `qsbs-regimes.md`).

**F. Net cash and cash-needed**
- Cash needed = strike cost + withholding on ordinary spread (NQSO) + AMT (ISO hold).
- Cash available = net proceeds from any same-event sale (after strike + withholding).
- Gap = needed − available. Flag any phantom-income leg with no funding source.

**G. Clocks status**
- LTCG clock: started at exercise? months elapsed? crosses 1 year when?
- QSBS clock: started at exercise? which regime? crosses 3/4/5 years when?
- Deadlines: 83(b) 30 days from grant; 90-day post-termination window; 3-month
  ISO→NQSO statute.

## 3. Worked pass (invented — Kestrel, ISO exercise-and-hold)

Intake: 50,000 ISOs, strike $0.40, current 409A $7.00, single filer, YTD
ordinary income $155,000, regular federal tax $27,500, hold (no sale this year).

- **B** Strike cost = $0.40 × 50,000 = **$20,000**.
- **D** L1 = ($7.00 − $0.40) × 50,000 = **$330,000**; L2 = $155,000 + $330,000 =
  **$485,000**; L3 exemption **$90,000**, base **$395,000**; L4 = $62,400 +
  $43,400 = **$105,800**; L5 AMT = $105,800 − $27,500 = **$78,300**.
- **F** Cash needed = $20,000 + $0 withholding (ISO) + $78,300 AMT = **$98,300**;
  cash available = $0 (no sale) → **gap $98,300**, all phantom. Fund it or don't
  exercise-and-hold.
- **G** LTCG and QSBS clocks start at this exercise; nothing is qualified yet.

**Certify:** confirm the regular-tax figure, current-year AMT parameters, and
state conformity; if you will file on this, take it to a CPA first.
