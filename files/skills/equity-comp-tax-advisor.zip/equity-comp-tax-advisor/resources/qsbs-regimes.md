# QSBS §1202 — The Two Regimes

> **Verify against current §1202 law before relying — this area moved recently.**
> The split date, holding periods, caps, and gross-asset thresholds below are the
> course-simplified framing. Confirm each against current statute and your state's
> conformity before anyone relies on a number.

QSBS (Qualified Small Business Stock, IRC §1202) can exclude some or all of the
federal gain on a sale of qualifying startup stock. It is the 0% federal rate
hiding inside an ordinary-looking grant — but only if you cleared the checklist
**and** started the clock at the right moment.

---

## The four qualification checks

1. **C-corporation.** The issuer is (and was) a domestic C-corp. LLCs and
   S-corps do not qualify.
2. **Original issuance.** You acquired the stock **from the company** (at
   original issue), not bought secondhand from another holder.
3. **Gross-asset test at issuance.** Company gross assets were **≤ the threshold**
   (below) at the time the stock was issued.
4. **Active business.** The company runs a qualified active trade or business
   (several sectors — e.g., many professional-services and financial fields — are
   excluded).

## The one-liner that trips option holders

**Option stock is "issued" when you EXERCISE, not when you're granted.** Both the
holding-period clock **and** the gross-asset test run from the **exercise** date.
Sitting on vested-but-unexercised options starts **no** QSBS clock — and if the
company's gross assets cross the threshold before you exercise, QSBS can be
**permanently** lost while you wait.

---

## The two regimes (by issuance date)

| | **Issued on/before Jul 4, 2025** | **Issued after Jul 4, 2025** |
|---|---|---|
| Holding period → exclusion | **5 years → 100%** | **3 yr → 50% · 4 yr → 75% · 5 yr → 100%** (tiered) |
| Per-issuer exclusion cap | **$10M** (or 10× basis, if greater) | **$15M** (or 10× basis, if greater) |
| Gross-asset test at issuance | **≤ $50M** | **≤ $75M** |

**Never apply one regime's tiers or caps to the other's stock.** Check the
issuance (exercise) date first, then pick the column. Mixing them is a classic
hallucination — the numbers look plausible and are simply wrong for that stock.

---

## State conformity (do not assume)

Federal QSBS exclusion does **not** automatically flow through to state tax.
Some states conform, some partially conform, and some (notably California and
others) do **not** conform or impose their own rules. **Flag state treatment as
a separate question and route it to a CPA** — never assume conformity.

---

## Worked framing (invented — illustrative)

Suppose an employee early-exercises and holds C-corp stock issued **after Jul 4,
2025**, when company gross assets were comfortably under $75M, and later sells at
a large gain:
- At **3 years** held from exercise → **50%** of the eligible gain excluded.
- At **4 years** → **75%** excluded.
- At **5 years** → **100%** excluded, up to the **$15M** (or 10× basis) cap.

The dollars turn entirely on the **issuance/exercise date** and the **holding
period** — which is why the exercise-timing decision (Workflow E) and QSBS are
the same conversation. Quantify the wait, name what must stay true for it to pay,
and let the human decide.

**Certify:** confirm C-corp status, original issuance, the gross-asset test at
issuance, the active-business test, the exact issuance/exercise date, the
holding period, and **state conformity** — then have a CPA sign off before anyone
files on the exclusion.
