# Tax Parameters — Course-Simplified Defaults

> **Course-simplified defaults for 2026; replace with the year you are computing
> and cite your source. AI must stamp any figure it cannot source as
> `UNVERIFIED`.** This file is the single place the skill reads rate and
> threshold parameters from — update it here, not inline in an answer.

**How to use:** if the user supplies a current-year figure, use theirs and note
the source. If not, use the default below AND say you are using a
course-simplified default. If neither is available, stamp `UNVERIFIED`.

---

## AMT (single filer)

| Parameter | Default | Note |
|---|---|---|
| AMT exemption | **$90,000** | phased out above the threshold below |
| Exemption phaseout start | **$500,000** of AMTI | $0.50 lost per $1 over |
| Exemption fully gone at | **$680,000** of AMTI | = $500,000 + $90,000 ÷ 0.5 |
| Phaseout rate | **$0.50 per $1** | shadow bracket ≈ 28% × 1.5 ≈ 42% |
| Tentative-minimum-tax rate | **26%** on first **$240,000** of base | **28%** above $240,000 |

Married-filing-jointly figures differ — not modeled here; stamp `UNVERIFIED`
and route to a CPA if the user is MFJ.

## Capital gains and investment tax

| Parameter | Default | Note |
|---|---|---|
| Long-term capital gains | **0% / 15% / 20%** | bracket-dependent; assume 20% for high earners unless told |
| Net investment income tax (NIIT) | **3.8%** | on investment income above the MAGI threshold |
| Short-term capital gains | taxed as **ordinary** | held ≤ 1 year |

## Ordinary income (single, simplified)

Use the user's marginal rate if given. Course-simplified top marginal reference:
**37%**. Do not compute a full bracket stack from memory — if you need bracket
detail, pull the current-year table and cite it, or stamp `UNVERIFIED`.

## Payroll / withholding (employer side)

| Parameter | Default | Note |
|---|---|---|
| Supplemental federal withholding | **22%** on aggregate ≤ $1,000,000 | **37%** on the portion above $1,000,000 |
| Employee Medicare | **1.45%** | + **0.9%** Additional Medicare surcharge over the wage threshold → assume **2.35%** |
| Employer Medicare | **1.45%** | on NQSO / disqualifying-ISO spreads |
| Social Security wage base | **$176,100** `UNVERIFIED for 2026` | assume already met (spreads sit on top of salary) |

## Corporate

| Parameter | Default | Note |
|---|---|---|
| Federal corporate rate | **21%** | drives the deferred-tax-asset and deduction math |

---

## §409A / QSBS pointers (see companion files)

- §409A below-FMV penalty: immediate income + **20%** federal penalty + state
  add-ons. Safe harbor = strike ≥ FMV at grant.
- QSBS thresholds and holding periods change by issuance date — see
  `qsbs-regimes.md`; verify against current §1202 law before relying.

**Maintainer note:** review this file every tax year. The Social Security wage
base, the AMT exemption, and the phaseout thresholds are indexed and move
annually. A stale parameter silently corrupts every downstream number.
