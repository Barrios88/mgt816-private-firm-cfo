# ASC 718 Journal-Entry Cookbook

Every entry below foots. All figures are illustrative (fictional **Kestrel
Systems, Inc.**). Two rules run through all of it:
- **Grant-date value only. Never remeasured** for later price moves.
- **Options: nothing at grant** (stock ledger only); restricted stock: an entry
  at grant.

Corporate tax rate used throughout: **21%**.

---

## 1. Restricted stock (and founder stock — identical entries)

**Facts:** 200,000 restricted shares, grant-date FMV **$0.05** → **$10,000**
total, 4-year straight-line vest.

**At grant** (contra-equity; no P&L hit yet):
```
Dr Unearned (Deferred) Compensation .... 10,000
    Cr Common Stock ..................... 10,000
```

**Each year** (expense $10,000 ÷ 4 = $2,500):
```
Dr Compensation Expense ................ 2,500
    Cr Unearned Compensation ........... 2,500
```

**Each year — deferred tax layer** (book expenses now, tax deduction lands at
vest → DTA = 21% × $2,500 = $525):
```
Dr Deferred Tax Asset .................. 525
    Cr Deferred Tax Expense ............ 525
```

*Foots:* 4 × $2,500 = $10,000 total expense = the grant-date value. 4 × $525 =
$2,100 = 21% × $10,000.

---

## 2. Options — grant (ISO or NQSO, book is identical)

**No journal entry at grant.** Book cares about the grant-date fair value **of
the option** (from Black-Scholes / lattice / Monte Carlo), recognized over
vesting — not the strike, not the spread.

**Facts:** 45,000 options, grant-date **option** FV **$3.00** → **$135,000**
total grant-date value, 4-year straight-line vest.

**Each year** ($135,000 ÷ 4 = $33,750):
```
Dr Compensation Expense ................ 33,750
    Cr Paid-in Capital—Stock Options ... 33,750
```

*Foots:* 4 × $33,750 = $135,000 = 45,000 × $3.00.

---

## 3. Options — exercise

**Facts:** all 45,000 exercised, strike **$1.00**. Exercise-date FMV (say $18)
**never touches the books** — it is the employee's tax number, not a book event.

```
Dr Cash (45,000 × $1.00) ............... 45,000
Dr PIC—Stock Options (45,000 × $3.00) . 135,000
    Cr PIC—Common (plug) .............. 180,000
```

*Foots:* $45,000 + $135,000 = $180,000. The PIC—Stock Options debit equals the
cumulative grant-date expense (section 2), clearing that account.

---

## 4. Forfeiture — UNVESTED options (employee leaves before vesting)

**Reverse the unamortized expense.** Facts: the 45,000-option grant above;
employee leaves after **year 2**. Recognized so far = 2 × $33,750 = **$67,500**;
unamortized = **$67,500**.

```
Dr PIC—Stock Options ................... 67,500
    Cr Compensation Expense ........... 67,500
```

*Foots:* $135,000 total − $67,500 reversed = $67,500 kept for service rendered.

---

## 5. Vested options that EXPIRE unexercised

**No expense reversal.** The service was rendered; the employee simply chose not
to exercise (or was out of the money). The previously recognized
Compensation Expense **stays**. At most, reclassify within equity:
```
Dr PIC—Stock Options ................... [balance]
    Cr PIC—Expired Options ............ [balance]
```
No P&L effect. Contrast with section 4 — forfeiture of **unvested** options
reverses expense; expiry of **vested** options does not.

---

## 6. Type I modification — extending a post-termination window

**Book incremental fair value.** Facts: 20,000 vested options; extending the
exercise window adds **$1.50** of incremental option fair value per share →
20,000 × $1.50 = **$30,000**.

```
Dr Compensation Expense ................ 30,000
    Cr PIC—Stock Options .............. 30,000
```

Tax caution alongside the book entry: extending the window past **3 months**
after termination converts an **ISO to an NQSO** by statute (see
`iso-vs-nqso-decision-tree.md`). The modification costs book expense; the statute
costs the employee tax character. **Someone pays.**

---

## Quick reference

| Event | P&L effect? | Entry |
|---|---|---|
| Restricted stock grant | No | Dr Unearned Comp / Cr Common Stock |
| Restricted stock vest (each period) | Yes | Dr Comp Expense / Cr Unearned Comp (+ DTA) |
| Option grant | No | none (stock ledger only) |
| Option vest (each period) | Yes | Dr Comp Expense / Cr PIC—Stock Options |
| Option exercise | No | Dr Cash + Dr PIC—Stock Options / Cr PIC—Common |
| Unvested forfeiture | Yes (reversal) | Dr PIC—Stock Options / Cr Comp Expense |
| Vested expiry | No | reclass within equity only |
| Type I modification | Yes (incremental) | Dr Comp Expense / Cr PIC—Stock Options |

**Certify:** confirm the grant-date fair values, the vesting schedule, and the
corporate rate; a modification's incremental fair value and any tax-character
consequence should be reviewed with your auditor and a lawyer.
