# Option Plan Design — Founder / CFO Checklist

You are designing or amending an equity plan. Every choice below is a trade
between recruiting power, dilution, tax character, and administrative burden —
and most of them shift value between the employee and the company.
Name the trade; don't just pick a default.

> Figures are illustrative (fictional **Kestrel Systems**) unless labeled a
> statutory limit. Verify statutory items against current law.

---

## 1. Option pool size

- **Rule of thumb:** **10–20%** of fully diluted shares, stage-dependent.
  Earlier and more hiring-heavy → larger; later-stage → smaller.
- Investors often want the pool **expanded pre-money** (it dilutes founders, not
  the new investor). Know who bears the dilution before you agree.
- Model the pool against the actual hiring plan, not a round number.

## 2. ISO vs. NQSO default

- **Employees only** can get ISOs; consultants/advisors/directors get NQSOs by
  law — don't paper a consultant grant as an ISO.
- **Loss-making startup:** ISOs are fine — the company's lost deduction would
  idle in NOLs anyway, and employees prefer ISO character.
- **Profitable company:** NQSOs put a real ~21% deduction in hand at exercise.
- Remember the asymmetry: a **qualifying ISO disposition gives the company no
  deduction.** The employee's best outcome is your worst.

## 3. Early exercise (allow it or not)

- **Pro:** lets employees exercise unvested, file an 83(b) within 30 days, and
  start the LTCG + QSBS clocks while the spread is tiny → little/no AMT.
- **Con:** administrative burden — repurchase mechanics on forfeiture, 83(b)
  tracking, cap-table complexity, and the risk employees miss the 30-day window.
- If you allow it, build the **83(b) reminder** into onboarding. The deadline is
  non-extendable; a missed filing is a permanent employee harm you enabled.

## 4. Post-termination exercise window

- **Default:** ~**90 days** to exercise vested options or forfeit.
- **Extended windows** (e.g., longer) help departing employees — but exercise an
  ISO **more than 3 months** after termination and it is taxed as an **NQSO** by
  statute, even inside your extended window. Extending trades tax character for
  time; **someone pays.** Say so in the grant docs.
- A window extension is also an **ASC 718 Type I modification** → book
  incremental fair value.

## 5. The $100,000/year ISO limit

- Only **$100,000** of grant-date value can first become exercisable as ISOs per
  employee per calendar year; the excess is an **NQSO**. Track this at grant and
  in vesting-acceleration events — acceleration can blow past the limit and
  silently convert character.

## 6. 409A refresh cadence

- Refresh the 409A every **12 months** or on a **material event** (a financing, a
  tender, a major pivot). A strike **≥ FMV** is the safe harbor; **below** FMV
  triggers §409A penalties (immediate income + 20% federal penalty + state).
- A secondary/tender above the current 409A **pressures the next valuation
  upward** (partial weight to a one-time minority print) → higher future strikes.
  This is board process, not a loophole.

## 7. The honest-communication FAQ (the three prices)

Employees panic when they see three different "share prices." Give them the
plain-English version:

> "Three numbers describe our shares, and they answer different questions. The
> **preferred** price (what investors paid, say **$11**) includes the protections
> preferred stock carries — liquidation preferences and, sometimes, participation
> — so it sits above common. The **409A** (say **$3**) is an independent,
> defensible estimate of what a share of **common** is worth today, after
> discounts for those preferences and for illiquidity — it sets your strike. A
> **tender** price (say **$7**) is a one-time, negotiated clearing price for a
> specific sale. None of them is 'the real price' — each is real for its own
> purpose."

Keep the figures illustrative and tied to the company's own facts; never invent
numbers about the real cap table.

---

## Design certify-this checklist

- [ ] Pool sized to the hiring plan, dilution incidence understood.
- [ ] ISO/NQSO default matches the company's tax posture and each recipient's
      eligibility.
- [ ] Early-exercise decision made, with 83(b) reminders if allowed.
- [ ] Window length chosen with the 3-month ISO statute spelled out to employees.
- [ ] $100k/yr ISO tracking in place (incl. acceleration).
- [ ] 409A refresh cadence and safe-harbor discipline documented.
- [ ] Employee-facing three-prices FAQ drafted honestly.

**Escalation:** plan drafting/amendment, window extensions, early-exercise
reinstatement, §409A methodology, and ISO validity all go to a **securities /
startup lawyer**. The actual common FMV goes to the **409A firm**.
