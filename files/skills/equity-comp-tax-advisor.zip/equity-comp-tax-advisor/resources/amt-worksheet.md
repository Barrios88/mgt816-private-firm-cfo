# The 5-Line AMT Worksheet — ISO Exercise-and-Hold

Run this whenever someone **exercises an ISO and does NOT sell the shares in the
same calendar year**. You compute your tax twice — once the regular way, once
the AMT way — and pay the **higher** of the two. The bargain element on an ISO
exercise is invisible to the regular system and fully visible to the AMT system;
that gap is the whole event.

> Every dollar figure below is **invented and illustrative** (fictional company
> **Kestrel Systems, Inc.**). Substitute your own facts.

---

## Parameters used (course-simplified — see `amt-parameters.md`, update annually)

| Parameter | Value used |
|---|---|
| AMT exemption (single filer) | **$90,000** |
| Exemption phaseout | **$0.50 per $1** of AMTI over **$500,000** (gone at AMTI = $680,000) |
| Tentative-minimum-tax rate | **26%** on the first **$240,000** of base, **28%** above |

If the user gives you current-year figures, use theirs and stamp the source. If
you cannot source a figure, stamp it **UNVERIFIED**.

---

## The five lines

1. **Bargain element** = (FMV at exercise − strike) × shares.
   *This is the AMT add-back — paper gain, no cash received.*
2. **AMTI** = regular taxable income + bargain element.
3. **Exemption / base:**
   - exemption = max(0, $90,000 − 0.5 × max(0, AMTI − $500,000))
   - base = AMTI − exemption
4. **Tentative minimum tax** = 26% × min(base, $240,000) + 28% × max(0, base − $240,000).
5. **AMT owed** = max(0, tentative minimum tax − regular tax).

---

## Fully worked example (invented — Kestrel Systems)

**Facts:** single filer, 2026 taxable income **$155,000**, regular federal tax
**$27,500**. Exercises **50,000 ISOs**, strike **$0.40**, FMV at exercise
**$7.00**, sells **nothing** this year.

| Line | Formula | Result |
|---|---|---|
| L1 Bargain element | ($7.00 − $0.40) × 50,000 = $6.60 × 50,000 | **$330,000** |
| L2 AMTI | $155,000 + $330,000 | **$485,000** |
| L3 Exemption | AMTI $485,000 < $500,000 → no phaseout → full | **$90,000** |
| L3 Base | $485,000 − $90,000 | **$395,000** |
| L4 Tentative min tax | 26% × $240,000 + 28% × ($395,000 − $240,000) = $62,400 + 28% × $155,000 = $62,400 + $43,400 | **$105,800** |
| L5 AMT owed | max(0, $105,800 − $27,500) | **$78,300** |

**Headline:** ▶ **$78,300 of AMT owed — with zero shares sold.**

**Cash out the door** = strike cost (50,000 × $0.40 = $20,000) + AMT ($78,300) =
**$98,300, nothing sold.** That is phantom income: a real bill on a paper gain.
It must be funded.

---

## Three things to add after the number (never skip these)

- **The credit.** AMT paid on an ISO exercise becomes an **AMT credit
  carryforward** against future regular tax. It is (mostly) a **prepayment**,
  not a permanent cost — the timing hurts, the total often washes out.
- **The same-year-sale escape.** Sell the exercised shares in the **same
  calendar year** and the AMT adjustment disappears: it becomes a disqualifying
  disposition taxed as ordinary income instead (see the ISO/NQSO tree).
- **The strategy.** Exercise **early, while the spread is small.** Small spread →
  small add-back → little or no AMT. This is exactly why early-exercise + 83(b)
  exists.

## The phaseout shadow bracket

Once AMTI clears **$500,000**, each extra $1 of bargain element also burns $0.50
of exemption, so the marginal block is taxed at roughly **28% × 1.5 ≈ 42%**.
*Illustrative:* at AMTI **$620,000** the exemption is only max(0, $90,000 − 0.5 ×
($620,000 − $500,000)) = $90,000 − $60,000 = **$30,000**. Exercising "everything"
is not automatically right — the last shares can cost far more than the first.

## Red flag — the flat-28% shortcut is wrong three ways

Quoting "28% × bargain element" ignores (1) the exemption, (2) the 26% band, and
(3) the regular-tax offset in L5. **Never** use it. Run all five lines.

---

## Blank worksheet (run your own)

**Facts:** filing status ______ · taxable income $______ · regular federal tax
$______ · shares ______ · strike $______ · FMV at exercise $______ · shares
sold this year ______.

| Line | Formula | Result |
|---|---|---|
| L1 Bargain element | (FMV − strike) × shares = ($____ − $____) × ____ | $______ |
| L2 AMTI | taxable income + L1 = $____ + $____ | $______ |
| L3 Exemption | max(0, $90,000 − 0.5 × max(0, AMTI − $500,000)) | $______ |
| L3 Base | AMTI − exemption | $______ |
| L4 Tentative min tax | 26% × min(base, $240,000) + 28% × max(0, base − $240,000) | $______ |
| L5 AMT owed | max(0, L4 − regular tax) | $______ |

**Certify before relying:** confirm your regular-tax figure, this year's
exemption and thresholds, and your state's AMT conformity. Take it to a CPA
before you file.
