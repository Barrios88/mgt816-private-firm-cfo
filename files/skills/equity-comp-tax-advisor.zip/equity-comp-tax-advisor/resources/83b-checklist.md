# The 83(b) Election — 30-Day Checklist

> 🟥 **MISS THE 30 DAYS AND THERE IS NO FIX. CONFIRM YOUR GRANT DATE.** 🟥
> The clock runs from the **grant date**, not the vesting date, not the day you
> noticed. There are **no extensions**, no hardship exception, no do-over.

> All figures illustrative (fictional **Kestrel Systems**). Substitute real facts.

---

## What an 83(b) election is

An 83(b) election tells the IRS: "tax me **now**, on the **grant-date** fair
market value of **all** my shares, as ordinary income — instead of taxing each
tranche at its (higher) value as it vests." Every dollar of appreciation after
the grant then becomes **capital gain**, and your holding clock starts on the
grant date.

It converts **timing** (pay now vs. pay at each vest) and **character**
(ordinary vs. capital). The price you pay for that conversion is **forfeiture
risk** and **cash now**.

## Who is eligible

| Instrument | Eligible for 83(b)? |
|---|---|
| Restricted stock (founder or employee) | ✅ YES |
| Early-exercised options (you bought the shares, unvested) | ✅ YES |
| **RSUs** (a *promise* of shares, not property you hold) | ❌ NO |
| Vested options not yet exercised | ❌ NO (no property yet) |

RSUs are ineligible precisely because you do not yet own property — which is why
early-stage firms hand out **restricted stock and early-exercisable options**
instead of RSUs when they want the 83(b) door open.

## The clock

- **30 days from the grant date. No extensions. Statutory.**
- File with the IRS office where you file your return; keep a stamped copy.
- Include a copy with that year's tax return.
- Best practice: send certified mail / tracked, keep the receipt, and have your
  employer countersign that they received their copy.

## The risk (say it plainly)

If you **forfeit** the shares after electing (you leave before vesting, they get
repurchased), there is **no refund** of the tax you prepaid. You may claim a
capital loss only to the extent you actually paid for the shares and were bought
back at a loss. You bet on the company and paid tax up front; if it doesn't vest,
that tax is gone.

---

## "Is it worth it?" heuristic

| Grant-date FMV | Verdict |
|---|---|
| **Tiny** (founder shares at formation; early-exercise at a small spread) | **Near-costless — usually do it.** Small tax now, all upside is LTCG. |
| **Moderate** | Weigh the cash-now bill against expected appreciation and forfeiture odds. |
| **Already high** | **Think hard.** Big tax now, real cash out, and forfeiture-no-refund risk is expensive. |

*Worked (invented — Kestrel):* employee gets **4,000** restricted shares,
grant-date FMV **$1.00** (total $4,000). Illustrative vesting-year prices
$3 / $7 / $12 / $16.

- **No 83(b):** ordinary income as it vests = 1,000×$3 + 1,000×$7 + 1,000×$12 +
  1,000×$16 = **$38,000**, taxed at ordinary rates over four years.
- **83(b):** **$4,000** ordinary income now (4,000 × $1.00). Sell all at $16:
  proceeds 4,000 × $16 = $64,000, minus the $4,000 basis already taxed =
  **$60,000 of LTCG.** Character converted; the steeper the price path, the
  bigger the win.

The election shines here because grant-date value is tiny. Reverse the facts
(grant-date FMV already high) and the same election becomes a large, risky
prepayment.

---

## File-this checklist

- [ ] Confirm the **grant date** in writing (this sets the 30-day deadline).
- [ ] Confirm the instrument is **eligible** (restricted stock or early-exercised
      option — NOT an RSU).
- [ ] Compute grant-date FMV × total shares = the ordinary income you will report.
- [ ] Confirm you have the **cash** for the tax now.
- [ ] Prepare, sign, and **mail within 30 days** (tracked); keep the receipt.
- [ ] Give a copy to your employer; include a copy with your tax return.
- [ ] Have a **CPA countersign** the election before you file.

**Escalation:** the mechanics are above, but the *decision* to file — and the
election document itself — should be reviewed by a CPA or startup lawyer. If you
are within days of the deadline, get help **today**; it cannot be extended.
