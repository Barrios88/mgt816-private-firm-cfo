# AI Verification Log — Equity-Comp Tax

**AI does the analyst work; you certify every number.** This log is where you
operationalize that. For any quantitative answer the skill produces, run the
five manual checks below and record the result. An unlogged number is an
uncertified number — do not rely on it, and do not put it in front of a board or
on a return.

Stamp any figure you cannot trace to a stated source or to `amt-parameters.md`
as **UNVERIFIED**.

---

## The five manual checks (adapt each to the case)

1. **Assumption fidelity** — every rate, threshold, and FMV traced to a stated
   source or `amt-parameters.md`; anything else stamped **UNVERIFIED**.
2. **Character check** — each dollar correctly typed (ordinary / LTCG / AMT
   add-back / QSBS-excluded); re-derive the qualifying-vs-disqualifying
   disposition test by hand.
3. **AMT recompute** — hand-run all five lines; confirm the exemption phaseout is
   applied; reject any flat-28%-of-spread shortcut.
4. **Cash-bridge tie-out** — strike + withholding + AMT (needed) vs. net proceeds
   (available); confirm every phantom-income leg has a funding source.
5. **Two-sided reconciliation** — the employee's ordinary income equals the
   company's deduction (only NQSO / disqualifying-ISO tranches generate one), and
   withholding remitted ties to what was withheld.

---

## Log template

| # | Prompt used | AI claim / number | Check performed | Result (confirmed / corrected / rejected) | Change made |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

---

## Pre-seeded domain checks (illustrative — fictional Kestrel Systems)

| # | Prompt used | AI claim / number | Check performed | Result | Change made |
|---|---|---|---|---|---|
| S1 | "AMT on 50,000 ISOs, strike $0.40, FMV $7.00, income $155,000, reg tax $27,500" | AMT owed = **$78,300** | **Check 3 — AMT recompute.** L1 (7.00−0.40)×50,000 = 330,000; L2 155,000+330,000 = 485,000; L3 485,000 < 500,000 → exemption 90,000, base 395,000; L4 0.26×240,000 + 0.28×155,000 = 62,400+43,400 = 105,800; L5 105,800−27,500 = 78,300 | **confirmed** | none |
| S2 | same as S1 | "just use 28% × bargain = $92,400" | **Check 3 — reject shortcut.** Flat 28% ignores exemption, the 26% band, and the regular-tax offset | **rejected** | replaced with the 5-line result $78,300 |
| S3 | same as S1 | current-year AMT exemption stated from memory | **Check 1 — assumption fidelity.** Traced to `amt-parameters.md` course default $90,000; no better-sourced figure supplied | **confirmed (as course default)** | stamped "course-simplified; verify current-year" |
| S4 | "NQSO exercise, spread $252,000; what does the company deduct?" | Company deduction = **$252,000**; withholding remitted = **$61,362** (24.35%) | **Check 5 — two-sided reconciliation.** Employee ordinary income $252,000 = company deduction $252,000; withholding 0.2435×252,000 = 61,362 ties out | **confirmed** | none |
| S5 | "ISO exercise-and-hold, no sale — is there a cash problem?" | Cash needed $98,300, cash available $0 | **Check 4 — cash-bridge tie-out.** Strike 50,000×0.40 = 20,000 + AMT 78,300 = 98,300; no same-year sale → phantom income, no funding source | **confirmed** | flagged: fund it or reconsider exercise-and-hold |
| S6 | "Consultant was granted ISOs; tax at exercise?" | "It's an ISO; no tax at exercise, AMT add-back only" | **Check 2 — character check.** Consultants cannot hold ISOs → it is an NQSO → spread is ordinary income at exercise | **corrected** | re-typed the spread as ordinary; routed ISO-validity to a lawyer |

---

**Certification ethic.** This mirrors the course policy: *AI does the analyst
work; the human certifies every number; the final exam is closed-book.* If a row
cannot be confirmed by hand, it is not ready to rely on. When a real, dated,
dollar decision is on the line, log the check **and** add the escalation flag
(CPA / securities lawyer / 409A firm).
